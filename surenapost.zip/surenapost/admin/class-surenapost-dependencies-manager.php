<?php
/**
 * کلاس مدیریت وابستگی‌های سورنا پست
 *
 * API جدید تمام وابستگی‌ها را به‌صورت یکجا از مسیر /api/dependency/extra
 * و با ساختار type / name / value برمی‌گرداند.
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس مدیریت وابستگی‌ها
 */
class Surenapost_Dependencies_Manager {

	/** @var string */
	private $post_services_option = 'surenapost_post_services';

	/** @var string */
	private $packet_types_option = 'surenapost_packet_types';

	/** @var string */
	private $box_sizes_option = 'surenapost_box_sizes';

	/** @var string */
	private $pay_types_option = 'surenapost_pay_types';

	/**
	 * نسخه پاک‌سازی‌شده پاسخ خام API؛ برای سازگاری با نوع‌های جدید احتمالی.
	 *
	 * @var string
	 */
	private $raw_dependencies_option = 'surenapost_dependencies_raw';

	/** @var string */
	private $cache_transient_prefix = 'surenapost_deps_cache_';

	/** @var int */
	private $cache_expiration = 86400;

	/** @var string */
	private $api_base_url = 'https://post-api.sourena.shop/api/dependency';

	/** @var array|WP_Error|null */
	private $extra_dependencies_cache = null;

	/** @var bool */
	private $extra_dependencies_loaded = false;

	/**
	 * دریافت یک نوع وابستگی از endpoint مشترک API جدید.
	 *
	 * @param string $type  نوع داخلی افزونه.
	 * @param string $token توکن API.
	 * @return array|WP_Error
	 */
	public function fetch_dependency_from_api( $type, $token ) {
		if ( empty( $token ) ) {
			return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		if ( ! $this->get_option_name( $type ) ) {
			return new WP_Error( 'invalid_dependency_type', __( 'نوع وابستگی نامعتبر است.', 'surenapost' ) );
		}

		$extra_items = $this->fetch_extra_dependencies_from_api( $token );
		if ( is_wp_error( $extra_items ) ) {
			return $extra_items;
		}

		return $this->filter_extra_dependencies( $type, $extra_items );
	}

	/**
	 * دریافت خروجی endpoint وابستگی.
	 *
	 * @param string $endpoint بخش پایانی URL.
	 * @param string $token    توکن API.
	 * @return array|WP_Error
	 */
	private function fetch_dependency_output_from_endpoint( $endpoint, $token ) {
		$url = $this->api_base_url . '/' . ltrim( (string) $endpoint, '/' );

		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 30,
				'httpversion' => '1.1',
				'headers'     => array(
					'Authorization' => 'Bearer ' . trim( (string) $token ),
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return new WP_Error(
				'invalid_json',
				sprintf(
					/* translators: %s: JSON error message. */
					__( 'پاسخ نامعتبر از API دریافت شد: %s', 'surenapost' ),
					json_last_error_msg()
				)
			);
		}

		if ( $code < 200 || $code >= 300 ) {
			$message = $this->extract_api_error_message( $data );
			if ( '' === $message ) {
				$message = sprintf(
					/* translators: 1: endpoint name, 2: HTTP status code. */
					__( 'خطا در دریافت %1$s: کد %2$d', 'surenapost' ),
					$endpoint,
					$code
				);
			}

			return new WP_Error( 'api_error', $message );
		}

		if ( isset( $data['status'] ) && false === $data['status'] ) {
			$message = $this->extract_api_error_message( $data );
			return new WP_Error(
				'api_error',
				'' !== $message ? $message : __( 'سرویس سورناپست درخواست دریافت وابستگی‌ها را رد کرد.', 'surenapost' )
			);
		}

		if ( ! isset( $data['output'] ) || ! is_array( $data['output'] ) ) {
			return new WP_Error( 'invalid_data', __( 'فیلد output در پاسخ وابستگی‌های سورنا پست یافت نشد.', 'surenapost' ) );
		}

		return $data['output'];
	}

	/**
	 * دریافت endpoint مشترک extra فقط یک بار در هر درخواست.
	 *
	 * @param string $token توکن API.
	 * @return array|WP_Error
	 */
	private function fetch_extra_dependencies_from_api( $token ) {
		if ( $this->extra_dependencies_loaded ) {
			return $this->extra_dependencies_cache;
		}

		$this->extra_dependencies_loaded = true;
		$this->extra_dependencies_cache  = $this->fetch_dependency_output_from_endpoint( 'extra', $token );

		return $this->extra_dependencies_cache;
	}

	/**
	 * نگاشت نام نوع‌های API جدید به نام‌های داخلی افزونه.
	 * نام اصلی فعلی API در ابتدای هر آرایه آمده و نام‌های قدیمی فقط برای
	 * سازگاری با پاسخ‌های کش‌شده یا نسخه‌های گذار حفظ شده‌اند.
	 *
	 * @return array<string,array<int,string>>
	 */
	private function get_api_type_map() {
		return array(
			'post-services' => array( 'postservices', 'posttype', 'postservice', 'postserviceid' ),
			'packet-types'  => array( 'packettypes', 'packettype', 'packagetype' ),
			'box-sizes'     => array( 'boxsizes', 'boxsize', 'packetsize' ),
			'payType'       => array( 'paytype', 'paymenttype' ),
		);
	}

	/**
	 * نرمال‌سازی نام type دریافتی از API.
	 *
	 * API در نسخه‌های مختلف ممکن است یک type را با حروف بزرگ و کوچک، خط تیره،
	 * آندرلاین یا فاصله برگرداند. همه این حالت‌ها باید یک نوع در نظر گرفته شوند.
	 *
	 * @param mixed $type نوع خام API.
	 * @return string
	 */
	private function normalize_api_type( $type ) {
		$type = strtolower( trim( (string) $type ) );
		return preg_replace( '/[^a-z0-9]+/', '', $type );
	}

	/**
	 * جدا کردن یک نوع وابستگی از خروجی مشترک extra.
	 *
	 * @param string $type        نوع داخلی افزونه.
	 * @param array  $extra_items خروجی endpoint extra.
	 * @return array
	 */
	private function filter_extra_dependencies( $type, $extra_items ) {
		$type_map = $this->get_api_type_map();

		if ( ! isset( $type_map[ $type ] ) || ! is_array( $extra_items ) ) {
			return array();
		}

		$accepted_types = $type_map[ $type ];
		$items          = array();
		$seen_ids       = array();

		foreach ( $extra_items as $item ) {
			if (
				! is_array( $item ) ||
				! isset( $item['type'], $item['name'] ) ||
				! array_key_exists( 'value', $item ) ||
				! in_array( $this->normalize_api_type( $item['type'] ), $accepted_types, true )
			) {
				continue;
			}

			$name = sanitize_text_field( trim( (string) $item['name'] ) );
			if ( '' === $name || ! is_numeric( $item['value'] ) ) {
				continue;
			}

			$item_id = (int) $item['value'];
			if ( isset( $seen_ids[ $item_id ] ) ) {
				continue;
			}

			$seen_ids[ $item_id ] = true;
			$items[] = array(
				'id'   => $item_id,
				'name' => $name,
			);
		}

		return $items;
	}

	/**
	 * پاک‌سازی پاسخ خام قبل از ذخیره در option.
	 *
	 * @param array $items پاسخ خام API.
	 * @return array
	 */
	private function sanitize_raw_dependencies( $items ) {
		$sanitized = array();

		if ( ! is_array( $items ) ) {
			return $sanitized;
		}

		foreach ( $items as $item ) {
			if (
				! is_array( $item ) ||
				! isset( $item['type'], $item['name'] ) ||
				! array_key_exists( 'value', $item )
			) {
				continue;
			}

			$type = sanitize_text_field( trim( (string) $item['type'] ) );
			$name = sanitize_text_field( trim( (string) $item['name'] ) );

			if ( '' === $type || '' === $name || ! is_numeric( $item['value'] ) ) {
				continue;
			}

			$sanitized[] = array(
				'type'  => $type,
				'name'  => $name,
				'value' => (int) $item['value'],
			);
		}

		return $sanitized;
	}

	/**
	 * ذخیره وابستگی‌ها در option و transient.
	 *
	 * @param string $type نوع وابستگی.
	 * @param array  $data داده‌ها.
	 * @return bool
	 */
	public function save_dependency( $type, $data ) {
		if ( ! is_array( $data ) ) {
			return false;
		}

		$option_name = $this->get_option_name( $type );
		if ( ! $option_name ) {
			return false;
		}

		update_option( $option_name, array_values( $data ), false );
		set_transient( $this->cache_transient_prefix . $type, array_values( $data ), $this->cache_expiration );

		return true;
	}

	/**
	 * دریافت وابستگی‌ها از کش یا option.
	 *
	 * @param string $type نوع وابستگی.
	 * @return array|false
	 */
	public function get_dependency( $type ) {
		$option_name = $this->get_option_name( $type );
		if ( ! $option_name ) {
			return false;
		}

		$transient_key = $this->cache_transient_prefix . $type;
		$cached        = get_transient( $transient_key );
		if ( false !== $cached && is_array( $cached ) && ! empty( $cached ) ) {
			return $cached;
		}

		$stored = get_option( $option_name, false );
		if ( false !== $stored && is_array( $stored ) && ! empty( $stored ) ) {
			set_transient( $transient_key, $stored, $this->cache_expiration );
			return $stored;
		}

		// بازیابی خودکار از پاسخ خام؛ برای نصب‌هایی که با نگاشت قدیمی ذخیره شده‌اند.
		$raw = get_option( $this->raw_dependencies_option, array() );
		if ( is_array( $raw ) && ! empty( $raw ) ) {
			$rebuilt = $this->filter_extra_dependencies( $type, $raw );
			if ( ! empty( $rebuilt ) ) {
				$this->save_dependency( $type, $rebuilt );
				return $rebuilt;
			}
		}

		return is_array( $stored ) ? $stored : false;
	}

	/**
	 * آیا حداقل یک همگام‌سازی معتبر وابستگی انجام شده است؟
	 *
	 * در نسخه PHP خام، موفقیت بر اساس دریافت مجموعه معتبر type/name/value است؛
	 * خالی بودن یکی از گروه‌های شناخته‌شده نباید مرحله راه‌اندازی را برای همیشه متوقف کند.
	 *
	 * @return bool
	 */
	public function has_successful_sync() {
		if ( '1' === (string) get_option( 'surenapost_dependencies_sync_complete', '' ) ) {
			return true;
		}

		$raw = get_option( $this->raw_dependencies_option, array() );
		if ( is_array( $raw ) && ! empty( $raw ) ) {
			return true;
		}

		if ( '' === trim( (string) get_option( 'surenapost_dependencies_last_refresh', '' ) ) ) {
			return false;
		}

		foreach ( array_keys( $this->get_all_dependency_types() ) as $type ) {
			$items = get_option( $this->get_option_name( $type ), array() );
			if ( is_array( $items ) && ! empty( $items ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * دریافت عنوان یک وابستگی بر اساس شناسه.
	 *
	 * @param string $type     نوع وابستگی.
	 * @param int    $item_id  شناسه.
	 * @param string $fallback مقدار جایگزین.
	 * @return string
	 */
	public function get_dependency_name( $type, $item_id, $fallback = '' ) {
		$items   = $this->get_dependency( $type );
		$item_id = (int) $item_id;

		// در payType مقدار صفر معتبر است.
		if ( ! is_array( $items ) || ( 'payType' !== $type && $item_id <= 0 ) ) {
			return (string) $fallback;
		}

		foreach ( $items as $item ) {
			if ( isset( $item['id'], $item['name'] ) && (int) $item['id'] === $item_id ) {
				return sanitize_text_field( (string) $item['name'] );
			}
		}

		return (string) $fallback;
	}

	/**
	 * دریافت نام option بر اساس نوع.
	 *
	 * @param string $type نوع وابستگی.
	 * @return string|false
	 */
	private function get_option_name( $type ) {
		switch ( $type ) {
			case 'post-services':
				return $this->post_services_option;
			case 'packet-types':
				return $this->packet_types_option;
			case 'box-sizes':
				return $this->box_sizes_option;
			case 'payType':
				return $this->pay_types_option;
			default:
				return false;
		}
	}

	/**
	 * بروزرسانی تمام وابستگی‌ها از endpoint واحد extra.
	 *
	 * مطابق نسخه PHP خام، داده‌های قبلی فقط پس از دریافت و اعتبارسنجی موفق پاسخ
	 * با مجموعه جدید جایگزین می‌شوند. پارامتر دوم برای سازگاری API داخلی افزونه
	 * حفظ شده، اما API جدید همیشه جایگزینی کامل انجام می‌دهد.
	 *
	 * @param string $token          توکن API.
	 * @param bool   $clear_existing پارامتر سازگاری؛ در API جدید نادیده گرفته می‌شود.
	 * @return array
	 */
	public function update_all_dependencies( $token, $clear_existing = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$dependency_types = $this->get_all_dependency_types();
		$results          = array(
			'total_inserted' => 0,
			'total_skipped'  => 0,
			'errors'         => array(),
			'details'        => array(),
		);

		$extra_items = $this->fetch_extra_dependencies_from_api( $token );
		if ( is_wp_error( $extra_items ) ) {
			$results['errors'][] = $extra_items->get_error_message();
			return $results;
		}

		if ( ! is_array( $extra_items ) ) {
			$results['errors'][] = __( 'پاسخ نامعتبر از API برای dependency/extra دریافت شد.', 'surenapost' );
			return $results;
		}

		$sanitized_raw = $this->sanitize_raw_dependencies( $extra_items );
		if ( empty( $sanitized_raw ) ) {
			$results['errors'][] = __( 'هیچ وابستگی معتبر با ساختار type، name و value از API دریافت نشد.', 'surenapost' );
			return $results;
		}

		// ابتدا همه گروه‌ها آماده می‌شوند تا در صورت خطا، داده‌های قبلی دست‌نخورده بمانند.
		$grouped = array();
		foreach ( $dependency_types as $type => $label ) {
			$grouped[ $type ] = $this->filter_extra_dependencies( $type, $sanitized_raw );
		}

		// جایگزینی کامل؛ معادل DELETE و INSERT نسخه PHP خام، اما بدون بازه خالی خطرناک.
		foreach ( $dependency_types as $type => $label ) {
			$data = $grouped[ $type ];
			$this->save_dependency( $type, $data );

			$count = count( $data );
			$results['details'][ $type ] = array(
				'label'    => $label,
				'inserted' => $count,
				'skipped'  => 0,
				'total'    => $count,
			);
		}

		// مانند PHP خام، تعداد کل بر اساس تمام ردیف‌های معتبر پاسخ محاسبه می‌شود.
		$results['total_inserted'] = count( $sanitized_raw );

		update_option( $this->raw_dependencies_option, $sanitized_raw, false );
		update_option( 'surenapost_dependencies_last_refresh', current_time( 'mysql' ), false );
		update_option( 'surenapost_dependencies_sync_complete', '1', false );

		return $results;
	}

	/**
	 * استخراج پیام خطای API.
	 *
	 * @param array $data پاسخ API.
	 * @return string
	 */
	private function extract_api_error_message( $data ) {
		if ( ! is_array( $data ) ) {
			return '';
		}

		foreach ( array( 'error', 'message' ) as $key ) {
			if ( isset( $data[ $key ] ) && is_scalar( $data[ $key ] ) ) {
				return sanitize_text_field( (string) $data[ $key ] );
			}
		}

		foreach ( array( 'data', 'output' ) as $container ) {
			if ( isset( $data[ $container ] ) && is_array( $data[ $container ] ) ) {
				foreach ( array( 'error', 'message' ) as $key ) {
					if ( isset( $data[ $container ][ $key ] ) && is_scalar( $data[ $container ][ $key ] ) ) {
						return sanitize_text_field( (string) $data[ $container ][ $key ] );
					}
				}
			}
		}

		return '';
	}

	/**
	 * پاک کردن تمام وابستگی‌ها.
	 *
	 * @return bool
	 */
	public function clear_all_dependencies() {
		foreach ( array_keys( $this->get_all_dependency_types() ) as $type ) {
			$option_name = $this->get_option_name( $type );
			if ( $option_name ) {
				delete_option( $option_name );
			}
			delete_transient( $this->cache_transient_prefix . $type );
		}

		delete_option( $this->raw_dependencies_option );
		delete_option( 'surenapost_dependencies_last_refresh' );
		delete_option( 'surenapost_dependencies_sync_complete' );

		return true;
	}

	/**
	 * دریافت لیست انواع وابستگی‌های مورد استفاده افزونه.
	 *
	 * @return array
	 */
	public function get_all_dependency_types() {
		return array(
			'post-services' => __( 'خدمات پست', 'surenapost' ),
			'packet-types'  => __( 'انواع بسته', 'surenapost' ),
			'box-sizes'     => __( 'اندازه‌های جعبه', 'surenapost' ),
			'payType'       => __( 'انواع پرداخت', 'surenapost' ),
		);
	}
}

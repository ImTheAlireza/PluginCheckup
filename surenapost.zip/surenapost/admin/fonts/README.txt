IRANSans print font files

Place the files exactly here:
- eot/IRANSansWeb.eot
- woff2/IRANSansWeb.woff2
- woff/IRANSansWeb.woff
- ttf/IRANSansWeb.ttf

The print template loads these files locally from the plugin.

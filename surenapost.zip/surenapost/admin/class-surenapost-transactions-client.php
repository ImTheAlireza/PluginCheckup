<?php
/**
 * کلاینت تراکنش‌های کیف‌پول سورناپست
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس کلاینت تراکنش‌ها
 */
class Surenapost_Transactions_Client {

	/**
	 * آدرس API تراکنش‌ها
	 *
	 * @var string
	 */
	private $transactions_endpoint = 'https://post-api.sourena.shop/api/wallet/transactions';

	/**
	 * آدرس API وابستگی‌های تراکنش‌ها
	 *
	 * @var string
	 */
	private $dependencies_endpoint = 'https://post-api.sourena.shop/api/wallet/transactions/dependency';

	/**
	 * زمان تایم‌اوت درخواست
	 *
	 * @var int
	 */
	private $timeout = 30;

	/**
	 * دریافت لیست تراکنش‌های کیف‌پول
	 *
	 * @param string $token      توکن API
	 * @param array  $params     پارامترهای فیلتر
	 * @return array|WP_Error
	 */
	public function fetch_transactions( $token, $params = array() ) {
		if ( empty( $token ) ) {
			return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		// ساخت URL با پارامترها
		$url = $this->transactions_endpoint;
		$query_params = array();

		// صفحه‌بندی
		if ( isset( $params['page'] ) && is_numeric( $params['page'] ) ) {
			$query_params['page'] = absint( $params['page'] );
		} else {
			$query_params['page'] = 1;
		}

		// تعداد آیتم در هر صفحه
		if ( isset( $params['per_page'] ) && is_numeric( $params['per_page'] ) ) {
			$query_params['per_page'] = absint( $params['per_page'] );
		} else {
			$query_params['per_page'] = 10;
		}

		// فیلتر تاریخ شروع
		if ( ! empty( $params['start_date'] ) ) {
			$query_params['start_date'] = sanitize_text_field( $params['start_date'] );
		}

		// فیلتر تاریخ پایان
		if ( ! empty( $params['end_date'] ) ) {
			$query_params['end_date'] = sanitize_text_field( $params['end_date'] );
		}

		// فیلتر نوع تراکنش
		if ( ! empty( $params['type'] ) ) {
			$query_params['type'] = sanitize_text_field( $params['type'] );
		}

		// اضافه کردن query string به URL
		if ( ! empty( $query_params ) ) {
			$url = add_query_arg( $query_params, $url );
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => $this->timeout,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
		}

		$data = json_decode( $body, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'json_error', json_last_error_msg() );
		}

		return $data;
	}

	/**
	 * دریافت وابستگی‌های لیست تراکنش‌ها (نوع تراکنش)
	 *
	 * @param string $token توکن API
	 * @return array|WP_Error
	 */
	public function fetch_dependencies( $token ) {
		if ( empty( $token ) ) {
			return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$response = wp_remote_get(
			$this->dependencies_endpoint,
			array(
				'timeout' => $this->timeout,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
		}

		$data = json_decode( $body, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'json_error', json_last_error_msg() );
		}

		// پردازش داده‌های دریافتی
		$result = array(
			'types' => array(),
		);

		// استخراج type ها
		if ( isset( $data['output']['type'] ) && is_array( $data['output']['type'] ) ) {
			foreach ( $data['output']['type'] as $type ) {
				if ( isset( $type['value'] ) && isset( $type['label'] ) ) {
					$result['types'][ $type['value'] ] = $type['label'];
				}
			}
		} elseif ( isset( $data['type'] ) && is_array( $data['type'] ) ) {
			foreach ( $data['type'] as $type ) {
				if ( isset( $type['value'] ) && isset( $type['label'] ) ) {
					$result['types'][ $type['value'] ] = $type['label'];
				}
			}
		}

		// در صورت خالی بودن، از مقادیر پیش‌فرض استفاده می‌کنیم
		if ( empty( $result['types'] ) ) {
			$result['types'] = $this->get_default_types();
		}

		return $result;
	}

	/**
	 * دریافت لیست پیش‌فرض انواع تراکنش
	 *
	 * @return array
	 */
	public function get_default_types() {
		return array(
			'credit'  => __( 'افزایش موجودی', 'surenapost' ),
			'debit'   => __( 'کاهش موجودی', 'surenapost' ),
			'payment' => __( 'پرداخت', 'surenapost' ),
			'refund'  => __( 'بازگشت وجه', 'surenapost' ),
		);
	}
}

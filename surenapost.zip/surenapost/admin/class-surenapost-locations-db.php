<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surenapost_Locations_DB {

    /**
     * نام جدول استان‌ها
     *
     * @var string
     */
    private $provinces_table;

    /**
     * نام جدول شهرها
     *
     * @var string
     */
    private $cities_table;

    /**
     * نام option برای نسخه schema
     *
     * @var string
     */
    private $schema_version_option = 'surenapost_locations_schema_version';

    /**
     * نسخه schema
     *
     * @var string
     */
    private $schema_version = '1.0.0';

    /**
     * آدرس پایه API
     *
     * @var string
     */
    private $api_base_url = 'https://post-api.sourena.shop/api/dependency/';

    /**
     * سازنده
     */
    public function __construct() {
        global $wpdb;

        $this->provinces_table = $wpdb->prefix . 'surenapost_provinces';
        $this->cities_table    = $wpdb->prefix . 'surenapost_cities';
    }

    /**
     * اگر جدول‌ها وجود ندارند یا نسخه schema تغییر کرده، جدول‌ها را می‌سازد
     *
     * @return void
     */
    public function maybe_create_tables() {
        $current_version = get_option( $this->schema_version_option, '' );

        if ( $current_version !== $this->schema_version || ! $this->tables_exist() ) {
            $this->create_tables();
            update_option( $this->schema_version_option, $this->schema_version, false );
        }
    }

    /**
     * بررسی وجود جدول‌ها
     *
     * @return bool
     */
    private function tables_exist() {
        global $wpdb;

        $provinces_exists = $wpdb->get_var(
            $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->provinces_table )
        );

        $cities_exists = $wpdb->get_var(
            $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->cities_table )
        );

        return ( $provinces_exists === $this->provinces_table ) && ( $cities_exists === $this->cities_table );
    }

    /**
     * ساخت جدول‌ها
     *
     * @return void
     */
    public function create_tables() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();

        $sql_provinces = "CREATE TABLE {$this->provinces_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			api_id bigint(20) unsigned NOT NULL,
			name varchar(191) NOT NULL,
			created_at datetime NULL DEFAULT NULL,
			updated_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY api_id (api_id),
			KEY name (name)
		) {$charset_collate};";

        $sql_cities = "CREATE TABLE {$this->cities_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			api_id bigint(20) unsigned NOT NULL,
			province_api_id bigint(20) unsigned NOT NULL,
			name varchar(191) NOT NULL,
			created_at datetime NULL DEFAULT NULL,
			updated_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY api_id (api_id),
			KEY province_api_id (province_api_id),
			KEY name (name),
			KEY province_name (province_api_id, name)
		) {$charset_collate};";

        dbDelta( $sql_provinces );
        dbDelta( $sql_cities );
    }

    /**
     * گرفتن توکن API
     *
     * @return string
     */
    private function get_api_token() {
        $api_manager = new Surenapost_Api_Manager();
        return (string) $api_manager->get_api_key();
    }

    /**
     * درخواست GET به API
     *
     * @param string $endpoint endpoint
     * @param array  $query_args پارامترهای query string
     * @return array|WP_Error
     */
    private function api_get( $endpoint, $query_args = array() ) {
        $token = $this->get_api_token();

        if ( empty( $token ) ) {
            return new WP_Error( 'no_api_key', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $url = trailingslashit( $this->api_base_url ) . ltrim( $endpoint, '/' );

        if ( ! empty( $query_args ) ) {
            $url = add_query_arg( $query_args, $url );
        }

        $headers = array(
            'Authorization: Bearer ' . $token,
            'Accept: application/json',
        );

        $ch = curl_init();

        curl_setopt_array( $ch, array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CUSTOMREQUEST  => 'GET',
            CURLOPT_TIMEOUT        => 30,
        ) );

        $body       = curl_exec( $ch );
        $curl_error = curl_error( $ch );
        $http_code  = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );

        curl_close( $ch );

        update_option(
            'surenapost_locations_last_api_debug',
            array(
                'url'        => $url,
                'http_code'  => $http_code,
                'curl_error' => $curl_error,
                'raw_body'   => $body,
                'time'       => current_time( 'mysql' ),
            ),
            false
        );

        if ( ! empty( $curl_error ) ) {
            return new WP_Error(
                'curl_error',
                'Curl Error: ' . $curl_error,
                array(
                    'url' => $url,
                )
            );
        }

        if ( $http_code < 200 || $http_code >= 300 ) {
            return new WP_Error(
                'api_error',
                __( 'پاسخ نامعتبر از سرور دریافت شد.', 'surenapost' ),
                array(
                    'http_code' => $http_code,
                    'raw_body'  => $body,
                    'url'       => $url,
                )
            );
        }

        $data = json_decode( $body, true );

        if ( JSON_ERROR_NONE !== json_last_error() ) {
            return new WP_Error(
                'invalid_json',
                'JSON Decode Error: ' . json_last_error_msg(),
                array(
                    'raw_body' => $body,
                    'url'      => $url,
                )
            );
        }

        if ( ! is_array( $data ) ) {
            return new WP_Error(
                'invalid_data',
                __( 'داده دریافتی از API معتبر نیست.', 'surenapost' ),
                array(
                    'raw_body' => $body,
                    'url'      => $url,
                )
            );
        }

        if ( isset( $data['status'] ) && false === $data['status'] ) {
            $message = $this->extract_api_error_message( $data );

            return new WP_Error(
                'api_error',
                '' !== $message ? $message : __( 'سرویس سورناپست درخواست دریافت شهرها و استان‌ها را رد کرد.', 'surenapost' ),
                array(
                    'raw_body' => $body,
                    'url'      => $url,
                )
            );
        }

        return $data;
    }
    /**
     * استخراج پیام خطای API.
     *
     * @param array $data پاسخ API.
     * @return string
     */
    private function extract_api_error_message( $data ) {
        if ( ! is_array( $data ) ) {
            return '';
        }

        foreach ( array( 'error', 'message' ) as $key ) {
            if ( isset( $data[ $key ] ) && is_string( $data[ $key ] ) ) {
                return sanitize_text_field( $data[ $key ] );
            }
        }

        if ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
            foreach ( array( 'error', 'message' ) as $key ) {
                if ( isset( $data['data'][ $key ] ) && is_string( $data['data'][ $key ] ) ) {
                    return sanitize_text_field( $data['data'][ $key ] );
                }
            }
        }

        return '';
    }

    /**
     * بررسی آرایه لیستی
     *
     * @param mixed $array آرایه
     * @return bool
     */
    private function is_list_array( $array ) {
        if ( ! is_array( $array ) ) {
            return false;
        }

        $expected_key = 0;
        foreach ( $array as $key => $value ) {
            if ( $key !== $expected_key ) {
                return false;
            }
            $expected_key++;
        }

        return true;
    }

    /**
     * استخراج لیست آیتم‌ها از پاسخ API
     *
     * @param array $data داده خام
     * @return array
     */
    private function extract_items( $data ) {
        if ( ! is_array( $data ) ) {
            return array();
        }

        if ( isset( $data['output'] ) && is_array( $data['output'] ) ) {
            return $data['output'];
        }

        if ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
            return $data['data'];
        }

        if ( isset( $data['result'] ) && is_array( $data['result'] ) ) {
            return $data['result'];
        }

        if ( $this->is_list_array( $data ) ) {
            return $data;
        }

        return array();
    }

    /**
     * نرمال‌سازی استان‌ها
     *
     * @param array $data داده خام
     * @return array
     */
    private function normalize_provinces( $data ) {
        $items   = $this->extract_items( $data );
        $results = array();

        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['id'] ) || ! isset( $item['name'] ) ) {
                continue;
            }

            $api_id = absint( $item['id'] );
            $name   = sanitize_text_field( $item['name'] );

            if ( $api_id <= 0 || '' === $name ) {
                continue;
            }

            $results[] = array(
                'id'   => $api_id,
                'name' => $name,
            );
        }

        update_option( 'surenapost_locations_last_normalized_provinces', $results, false );

        return $results;
    }

    /**
     * نرمال‌سازی شهرها
     *
     * @param int   $province_id شناسه استان
     * @param array $data داده خام
     * @return array
     */
    private function normalize_cities( $province_id, $data ) {
        $items   = $this->extract_items( $data );
        $results = array();

        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['id'] ) || ! isset( $item['name'] ) ) {
                continue;
            }

            $api_id = absint( $item['id'] );
            $name   = sanitize_text_field( $item['name'] );

            if ( $api_id <= 0 || '' === $name ) {
                continue;
            }

            $results[] = array(
                'id'              => $api_id,
                'province_api_id' => absint( $province_id ),
                'name'            => $name,
            );
        }

        update_option( 'surenapost_locations_last_normalized_cities_' . absint( $province_id ), $results, false );

        return $results;
    }

    /**
     * گرفتن استان‌ها از API
     *
     * @return array|WP_Error
     */
    public function fetch_provinces_from_api() {
        $data = $this->api_get( 'provinces' );

        if ( is_wp_error( $data ) ) {
            return $data;
        }

        return $this->normalize_provinces( $data );
    }

    /**
     * گرفتن شهرهای یک استان از API
     *
     * @param int $province_id شناسه استان
     * @return array|WP_Error
     */
    public function fetch_cities_from_api( $province_id ) {
        $province_id = absint( $province_id );

        if ( $province_id <= 0 ) {
            return new WP_Error( 'invalid_province', __( 'شناسه استان نامعتبر است.', 'surenapost' ) );
        }

        $data = $this->api_get(
            'cities',
            array(
                'province_id' => $province_id,
            )
        );

        if ( is_wp_error( $data ) ) {
            return $data;
        }

        return $this->normalize_cities( $province_id, $data );
    }

    /**
     * ذخیره یا بروزرسانی استان‌ها در دیتابیس
     *
     * @param array $provinces آرایه استان‌ها
     * @return array|WP_Error
     */
    public function save_provinces( $provinces ) {
        global $wpdb;

        $this->maybe_create_tables();

        $result = array(
            'inserted' => 0,
            'updated'  => 0,
            'total'    => 0,
        );

        if ( ! is_array( $provinces ) || empty( $provinces ) ) {
            return $result;
        }

        $existing_rows = $wpdb->get_results(
            "SELECT api_id, name FROM {$this->provinces_table}",
            ARRAY_A
        );

        $existing_map = array();
        if ( ! empty( $existing_rows ) ) {
            foreach ( $existing_rows as $row ) {
                $existing_map[ (int) $row['api_id'] ] = $row['name'];
            }
        }

        $now = current_time( 'mysql' );

        foreach ( $provinces as $province ) {
            if ( ! isset( $province['id'], $province['name'] ) ) {
                continue;
            }

            $api_id = absint( $province['id'] );
            $name   = sanitize_text_field( $province['name'] );

            if ( $api_id <= 0 || '' === $name ) {
                continue;
            }

            if ( isset( $existing_map[ $api_id ] ) ) {
                if ( $existing_map[ $api_id ] !== $name ) {
                    $updated = $wpdb->update(
                        $this->provinces_table,
                        array(
                            'name'       => $name,
                            'updated_at' => $now,
                        ),
                        array(
                            'api_id' => $api_id,
                        ),
                        array( '%s', '%s' ),
                        array( '%d' )
                    );

                    if ( false === $updated ) {
                        return new WP_Error(
                            'db_update_error',
                            __( 'خطا در بروزرسانی استان‌ها در دیتابیس.', 'surenapost' ),
                            array(
                                'db_error' => $wpdb->last_error,
                                'api_id'   => $api_id,
                            )
                        );
                    }

                    $result['updated']++;
                }
            } else {
                $inserted = $wpdb->insert(
                    $this->provinces_table,
                    array(
                        'api_id'     => $api_id,
                        'name'       => $name,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ),
                    array( '%d', '%s', '%s', '%s' )
                );

                if ( false === $inserted ) {
                    return new WP_Error(
                        'db_insert_error',
                        __( 'خطا در ذخیره استان‌ها در دیتابیس.', 'surenapost' ),
                        array(
                            'db_error' => $wpdb->last_error,
                            'api_id'   => $api_id,
                        )
                    );
                }

                $result['inserted']++;
            }

            $result['total']++;
        }

        return $result;
    }

    /**
     * ذخیره یا بروزرسانی شهرهای یک استان در دیتابیس
     *
     * @param int   $province_id شناسه استان
     * @param array $cities آرایه شهرها
     * @return array|WP_Error
     */
    public function save_cities( $province_id, $cities ) {
        global $wpdb;

        $this->maybe_create_tables();

        $province_id = absint( $province_id );

        $result = array(
            'inserted' => 0,
            'updated'  => 0,
            'total'    => 0,
        );

        if ( $province_id <= 0 || ! is_array( $cities ) || empty( $cities ) ) {
            return $result;
        }

        $existing_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT api_id, name FROM {$this->cities_table} WHERE province_api_id = %d",
                $province_id
            ),
            ARRAY_A
        );

        $existing_map = array();
        if ( ! empty( $existing_rows ) ) {
            foreach ( $existing_rows as $row ) {
                $existing_map[ (int) $row['api_id'] ] = $row['name'];
            }
        }

        $now = current_time( 'mysql' );

        foreach ( $cities as $city ) {
            if ( ! isset( $city['id'], $city['name'] ) ) {
                continue;
            }

            $api_id = absint( $city['id'] );
            $name   = sanitize_text_field( $city['name'] );

            if ( $api_id <= 0 || '' === $name ) {
                continue;
            }

            if ( isset( $existing_map[ $api_id ] ) ) {
                if ( $existing_map[ $api_id ] !== $name ) {
                    $updated = $wpdb->update(
                        $this->cities_table,
                        array(
                            'name'            => $name,
                            'province_api_id' => $province_id,
                            'updated_at'      => $now,
                        ),
                        array(
                            'api_id' => $api_id,
                        ),
                        array( '%s', '%d', '%s' ),
                        array( '%d' )
                    );

                    if ( false === $updated ) {
                        return new WP_Error(
                            'db_update_error',
                            __( 'خطا در بروزرسانی شهرها در دیتابیس.', 'surenapost' ),
                            array(
                                'db_error' => $wpdb->last_error,
                                'api_id'   => $api_id,
                            )
                        );
                    }

                    $result['updated']++;
                }
            } else {
                $inserted = $wpdb->insert(
                    $this->cities_table,
                    array(
                        'api_id'          => $api_id,
                        'province_api_id' => $province_id,
                        'name'            => $name,
                        'created_at'      => $now,
                        'updated_at'      => $now,
                    ),
                    array( '%d', '%d', '%s', '%s', '%s' )
                );

                if ( false === $inserted ) {
                    return new WP_Error(
                        'db_insert_error',
                        __( 'خطا در ذخیره شهرها در دیتابیس.', 'surenapost' ),
                        array(
                            'db_error' => $wpdb->last_error,
                            'api_id'   => $api_id,
                        )
                    );
                }

                $result['inserted']++;
            }

            $result['total']++;
        }

        return $result;
    }

    /**
     * دریافت استان‌ها از دیتابیس
     *
     * @param bool $force_refresh اگر true باشد قبلش sync انجام می‌دهد
     * @return array|WP_Error
     */
    public function get_provinces( $force_refresh = false ) {
        global $wpdb;

        $this->maybe_create_tables();

        if ( $force_refresh ) {
            $refresh = $this->refresh_provinces();
            if ( is_wp_error( $refresh ) ) {
                return $refresh;
            }
        }

        $rows = $wpdb->get_results(
            "SELECT api_id AS id, name FROM {$this->provinces_table} ORDER BY name ASC",
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    /**
     * دریافت شهرهای یک استان از دیتابیس
     *
     * @param int  $province_id شناسه استان
     * @param bool $force_refresh اگر true باشد قبلش sync انجام می‌دهد
     * @return array|WP_Error
     */
    public function get_cities( $province_id, $force_refresh = false ) {
        global $wpdb;

        $this->maybe_create_tables();

        $province_id = absint( $province_id );

        if ( $province_id <= 0 ) {
            return new WP_Error( 'invalid_province', __( 'شناسه استان نامعتبر است.', 'surenapost' ) );
        }

        if ( $force_refresh ) {
            $refresh = $this->refresh_cities_by_province( $province_id );
            if ( is_wp_error( $refresh ) ) {
                return $refresh;
            }
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT api_id AS id, name FROM {$this->cities_table} WHERE province_api_id = %d ORDER BY name ASC",
                $province_id
            ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    /**
     * بروزرسانی استان‌ها از API
     *
     * @return array|WP_Error
     */
    public function refresh_provinces() {
        $this->maybe_create_tables();

        $provinces = $this->fetch_provinces_from_api();
        if ( is_wp_error( $provinces ) ) {
            return $provinces;
        }

        if ( empty( $provinces ) ) {
            return new WP_Error(
                'empty_provinces',
                __( 'هیچ استان معتبری از API دریافت نشد.', 'surenapost' )
            );
        }

        return $this->save_provinces( $provinces );
    }

    /**
     * بروزرسانی شهرهای یک استان از API
     *
     * @param int $province_id شناسه استان
     * @return array|WP_Error
     */
    public function refresh_cities_by_province( $province_id ) {
        $this->maybe_create_tables();

        $province_id = absint( $province_id );

        if ( $province_id <= 0 ) {
            return new WP_Error( 'invalid_province', __( 'شناسه استان نامعتبر است.', 'surenapost' ) );
        }

        $cities = $this->fetch_cities_from_api( $province_id );
        if ( is_wp_error( $cities ) ) {
            return $cities;
        }

        return $this->save_cities( $province_id, $cities );
    }

    /**
     * بروزرسانی کامل استان‌ها و شهرها
     *
     * @return array|WP_Error
     */
    public function refresh_all() {
        $this->maybe_create_tables();

        $provinces = $this->fetch_provinces_from_api();
        if ( is_wp_error( $provinces ) ) {
            return $provinces;
        }

        if ( empty( $provinces ) || ! is_array( $provinces ) ) {
            return new WP_Error(
                'empty_provinces',
                __( 'لیست استان‌ها خالی است یا از پاسخ API چیزی استخراج نشد.', 'surenapost' )
            );
        }

        $province_result = $this->save_provinces( $provinces );
        if ( is_wp_error( $province_result ) ) {
            return $province_result;
        }

        $results = array(
            'provinces_total'    => count( $provinces ), // تعداد بررسی شده از API
            'provinces_inserted' => isset( $province_result['inserted'] ) ? (int) $province_result['inserted'] : 0,
            'provinces_updated'  => isset( $province_result['updated'] ) ? (int) $province_result['updated'] : 0,
            'cities_total'       => 0, // تعداد بررسی شده از API
            'cities_inserted'    => 0,
            'cities_updated'     => 0,
            'errors'             => array(),
        );

        foreach ( $provinces as $province ) {
            if ( ! isset( $province['id'] ) ) {
                continue;
            }

            $province_id   = absint( $province['id'] );
            $province_name = isset( $province['name'] ) ? $province['name'] : $province_id;

            if ( $province_id <= 0 ) {
                continue;
            }

            $cities = $this->fetch_cities_from_api( $province_id );

            if ( is_wp_error( $cities ) ) {
                $results['errors'][] = sprintf(
                    __( 'خطا در دریافت شهرهای استان %s', 'surenapost' ),
                    $province_name
                );
                continue;
            }

            $city_result = $this->save_cities( $province_id, $cities );

            if ( is_wp_error( $city_result ) ) {
                $results['errors'][] = sprintf(
                    __( 'خطا در ذخیره شهرهای استان %s', 'surenapost' ),
                    $province_name
                );
                continue;
            }

            $results['cities_total']    += count( $cities );
            $results['cities_inserted'] += isset( $city_result['inserted'] ) ? (int) $city_result['inserted'] : 0;
            $results['cities_updated']  += isset( $city_result['updated'] ) ? (int) $city_result['updated'] : 0;
        }

        update_option( 'surenapost_locations_last_refresh', current_time( 'mysql' ), false );

        // شمارش واقعی موجود در دیتابیس
        $results['db_provinces_count'] = $this->count_provinces();
        $results['db_cities_count']    = $this->count_cities();

        return $results;
    }

public function handle_refresh_locations_submit() {
	error_log( 'RUNNING: ' . __CLASS__ . '::' . __FUNCTION__ );

	if ( ! is_admin() ) {
		return;
	}

	if ( ! isset( $_POST['surenapost_refresh_locations_submit'] ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
	}

	check_admin_referer( 'surenapost_refresh_locations_action', 'surenapost_refresh_locations_nonce' );

	$result = $this->refresh_all();

	$redirect_url = add_query_arg(
		array(
			'page' => 'surenapost',
			'tab'  => 'update',
		),
		admin_url( 'admin.php' )
	);

	if ( is_wp_error( $result ) ) {
		$redirect_url = add_query_arg(
			array(
				'surenapost_locations_updated' => '0',
				'surenapost_locations_message' => rawurlencode( $result->get_error_message() ),
			),
			$redirect_url
		);

		error_log( 'SURENAPOST REDIRECT URL: ' . $redirect_url );
		wp_safe_redirect( $redirect_url );
		exit;
	}

	$message = sprintf(
		'بروزرسانی با موفقیت انجام شد. %1$s استان از API بررسی شد، %2$s استان جدید اضافه شد، %3$s استان بروزرسانی شد، %4$s شهر از API بررسی شد، %5$s شهر جدید اضافه شد، %6$s شهر بروزرسانی شد.',
		isset( $result['provinces_total'] ) ? (int) $result['provinces_total'] : 0,
		isset( $result['provinces_inserted'] ) ? (int) $result['provinces_inserted'] : 0,
		isset( $result['provinces_updated'] ) ? (int) $result['provinces_updated'] : 0,
		isset( $result['cities_total'] ) ? (int) $result['cities_total'] : 0,
		isset( $result['cities_inserted'] ) ? (int) $result['cities_inserted'] : 0,
		isset( $result['cities_updated'] ) ? (int) $result['cities_updated'] : 0
	);

	$redirect_url = add_query_arg(
		array(
			'surenapost_locations_updated' => '1',
			'surenapost_locations_message' => rawurlencode( $message ),
		),
		$redirect_url
	);

	error_log( 'SURENAPOST REDIRECT URL: ' . $redirect_url );
	wp_safe_redirect( $redirect_url );
	exit;
}


/**
     * پاک کردن همه داده‌های استان و شهر
     *
     * @return bool
     */
    public function clear_all_data() {
        global $wpdb;

        $this->maybe_create_tables();

        $wpdb->query( "TRUNCATE TABLE {$this->cities_table}" );
        $wpdb->query( "TRUNCATE TABLE {$this->provinces_table}" );

        delete_option( 'surenapost_locations_last_refresh' );

        return true;
    }

    /**
     * برای سازگاری با نام قبلی
     *
     * @return bool
     */
    public function clear_all_cache() {
        return $this->clear_all_data();
    }

    /**
     * زمان آخرین بروزرسانی
     *
     * @return string
     */
    public function get_last_refresh_time() {
        return (string) get_option( 'surenapost_locations_last_refresh', '' );
    }

    public function count_provinces() {
        global $wpdb;

        $this->maybe_create_tables();

        return (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT api_id) FROM {$this->provinces_table}"
        );
    }

    /**
     * تعداد شهرها
     *
     * @return int
     */
    public function count_cities() {
        global $wpdb;

        $this->maybe_create_tables();

        return (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT api_id) FROM {$this->cities_table}"
        );
    }
}
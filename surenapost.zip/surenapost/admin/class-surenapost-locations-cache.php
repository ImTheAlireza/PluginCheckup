<?php
/**
 * کلاس مدیریت کش استان‌ها و شهرها
 *
 * مسئولیت ذخیره و بازیابی سریع اطلاعات استان‌ها و شهرها از API
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس مدیریت کش استان‌ها و شهرها
 */
class Surenapost_Locations_Cache {

	/**
	 * نام transient برای کش استان‌ها
	 *
	 * @var string
	 */
	private $provinces_transient = 'surenapost_provinces_cache';

	/**
	 * نام option برای ذخیره دائمی استان‌ها
	 *
	 * @var string
	 */
	private $provinces_option = 'surenapost_provinces_data';

	/**
	 * نام transient برای کش شهرها (با province_id)
	 *
	 * @var string
	 */
	private $cities_transient_prefix = 'surenapost_cities_cache_';

	/**
	 * نام option برای ذخیره دائمی شهرها
	 *
	 * @var string
	 */
	private $cities_option_prefix = 'surenapost_cities_data_';

	/**
	 * زمان انقضای کش (به ثانیه) - 7 روز
	 *
	 * @var int
	 */
	private $cache_expiration = 604800; // 7 * 24 * 60 * 60

	/**
	 * سازنده کلاس
	 */
	public function __construct() {
		// متدها از طریق کلاس‌های دیگر فراخوانی می‌شوند
	}

	/**
	 * دریافت لیست استان‌ها (از کش یا API)
	 *
	 * @param bool $force_refresh اگر true باشد، از API دریافت می‌کند و کش را بروزرسانی می‌کند
	 * @return array|WP_Error آرایه استان‌ها یا خطا
	 */
	public function get_provinces( $force_refresh = false ) {
		// اگر force_refresh نباشد، ابتدا از transient بررسی می‌کنیم
		if ( ! $force_refresh ) {
			$cached = get_transient( $this->provinces_transient );
			if ( false !== $cached && is_array( $cached ) ) {
				return $cached;
			}

			// اگر transient منقضی شده، از option بررسی می‌کنیم
			$stored = get_option( $this->provinces_option, false );
			if ( false !== $stored && is_array( $stored ) && ! empty( $stored ) ) {
				// کش را دوباره تنظیم می‌کنیم
				set_transient( $this->provinces_transient, $stored, $this->cache_expiration );
				return $stored;
			}
		}

		// دریافت از API
		$api_manager = new Surenapost_Api_Manager();
		$token       = $api_manager->get_api_key();

		if ( empty( $token ) ) {
			return new WP_Error( 'no_api_key', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$response = wp_remote_get(
			'https://post-api.sourena.shop/api/dependency/provinces',
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error( 'api_error', __( 'پاسخ نامعتبر از سرور دریافت شد.', 'surenapost' ) );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'invalid_data', __( 'امکان خواندن اطلاعات استان‌ها وجود ندارد.', 'surenapost' ) );
		}

		// ذخیره در transient و option
		$this->save_provinces( $data );

		return $data;
	}

	/**
	 * ذخیره لیست استان‌ها در کش و option
	 *
	 * @param array $provinces آرایه استان‌ها
	 * @return bool
	 */
	public function save_provinces( $provinces ) {
		if ( ! is_array( $provinces ) ) {
			return false;
		}

		// ذخیره در transient (کش موقت)
		set_transient( $this->provinces_transient, $provinces, $this->cache_expiration );

		// ذخیره در option (ذخیره دائمی)
		update_option( $this->provinces_option, $provinces );

		return true;
	}

	/**
	 * دریافت لیست شهرها بر اساس استان (از کش یا API)
	 *
	 * @param int  $province_id شناسه استان
	 * @param bool $force_refresh اگر true باشد، از API دریافت می‌کند و کش را بروزرسانی می‌کند
	 * @return array|WP_Error آرایه شهرها یا خطا
	 */
	public function get_cities( $province_id, $force_refresh = false ) {
		if ( $province_id <= 0 ) {
			return new WP_Error( 'invalid_province', __( 'شناسه استان نامعتبر است.', 'surenapost' ) );
		}

		$transient_key = $this->cities_transient_prefix . $province_id;
		$option_key    = $this->cities_option_prefix . $province_id;

		// اگر force_refresh نباشد، ابتدا از transient بررسی می‌کنیم
		if ( ! $force_refresh ) {
			$cached = get_transient( $transient_key );
			if ( false !== $cached && is_array( $cached ) ) {
				return $cached;
			}

			// اگر transient منقضی شده، از option بررسی می‌کنیم
			$stored = get_option( $option_key, false );
			if ( false !== $stored && is_array( $stored ) && ! empty( $stored ) ) {
				// کش را دوباره تنظیم می‌کنیم
				set_transient( $transient_key, $stored, $this->cache_expiration );
				return $stored;
			}
		}

		// دریافت از API
		$api_manager = new Surenapost_Api_Manager();
		$token       = $api_manager->get_api_key();

		if ( empty( $token ) ) {
			return new WP_Error( 'no_api_key', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$response = wp_remote_get(
			add_query_arg(
				array( 'province_id' => $province_id ),
				'https://post-api.sourena.shop/api/dependency/cities'
			),
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error( 'api_error', __( 'پاسخ نامعتبر از سرور دریافت شد.', 'surenapost' ) );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'invalid_data', __( 'امکان خواندن اطلاعات شهرها وجود ندارد.', 'surenapost' ) );
		}

		// ذخیره در transient و option
		$this->save_cities( $province_id, $data );

		return $data;
	}

	/**
	 * ذخیره لیست شهرها در کش و option
	 *
	 * @param int   $province_id شناسه استان
	 * @param array $cities      آرایه شهرها
	 * @return bool
	 */
	public function save_cities( $province_id, $cities ) {
		if ( $province_id <= 0 || ! is_array( $cities ) ) {
			return false;
		}

		$transient_key = $this->cities_transient_prefix . $province_id;
		$option_key    = $this->cities_option_prefix . $province_id;

		// ذخیره در transient (کش موقت)
		set_transient( $transient_key, $cities, $this->cache_expiration );

		// ذخیره در option (ذخیره دائمی)
		update_option( $option_key, $cities );

		return true;
	}

	/**
	 * پاک کردن تمام کش‌های استان‌ها و شهرها
	 *
	 * @return bool
	 */
	public function clear_all_cache() {
		// پاک کردن transient استان‌ها
		delete_transient( $this->provinces_transient );

		// پاک کردن option استان‌ها (دیتای دائمی)
		delete_option( $this->provinces_option );

		// پاک کردن transient و option شهرها (برای تمام استان‌ها)
		global $wpdb;

		// حذف تمام transient های مرتبط با شهرها
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . $this->cities_transient_prefix ) . '%',
				$wpdb->esc_like( '_transient_timeout_' . $this->cities_transient_prefix ) . '%'
			)
		);

		// حذف تمام option های دائمی مرتبط با شهرها
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( $this->cities_option_prefix ) . '%'
			)
		);

		return true;
	}

	/**
	 * پاک کردن کش شهرهای یک استان خاص
	 *
	 * @param int $province_id شناسه استان
	 * @return bool
	 */
	public function clear_cities_cache( $province_id ) {
		if ( $province_id <= 0 ) {
			return false;
		}

		$transient_key = $this->cities_transient_prefix . $province_id;
		delete_transient( $transient_key );

		return true;
	}

	/**
	 * بروزرسانی دستی تمام داده‌ها از API
	 *
	 * @return array|WP_Error نتیجه بروزرسانی
	 */
	public function refresh_all() {
		// دریافت استان‌ها
		$provinces = $this->get_provinces( true );
		if ( is_wp_error( $provinces ) ) {
			return $provinces;
		}

		// دریافت شهرهای هر استان
		$results = array(
			'provinces' => count( $provinces ),
			'cities'    => 0,
			'errors'    => array(),
		);

		if ( is_array( $provinces ) ) {
			foreach ( $provinces as $province ) {
				if ( isset( $province['id'] ) ) {
					$cities = $this->get_cities( intval( $province['id'] ), true );
					if ( ! is_wp_error( $cities ) && is_array( $cities ) ) {
						$results['cities'] += count( $cities );
					} else {
						$results['errors'][] = sprintf(
							__( 'خطا در دریافت شهرهای استان %s', 'surenapost' ),
							isset( $province['name'] ) ? $province['name'] : $province['id']
						);
					}
				}
			}
		}

		return $results;
	}

	/**
	 * دریافت زمان انقضای کش
	 *
	 * @return int زمان انقضا به ثانیه
	 */
	public function get_cache_expiration() {
		return $this->cache_expiration;
	}

	/**
	 * تنظیم زمان انقضای کش
	 *
	 * @param int $seconds زمان انقضا به ثانیه
	 * @return void
	 */
	public function set_cache_expiration( $seconds ) {
		$this->cache_expiration = absint( $seconds );
	}
}


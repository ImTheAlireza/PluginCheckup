<?php
/**
 * کلاینت پرداخت‌های سورناپست
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * کلاس کلاینت پرداخت‌ها
 */
class Surenapost_Payments_Client {

    /**
     * آدرس API پرداخت‌ها
     *
     * @var string
     */
    private $payments_endpoint = 'https://post-api.sourena.shop/api/wallet/payments';

    /**
     * آدرس API گزینه‌های درگاه پرداخت
     *
     * @var string
     */
    private $gateways_endpoint = 'https://post-api.sourena.shop/api/wallet/gateways';

    /**
     * آدرس API گزینه‌های وضعیت پرداخت
     *
     * @var string
     */
    private $statuses_endpoint = 'https://post-api.sourena.shop/api/wallet/statuses';

    /**
     * آدرس API وابستگی‌های پرداخت
     *
     * @var string
     */
    private $dependencies_endpoint = 'https://post-api.sourena.shop/api/wallet/payments/dependency';

    /**
     * زمان تایم‌اوت درخواست
     *
     * @var int
     */
    private $timeout = 30;

    /**
     * دریافت لیست پرداخت‌ها
     *
     * @param string $token      توکن API
     * @param array  $params     پارامترهای فیلتر
     * @return array|WP_Error
     */
    public function fetch_payments( $token, $params = array() ) {
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        // ساخت URL با پارامترها
        $url = $this->payments_endpoint;
        $query_params = array();

        // صفحه‌بندی
        if ( isset( $params['page'] ) && is_numeric( $params['page'] ) ) {
            $query_params['page'] = absint( $params['page'] );
        } else {
            $query_params['page'] = 1;
        }

        // تعداد آیتم در هر صفحه
        if ( isset( $params['per_page'] ) && is_numeric( $params['per_page'] ) ) {
            $query_params['per_page'] = absint( $params['per_page'] );
        } else {
            $query_params['per_page'] = 10;
        }

        // فیلتر شناسه پرداخت
        if ( ! empty( $params['payment_id'] ) ) {
            $query_params['payment_id'] = sanitize_text_field( $params['payment_id'] );
        }

        // فیلتر تاریخ شروع
        if ( ! empty( $params['start_date'] ) ) {
            $query_params['start_date'] = sanitize_text_field( $params['start_date'] );
        }

        // فیلتر تاریخ پایان
        if ( ! empty( $params['end_date'] ) ) {
            $query_params['end_date'] = sanitize_text_field( $params['end_date'] );
        }

        // فیلتر درگاه پرداخت
        if ( ! empty( $params['gateway'] ) ) {
            $query_params['gateway'] = sanitize_text_field( $params['gateway'] );
        }

        // فیلتر وضعیت
        if ( ! empty( $params['status'] ) ) {
            $query_params['status'] = sanitize_text_field( $params['status'] );
        }

        // اضافه کردن query string به URL
        if ( ! empty( $query_params ) ) {
            $url = add_query_arg( $query_params, $url );
        }

        $response = wp_remote_get(
            $url,
            array(
                'timeout' => $this->timeout,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept'        => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
        }

        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_error', json_last_error_msg() );
        }

        return $data;
    }

    /**
     * دریافت لیست درگاه‌های پرداخت
     *
     * @param string $token توکن API
     * @return array|WP_Error
     */
    public function fetch_gateways( $token ) {
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $response = wp_remote_get(
            $this->gateways_endpoint,
            array(
                'timeout' => $this->timeout,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept'        => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            // در صورت خطا، لیست پیش‌فرض را برمی‌گردانیم
            return $this->get_default_gateways();
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return $this->get_default_gateways();
        }

        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return $this->get_default_gateways();
        }

        // اگر داده از API دریافت شد، آن را برمی‌گردانیم
        if ( isset( $data['output'] ) && is_array( $data['output'] ) ) {
            return $data['output'];
        }

        return $this->get_default_gateways();
    }

    /**
     * دریافت لیست وضعیت‌های پرداخت
     *
     * @param string $token توکن API
     * @return array|WP_Error
     */
    public function fetch_statuses( $token ) {
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $response = wp_remote_get(
            $this->statuses_endpoint,
            array(
                'timeout' => $this->timeout,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept'        => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $this->get_default_statuses();
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return $this->get_default_statuses();
        }

        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return $this->get_default_statuses();
        }

        // اگر داده از API دریافت شد، آن را برمی‌گردانیم
        if ( isset( $data['output'] ) && is_array( $data['output'] ) ) {
            return $data['output'];
        }

        return $this->get_default_statuses();
    }

    /**
     * دریافت لیست پیش‌فرض درگاه‌های پرداخت
     *
     * @return array
     */
    private function get_default_gateways() {
        return array(
            'saman'     => __( 'سامان', 'surenapost' ),
            'zarinpal'  => __( 'زرین‌پال', 'surenapost' ),
            'mellat'    => __( 'ملت', 'surenapost' ),
            'parsian'   => __( 'پارسیان', 'surenapost' ),
        );
    }

    /**
     * دریافت لیست پیش‌فرض وضعیت‌های پرداخت
     *
     * @return array
     */
    private function get_default_statuses() {
        return array(
            'pending'   => __( 'در انتظار', 'surenapost' ),
            'completed' => __( 'تکمیل شده', 'surenapost' ),
            'failed'    => __( 'ناموفق', 'surenapost' ),
            'cancelled' => __( 'لغو شده', 'surenapost' ),
        );
    }

    /**
     * دریافت وابستگی‌های لیست پرداخت (درگاه‌ها و وضعیت‌ها)
     *
     * @param string $token توکن API
     * @return array|WP_Error
     */
    public function fetch_dependencies( $token ) {
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $response = wp_remote_get(
            $this->dependencies_endpoint,
            array(
                'timeout' => $this->timeout,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept'        => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
        }

        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_error', json_last_error_msg() );
        }

        // پردازش داده‌های دریافتی
        $result = array(
            'gateways' => array(),
            'statuses' => array(),
        );

        // استخراج gateway ها
        if ( isset( $data['output']['gateway'] ) && is_array( $data['output']['gateway'] ) ) {
            foreach ( $data['output']['gateway'] as $gateway ) {
                if ( isset( $gateway['value'] ) && isset( $gateway['label'] ) ) {
                    $result['gateways'][ $gateway['value'] ] = $gateway['label'];
                }
            }
        } elseif ( isset( $data['gateway'] ) && is_array( $data['gateway'] ) ) {
            foreach ( $data['gateway'] as $gateway ) {
                if ( isset( $gateway['value'] ) && isset( $gateway['label'] ) ) {
                    $result['gateways'][ $gateway['value'] ] = $gateway['label'];
                }
            }
        }

        // استخراج status ها
        if ( isset( $data['output']['status'] ) && is_array( $data['output']['status'] ) ) {
            foreach ( $data['output']['status'] as $status ) {
                if ( isset( $status['value'] ) && isset( $status['label'] ) ) {
                    $result['statuses'][ $status['value'] ] = $status['label'];
                }
            }
        } elseif ( isset( $data['status'] ) && is_array( $data['status'] ) ) {
            foreach ( $data['status'] as $status ) {
                if ( isset( $status['value'] ) && isset( $status['label'] ) ) {
                    $result['statuses'][ $status['value'] ] = $status['label'];
                }
            }
        }

        // در صورت خالی بودن، از مقادیر پیش‌فرض استفاده می‌کنیم
        if ( empty( $result['gateways'] ) ) {
            $result['gateways'] = $this->get_default_gateways();
        }

        if ( empty( $result['statuses'] ) ) {
            $result['statuses'] = $this->get_default_statuses();
        }

        return $result;
    }
}

<?php



/**
 * Plugin Name: Surenapost Wallet
 * Description: افزایش اعتبار کیف پول با درگاه سپ
 * Version: 1.0
 * Author: You
 */
defined('ABSPATH') || exit;

$api_manager   = new Surenapost_Api_Manager();
global $api_key;
$api_key     = $api_manager->get_api_key();

//var_dump($api_key); // باید مقدار درست را نمایش دهد
// 3️⃣ ثبت اکشن AJAX
add_action('wp_ajax_increase_wallet', 'surenapost_ajax_increase_wallet');

function surenapost_ajax_increase_wallet() {
    // بررسی nonce برای جلوگیری از CSRF
    check_ajax_referer( 'surenapost_admin_nonce', 'nonce' );

    // فقط مدیر فروشگاه یا مدیر کل
    if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( __( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
    }

    global $api_key; // اینجا متغیر global را فراخوانی می‌کنیم
    $amount = intval( $_POST['amount'] ?? 0 );
    if ( $amount <= 0 ) wp_send_json_error('مبلغ نامعتبر است.');

    $token = $api_key;
    if ( empty($token) ) wp_send_json_error('توکن API تنظیم نشده است.1'.$api_key);

    $client = new Surenapost_Wallet_Client();
    $result = $client->increase_wallet($token, $amount);

    if ( is_wp_error($result) ) wp_send_json_error($result->get_error_message());

    wp_send_json_success($result);
}



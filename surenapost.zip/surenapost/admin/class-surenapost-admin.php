<?php
/**
 * کلاس Admin
 *
 * مسئولیت مدیریت بخش ادمین پلاگین
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * کلاس Admin
 */
class Surenapost_Admin {

    /**
     * نام پلاگین
     *
     * @var string
     */
    private $plugin_name;

    /**
     * نسخه پلاگین
     *
     * @var string
     */
    private $version;

    /**
     * سرویس مشترک سفارش‌ها.
     *
     * @var Surenapost_Order_Service
     */
    private $order_service;

    /**
     * سازنده کلاس
     *
     * @param string $plugin_name نام پلاگین
     * @param string $version     نسخه پلاگین
     */
    public function __construct( $plugin_name, $version, $order_service = null ) {
        $this->plugin_name   = $plugin_name;
        $this->version       = $version;
        $this->order_service = $order_service instanceof Surenapost_Order_Service
            ? $order_service
            : new Surenapost_Order_Service();
    }
    /**
     * آیا صفحه جاری یکی از صفحات لیست یا جزئیات سفارش ووکامرس است؟
     *
     * @param WP_Screen|null $screen صفحه جاری.
     * @return bool
     */
    private function is_order_admin_screen( $screen ) {
        if ( ! $screen || ! isset( $screen->id ) ) {
            return false;
        }

        if ( in_array( $screen->id, array( 'edit-shop_order', 'shop_order', 'woocommerce_page_wc-orders' ), true ) ) {
            return true;
        }

        return isset( $screen->post_type ) && 'shop_order' === $screen->post_type;
    }

    private function get_print_url( $order_id ) {
        return wp_nonce_url(
            add_query_arg(
                array(
                    'action'   => 'surenapost_print_label',
                    'order_id' => absint( $order_id ),
                ),
                admin_url( 'admin-post.php' )
            ),
            'surenapost_print_label_' . absint( $order_id )
        );
    }

    /**
     * بارگذاری استایل‌های ادمین
     */
    public function enqueue_styles() {
        $screen = get_current_screen();

        if ( ! $screen || ! isset( $screen->id ) ) {
            return;
        }

        if ( false === strpos( $screen->id, 'surenapost' ) && ! $this->is_order_admin_screen( $screen ) ) {
            return;
        }

        wp_enqueue_style(
            $this->plugin_name,
            SURENAPOST_PLUGIN_URL . 'admin/css/surenapost-admin.css',
            array(),
            $this->version,
            'all'
        );

        $select2_css = SURENAPOST_PLUGIN_DIR . 'admin/css/select2.min.css';
        if ( file_exists( $select2_css ) ) {
            wp_enqueue_style(
                'surenapost-select2',
                SURENAPOST_PLUGIN_URL . 'admin/css/select2.min.css',
                array(),
                '4.1.0-rc.0'
            );
        }
    }
    function surenapost_register_print_assets() {
        wp_register_script(
            'surenapost-jsbarcode',
            SURENAPOST_PLUGIN_URL . 'admin/js/JsBarcode.all.min.js',
            array(),
            '3.11.6',
            false
        );

        wp_register_script(
            'surenapost-qrcode',
            SURENAPOST_PLUGIN_URL . 'admin/js/qrcode.js',
            array(),
            '1.0.0',
            false
        );
    }
    /**
     * بارگذاری اسکریپت‌های ادمین
     */
    public function enqueue_scripts() {
        $screen = get_current_screen();

        if ( ! $screen || ! isset( $screen->id ) ) {
            return;
        }

        if ( false === strpos( $screen->id, 'surenapost' ) && ! $this->is_order_admin_screen( $screen ) ) {
            return;
        }

        wp_enqueue_script(
            $this->plugin_name,
            SURENAPOST_PLUGIN_URL . 'admin/js/surenapost-admin.js',
            array( 'jquery' ),
            $this->version,
            false
        );

        $select2_deps = array( 'jquery', $this->plugin_name );
        $select2_js   = SURENAPOST_PLUGIN_DIR . 'admin/js/select2.min.js';

        if ( file_exists( $select2_js ) ) {
            wp_enqueue_script(
                'surenapost-select2',
                SURENAPOST_PLUGIN_URL . 'admin/js/select2.min.js',
                array( 'jquery' ),
                '4.1.0-rc.0',
                true
            );
            $select2_deps[] = 'surenapost-select2';
        }

        if ( $this->is_order_admin_screen( $screen ) ) {
            wp_enqueue_script(
                'surenapost-admin-list',
                SURENAPOST_PLUGIN_URL . 'admin/js/surenapost-admin-list.js',
                $select2_deps,
                $this->version,
                true
            );
        }

        wp_localize_script(
            $this->plugin_name,
            'wallet_ajax',
            array(
                'ajax_url'      => admin_url( 'admin-ajax.php' ),
                'nonce'         => wp_create_nonce( 'surenapost_admin_nonce' ),
                'poll_interval' => 60000,
                'i18n'          => array(
                    'select_province' => __( 'استان را انتخاب کنید', 'surenapost' ),
                    'select_city'     => __( 'شهر را انتخاب کنید', 'surenapost' ),
                    'loading'         => __( 'در حال بارگذاری...', 'surenapost' ),
                    'error'           => __( 'خطا در ارتباط با سرور', 'surenapost' ),
                ),
            )
        );
    }

    /**
     * افزودن منوی ادمین
     */
    /**
     * نمایش صفحه چاپ
     */
    public function display_print_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
        }

        // غیرفعال کردن header و footer وردپرس
        define( 'IFRAME_REQUEST', true );

        // حذف تمام action ها و filter های وردپرس که ممکن است header/footer اضافه کنند
        remove_all_actions( 'admin_head' );
        remove_all_actions( 'admin_footer' );
        remove_all_actions( 'admin_notices' );
        remove_all_actions( 'all_admin_notices' );

        // بارگذاری template چاپ
        require_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-print.php';
        exit;
    }

    function surenapost_render_print_label() {
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
        }

        $order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;

        if ( ! $order_id ) {
            wp_die( esc_html__( 'شناسه سفارش نامعتبر است.', 'surenapost' ) );
        }

        check_admin_referer( 'surenapost_print_label_' . $order_id );

        if ( ! function_exists( 'wc_get_order' ) ) {
            wp_die( esc_html__( 'ووکامرس در دسترس نیست.', 'surenapost' ) );
        }

        $order = wc_get_order( $order_id );

        if ( ! $order instanceof WC_Order ) {
            wp_die( esc_html__( 'سفارش یافت نشد.', 'surenapost' ) );
        }

        /*
         * سفارش‌های قدیمی ممکن است بارکد داشته باشند اما جزئیات جدید چاپ
         * (QR واقعی، نوع سرویس و مبلغ پرداخت در محل) هنوز روی آن‌ها ذخیره نشده باشد.
         * پیش از چاپ، حداکثر هر شش ساعت یک بار وضعیت همان سفارش را همگام می‌کنیم.
         */
        $tracking_for_sync = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );
        $last_print_sync   = absint( $order->get_meta( '_surenapost_print_details_checked', true ) );
        $print_meta_keys   = array( '_surenapost_qr_code', '_surenapost_postType', '_surenapost_payTypeText' );
        $needs_print_sync  = false;

        foreach ( $print_meta_keys as $print_meta_key ) {
            if ( '' === trim( (string) $order->get_meta( $print_meta_key, true ) ) ) {
                $needs_print_sync = true;
                break;
            }
        }

        if ( strlen( $tracking_for_sync ) > 3 && $needs_print_sync && ( time() - $last_print_sync ) >= 6 * HOUR_IN_SECONDS ) {
            $order->update_meta_data( '_surenapost_print_details_checked', time() );
            $order->save();

            $sync_result = $this->order_service->refresh_order( $order_id, 'tracking' );
            if ( ! is_wp_error( $sync_result ) ) {
                $reloaded_order = wc_get_order( $order_id );
                if ( $reloaded_order instanceof WC_Order ) {
                    $order = $reloaded_order;
                }
            }
        }

        $base_location    = function_exists( 'wc_get_base_location' ) ? wc_get_base_location() : array( 'country' => '', 'state' => '' );
        $store_country    = ! empty( $base_location['country'] ) ? $base_location['country'] : '';
        $store_state_code = ! empty( $base_location['state'] ) ? $base_location['state'] : '';
        $store_states     = ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->get_states( $store_country ) : array();
        $store_state_name = isset( $store_states[ $store_state_code ] ) ? $store_states[ $store_state_code ] : $store_state_code;

        $tracking_code    = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );
        $province_name    = trim( (string) $order->get_meta( '_surenapost_province_name', true ) );
        $city_name        = trim( (string) $order->get_meta( '_surenapost_city_name', true ) );
        $weight           = trim( (string) $order->get_meta( '_surenapost_weight', true ) );
        $postage          = trim( (string) $order->get_meta( '_surenapost_postage', true ) );
        $insurance        = trim( (string) $order->get_meta( '_surenapost_insurance', true ) );
        $tax              = trim( (string) $order->get_meta( '_surenapost_tax', true ) );
        $total_price      = trim( (string) $order->get_meta( '_surenapost_totalPrice', true ) );
        $box_size         = trim( (string) $order->get_meta( '_surenapost_boxSizeId', true ) );
        $pay_type_label   = $this->get_order_pay_type_label( $order );
        $pay_type_text    = trim( (string) $order->get_meta( '_surenapost_payTypeText', true ) );
        $post_type        = trim( (string) $order->get_meta( '_surenapost_postType', true ) );
        $remote_date      = trim( (string) $order->get_meta( '_surenapost_remote_date', true ) );
        $remote_time      = trim( (string) $order->get_meta( '_surenapost_remote_time', true ) );
        $qr_code          = trim( (string) $order->get_meta( '_surenapost_qr_code', true ) );
        $saved_postcode   = trim( (string) $order->get_meta( '_surenapost_postcode', true ) );
        $tracking_time    = absint( $order->get_meta( '_surenapost_times', true ) );
        $api_settings = ( new Surenapost_Api_Manager() )->get_api_settings();
        $allowed_print_modes = array( 'a5_products', 'a6_products', 'a5_products_end', 'a6_products_end', 'a6_no_products', 'a5_no_products' );
        $requested_print_mode = isset( $_GET['print_mode'] ) ? sanitize_key( wp_unslash( $_GET['print_mode'] ) ) : '';
        $print_mode_confirmed = in_array( $requested_print_mode, $allowed_print_modes, true );
        $print_mode = $print_mode_confirmed
            ? $requested_print_mode
            : ( isset( $api_settings['print_mode'] ) ? sanitize_key( $api_settings['print_mode'] ) : 'a5_products' );

        if ( 'full' === $print_mode ) {
            $print_mode = 'a5_products';
        } elseif ( 'summary' === $print_mode ) {
            $print_mode = 'a6_no_products';
        }
        if ( ! in_array( $print_mode, $allowed_print_modes, true ) ) {
            $print_mode = 'a5_products';
        }

        if ( ! $tracking_time ) {
            $tracking_time = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : current_time( 'timestamp' );
        }

        $receiver_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
        $receiver_addr = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() );

        if ( '' === $receiver_name ) {
            $receiver_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
        }
        if ( '' === $receiver_addr ) {
            $receiver_addr = trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() );
        }
        if ( '' === $province_name ) {
            $province_name = trim( (string) $order->get_shipping_state() );
        }
        if ( '' === $city_name ) {
            $city_name = trim( (string) $order->get_shipping_city() );
        }

        $receiver_zip = $saved_postcode ? $saved_postcode : $order->get_shipping_postcode();
        if ( '' === trim( (string) $receiver_zip ) ) {
            $receiver_zip = $order->get_billing_postcode();
        }
        $shipping_phone = is_callable( array( $order, 'get_shipping_phone' ) ) ? $order->get_shipping_phone() : $order->get_meta( '_shipping_phone', true );
        $receiver_tel   = $order->get_billing_phone() ? $order->get_billing_phone() : $shipping_phone;

        $print_date = '' !== $remote_date ? $remote_date : $this->format_print_date( 'Y/n/j', $tracking_time );
        $print_time = '' !== $remote_time ? $remote_time : $this->format_print_date( 'H:i', $tracking_time );

        if ( '' === $post_type && class_exists( 'Surenapost_Dependencies_Manager' ) ) {
            $post_service_id     = absint( $order->get_meta( '_surenapost_postServiceId', true ) );
            $dependency_manager  = new Surenapost_Dependencies_Manager();
            $post_type           = $dependency_manager->get_dependency_name( 'post-services', $post_service_id );
        }

        $products = array();
        foreach ( $order->get_items( 'line_item' ) as $item ) {
            $products[] = array(
                'name'     => is_callable( array( $item, 'get_name' ) ) ? $item->get_name() : '',
                'quantity' => is_callable( array( $item, 'get_quantity' ) ) ? $item->get_quantity() : 0,
            );
        }
        $print = array(
            'order_id'          => $order->get_id(),
            'tracking_code'     => $tracking_code,
            'province_name'     => $province_name,
            'city_name'         => $city_name,
            'weight'            => $weight,
            'postage'           => $postage,
            'insurance'         => $insurance,
            'tax'               => $tax,
            'total_price'       => $total_price,
            'pay_type_text'     => $pay_type_text,
            'box_size'          => $box_size,
            'pay_type'          => $pay_type_label,
            'post_type'         => $post_type,
            'print_date'        => $print_date,
            'print_time'        => $print_time,
            'print_mode'           => $print_mode,
            'print_mode_confirmed' => $print_mode_confirmed,
            'print_url'            => $this->get_print_url( $order_id ),
            'print_count_ajax_url' => admin_url( 'admin-ajax.php' ),
            'print_count_nonce'    => wp_create_nonce( 'surenapost_admin_nonce' ),
            'products'             => $products,

            'receiver_name'     => $receiver_name,
            'receiver_address'  => $receiver_addr,
            'receiver_postcode' => $receiver_zip,
            'receiver_mobile'   => $receiver_tel,

            'store_name'        => get_option( 'surenapost_sender_name', get_bloginfo( 'name' ) ),
            'store_url'         => home_url( '/' ),
            'store_address'     => get_option( 'surenapost_sender_address', get_option( 'woocommerce_store_address' ) ),
            'store_city'        => get_option( 'surenapost_sender_city', get_option( 'woocommerce_store_city' ) ),
            'store_state'       => get_option( 'surenapost_sender_state', $store_state_name ),
            'store_postcode'    => get_option( 'surenapost_sender_postcode', get_option( 'woocommerce_store_postcode' ) ),
            'store_phone'       => get_option( 'surenapost_sender_phone', get_option( 'woocommerce_store_phone' ) ),
            'plugin_url'        => SURENAPOST_PLUGIN_URL,
            'qr_text'           => '' !== $qr_code ? $qr_code : $tracking_code,
        );

        wp_enqueue_script( 'surenapost-jsbarcode' );
        wp_enqueue_script( 'surenapost-qrcode' );

        nocache_headers();
        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
        header( 'X-Robots-Tag: noindex, nofollow', true );

        include SURENAPOST_PLUGIN_DIR . 'admin/partials/print-label.php';
        exit;
    }


    /**
     * عنوان خوانای نوع پرداخت ثبت‌شده روی سفارش.
     * متن برگشتی API اولویت دارد و در صورت نبودن آن، نام وابستگی از کش پیدا می‌شود.
     *
     * @param WC_Order $order سفارش ووکامرس.
     * @return string
     */
    private function get_order_pay_type_label( $order ) {
        if ( ! $this->is_wc_order_object( $order ) ) {
            return '';
        }

        $label = trim( (string) $order->get_meta( '_surenapost_payType_label', true ) );
        if ( '' !== $label ) {
            return $label;
        }

        $pay_type_raw = $order->get_meta( '_surenapost_payType', true );
        if ( '' === trim( (string) $pay_type_raw ) || ! class_exists( 'Surenapost_Dependencies_Manager' ) ) {
            return '';
        }

        // مقدار صفر برای payType معتبر است و به «پرداخت در محل» اشاره می‌کند.
        $dependencies_manager = new Surenapost_Dependencies_Manager();
        return $dependencies_manager->get_dependency_name( 'payType', absint( $pay_type_raw ) );
    }

    /**
     * فرمت تاریخ چاپ
     * اگر کلاس Jdf داشتی از آن استفاده می‌کند، وگرنه wp_date
     */
    private function format_print_date( $format, $timestamp ) {
        if ( class_exists( 'Jdf' ) && method_exists( 'Jdf', 'jdate' ) ) {
            return Jdf::jdate( $format, $timestamp );
        }

        return wp_date( $format, $timestamp );
    }

    public function add_admin_menu() {
        add_menu_page(
            __( 'سورنا پست', 'surenapost' ),
            __( 'سورنا پست', 'surenapost' ),
            'manage_options',
            'surenapost',
            array( $this, 'display_admin_page' ),
            'dashicons-email-alt',
            30
        );

        // تب تنظیمات API
        add_submenu_page(
            'surenapost',
            __( 'تنظیمات API', 'surenapost' ),
            __( 'تنظیمات API', 'surenapost' ),
            'manage_options',
            'surenapost-api-settings',
            array( $this, 'display_api_settings_page' )
        );

        // تب داشبورد
        add_submenu_page(
            'surenapost',
            __( 'داشبورد', 'surenapost' ),
            __( 'داشبورد', 'surenapost' ),
            'manage_options',
            'surenapost',
            array( $this, 'display_admin_page' )
        );

        // راه‌اندازی اولیه
        add_submenu_page(
            'surenapost',
            __( 'راه‌اندازی اولیه', 'surenapost' ),
            __( 'راه‌اندازی اولیه', 'surenapost' ),
            'manage_options',
            'surenapost-setup',
            array( $this, 'display_setup_page' )
        );

        // صفحه چاپ (مخفی - فقط برای دسترسی مستقیم)
        add_submenu_page(
            null, // مخفی کردن از منو
            __( 'چاپ سفارش سورناپست', 'surenapost' ),
            __( 'چاپ', 'surenapost' ),
            'manage_woocommerce',
            'surenapost-print',
            array( $this, 'display_print_page' )
        );

        // تب گزارش‌ها
        add_submenu_page(
            'surenapost',
            __( 'گزارش‌ها', 'surenapost' ),
            __( 'گزارش‌ها', 'surenapost' ),
            'manage_options',
            'surenapost-reports',
            array( $this, 'display_reports_page' )
        );
        add_submenu_page(
            'surenapost',
            __( 'موجودی', 'surenapost' ),
            __( 'موجودی', 'surenapost' ),
            'manage_options',
            'surenapost-pay',
            array( $this, 'display_pay_page' )
        );

        // تب ریز تراکنش‌ها
        add_submenu_page(
            'surenapost',
            __( 'ریز تراکنش‌ها', 'surenapost' ),
            __( 'ریز تراکنش‌ها', 'surenapost' ),
            'manage_options',
            'surenapost-transactions',
            array( $this, 'display_transactions_page' )
        );
        add_submenu_page(
            'surenapost',
            __( 'لیست بارکدها  ', 'surenapost' ),
            __( 'لیست بارکدها  ', 'surenapost' ),
            'manage_options',
            'surenapost-tracking',
            array( $this, 'display_tracking_page' )
        );

        // تب بروزرسانی وابستگی‌ها
        add_submenu_page(
            'surenapost',
            __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'manage_options',
            'surenapost-update',
            array( $this, 'display_update_page' )
        );
    }


    /**
     * نمایش صفحه اصلی ادمین
     */
    public function display_admin_page() {
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'dashboard';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'لیست بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * نمایش صفحه راه‌اندازی اولیه
     */
    public function display_setup_page() {
        $current_tab = 'setup';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'setup'     => __( 'راه‌اندازی اولیه', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'       => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update'    => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking'  => __( 'لیست بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * نمایش صفحه تنظیمات API
     */
    public function display_api_settings_page() {
        $current_tab = 'api';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'tracking' => __( 'لیست بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * نمایش صفحه گزارش‌ها
     */
    public function display_reports_page() {
        $current_tab = 'reports';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }
    public function display_tracking_page() {
        $current_tab = 'tracking';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'لیست بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }
    public function display_pay_page() {
        $current_tab = 'pay';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * نمایش صفحه ریز تراکنش‌ها
     */
    public function display_transactions_page() {
        $current_tab = 'transactions';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * نمایش صفحه بروزرسانی وابستگی‌ها
     */
    public function display_update_page() {
        $current_tab = 'update';
        $tabs        = array(
            'dashboard' => __( 'داشبورد', 'surenapost' ),
            'api'       => __( 'تنظیمات API', 'surenapost' ),
            'reports'   => __( 'گزارش‌ها', 'surenapost' ),
            'pay'   => __( 'موجودی', 'surenapost' ),
            'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
            'update' => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
            'tracking' => __( 'بارکدها', 'surenapost' ),
        );

        include_once SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-admin-display.php';
    }

    /**
     * افزودن ستون سورنا پست به لیست سفارش‌ها
     *
     * @param array $columns
     *
     * @return array
     */
    public function add_surenapost_order_column( $columns ) {
        $new_columns = array();

        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;

            if ( 'order_status' === $key ) {
                // بعد از ستون وضعیت، ستون سورنا پست را اضافه می‌کنیم
                $new_columns['surenapost'] = __( 'سورنا پست', 'surenapost' );
            }
        }

        // اگر به هر دلیلی ستون اضافه نشد، در انتهای جدول اضافه شود
        if ( ! isset( $new_columns['surenapost'] ) ) {
            $new_columns['surenapost'] = __( 'سورنا پست', 'surenapost' );
        }

        return $new_columns;
    }

    /**
     * رندر ستون سورناپست در جدول قدیمی سفارش‌ها
     *
     * برای جلوگیری از تفاوت بین جدول قدیمی و HPOS،
     * خروجی هر دو جدول از یک تابع مشترک دریافت می‌شود.
     *
     * @param string $column  نام ستون
     * @param int    $post_id شناسه سفارش
     */
    public function render_surenapost_order_column( $column, $post_id ) {
        if ( 'surenapost' !== $column || ! function_exists( 'wc_get_order' ) ) {
            return;
        }

        $order = wc_get_order( $post_id );

        echo $order instanceof WC_Order ? $this->render_order_ui( $order, 'column' ) : '-'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    /**
     * افزودن ستون سورنا پست در جدول جدید سفارش‌ها (HPOS / wc-orders)
     *
     * @param array $columns
     *
     * @return array
     */
    public function add_surenapost_hpos_order_column( $columns ) {
        if ( ! isset( $columns['surenapost'] ) ) {
            $columns['surenapost'] = __( 'سورنا پست', 'surenapost' );
        }

        return $columns;
    }

    /**
     * رندر ستون سورنا پست در جدول جدید سفارش‌ها (HPOS / wc-orders)
     *
     * @param string   $column
     * @param WC_Order $order
     */
    public function render_surenapost_hpos_order_column( $column, $order ) {
        if ( 'surenapost' !== $column || ! $order instanceof WC_Order ) {
            return;
        }

        echo $this->render_order_ui( $order, 'column' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /**
     * AJAX: دریافت لیست استان‌ها از API سورنا (با استفاده از کش)
     */
    public function ajax_get_provinces() {
        $this->assert_admin_ajax_request();

        $locations_db = new Surenapost_Locations_DB();
        $provinces    = $locations_db->get_provinces( false );

        if ( is_wp_error( $provinces ) ) {
            wp_send_json_error( array(
                'message' => $provinces->get_error_message(),
            ) );
        }

        wp_send_json_success( $provinces );
    }
    /**
     * AJAX: دریافت لیست شهرها براساس استان انتخابی (با استفاده از کش)
     */
    public function ajax_get_cities() {
        $this->assert_admin_ajax_request();

        $province_id = isset( $_GET['province_id'] ) ? absint( wp_unslash( $_GET['province_id'] ) ) : 0;

        if ( $province_id <= 0 ) {
            wp_send_json_error( array(
                'message' => __( 'شناسه استان نامعتبر است.', 'surenapost' ),
            ) );
        }

        $locations_db = new Surenapost_Locations_DB();
        $cities       = $locations_db->get_cities( $province_id, false );

        if ( is_wp_error( $cities ) ) {
            wp_send_json_error( array(
                'message' => $cities->get_error_message(),
            ) );
        }

        wp_send_json_success( $cities );
    }
    /**
     * AJAX: ذخیره استان و شهر انتخابی برای یک سفارش
     */
    public function ajax_save_order_destination() {
        $this->assert_admin_ajax_request();

        $order_id        = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $province_id     = isset( $_POST['province_id'] ) ? absint( wp_unslash( $_POST['province_id'] ) ) : 0;
        $city_id         = isset( $_POST['city_id'] ) ? absint( wp_unslash( $_POST['city_id'] ) ) : 0;
        $province_name   = isset( $_POST['province_name'] ) ? sanitize_text_field( wp_unslash( $_POST['province_name'] ) ) : '';
        $city_name       = isset( $_POST['city_name'] ) ? sanitize_text_field( wp_unslash( $_POST['city_name'] ) ) : '';
        $post_service_id = isset( $_POST['post_service_id'] ) ? absint( wp_unslash( $_POST['post_service_id'] ) ) : 0;
        $packet_type     = isset( $_POST['packet_type'] ) ? absint( wp_unslash( $_POST['packet_type'] ) ) : 0;
        $box_size        = isset( $_POST['box_size'] ) ? absint( wp_unslash( $_POST['box_size'] ) ) : 0;
        $standard        = isset( $_POST['standard'] ) ? sanitize_text_field( wp_unslash( $_POST['standard'] ) ) : '0';
        $weight          = isset( $_POST['weight'] ) ? (float) wp_unslash( $_POST['weight'] ) : 0;
        $percel_value    = isset( $_POST['percel_value'] ) ? (float) wp_unslash( $_POST['percel_value'] ) : 0;
        $codeposti_get   = isset( $_POST['codeposti_get'] ) ? sanitize_text_field( wp_unslash( $_POST['codeposti_get'] ) ) : '';

        if ( $order_id <= 0 ) {
            wp_send_json_error( __( 'شناسه سفارش نامعتبر است.', 'surenapost' ) );
        }

        if ( $province_id <= 0 || $city_id <= 0 ) {
            wp_send_json_error( __( 'استان و شهر را انتخاب کنید.', 'surenapost' ) );
        }


        if ( $packet_type <= 0 ) {
            wp_send_json_error( __( 'نوع بسته را انتخاب کنید.', 'surenapost' ) );
        }

        if ( $box_size <= 0 ) {
            wp_send_json_error( __( 'سایز بسته را انتخاب کنید.', 'surenapost' ) );
        }

        if ( $weight <= 0 ) {
            wp_send_json_error( __( 'وزن کل را وارد کنید.', 'surenapost' ) );
        }

        if ( $percel_value < 0 ) {
            wp_send_json_error( __( 'ارزش کل مرسوله را وارد کنید.', 'surenapost' ) );
        }

        if ( ! function_exists( 'wc_get_order' ) ) {
            wp_send_json_error( __( 'ووکامرس در دسترس نیست.', 'surenapost' ) );
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            wp_send_json_error( __( 'سفارش یافت نشد.', 'surenapost' ) );
        }

        // ذخیره به عنوان متای سفارش (سازگار با HPOS و post meta)
        $order->update_meta_data( '_surenapost_province_id', $province_id );
        $order->update_meta_data( '_surenapost_city_id', $city_id );
        if ( $post_service_id > 0 ) {
            $order->update_meta_data( '_surenapost_post_service_id', $post_service_id );
        } else {
            // نوع ارسال پستی اختیاری است؛ انتخاب خالی نباید مقدار قبلی سفارش را نگه دارد.
            $order->delete_meta_data( '_surenapost_post_service_id' );
        }
        $order->update_meta_data( '_surenapost_packet_type', $packet_type );
        $order->update_meta_data( '_surenapost_box_size', $box_size );
        $order->update_meta_data( '_surenapost_standard', $standard );
        $order->update_meta_data( '_surenapost_weight', $weight );
        $order->update_meta_data( '_surenapost_percel_value', $percel_value );
        $order->update_meta_data( '_surenapost_postcode', $codeposti_get );

        if ( $province_name ) {
            $order->update_meta_data( '_surenapost_province_name', $province_name );
        }

        if ( $city_name ) {
            $order->update_meta_data( '_surenapost_city_name', $city_name );
        }

        $order->save();

        wp_send_json_success(
            array(
                'message'        => __( 'اطلاعات سفارش با موفقیت ذخیره شد.', 'surenapost' ),
                'order_id'       => $order_id,
                'province_id'    => $province_id,
                'city_id'        => $city_id,
                'province_name'  => $province_name,
                'city_name'      => $city_name,
            )
        );
    }

    /**
     * AJAX: بروزرسانی دستی کش استان‌ها و شهرها
     */
    public function ajax_refresh_locations_cache() {
        $this->assert_admin_ajax_request();

        $cache_manager = new Surenapost_Locations_Cache();
        $result        = $cache_manager->refresh_all();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success(
            array(
                'message'  => __( 'کش استان‌ها و شهرها با موفقیت بروزرسانی شد.', 'surenapost' ),
                'provinces' => $result['provinces'],
                'cities'    => $result['cities'],
                'errors'    => $result['errors'],
            )
        );
    }

    /**
     * AJAX: پاک کردن کش استان‌ها و شهرها
     */
    public function ajax_clear_locations_cache() {
        $this->assert_admin_ajax_request();

        $cache_manager = new Surenapost_Locations_Cache();
        $cleared       = $cache_manager->clear_all_cache();

        if ( $cleared ) {
            wp_send_json_success( __( 'کش با موفقیت پاک شد.', 'surenapost' ) );
        } else {
            wp_send_json_error( __( 'خطا در پاک کردن کش.', 'surenapost' ) );
        }
    }

    /**
     * AJAX: دریافت وابستگی‌های سورنا پست برای استفاده در فرم
     */
    public function ajax_get_dependencies() {
        $this->assert_admin_ajax_request();

        $dependencies_manager = new Surenapost_Dependencies_Manager();

        $post_services = $dependencies_manager->get_dependency( 'post-services' );
        $packet_types  = $dependencies_manager->get_dependency( 'packet-types' );
        $box_sizes     = $dependencies_manager->get_dependency( 'box-sizes' );
        $pay_types     = $dependencies_manager->get_dependency( 'payType' );

        wp_send_json_success(
            array(
                'post_services' => false !== $post_services ? $post_services : array(),
                'packet_types'  => false !== $packet_types ? $packet_types : array(),
                'box_sizes'     => false !== $box_sizes ? $box_sizes : array(),
                'pay_types'     => false !== $pay_types ? $pay_types : array(),
            )
        );
    }

    /**
     * AJAX: دریافت اطلاعات سفارش (وزن و ارزش)
     */
    public function ajax_get_order_info() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;

        if ( $order_id <= 0 ) {
            wp_send_json_error( __( 'شناسه سفارش نامعتبر است.', 'surenapost' ) );
        }

        if ( ! function_exists( 'wc_get_order' ) ) {
            wp_send_json_error( __( 'ووکامرس در دسترس نیست.', 'surenapost' ) );
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            wp_send_json_error( __( 'سفارش یافت نشد.', 'surenapost' ) );
        }

        // محاسبه وزن کل (به گرم)
        $total_weight = 0;
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( $product && $product->has_weight() ) {
                $item_weight = wc_get_weight( $product->get_weight(), 'g' ) * $item->get_quantity();
                $total_weight += $item_weight;
            }
        }

        // ارزش کل مرسوله (جمع کل سفارش منهای هزینه حمل)
        $total_value = $order->get_total() - $order->get_shipping_total();

        wp_send_json_success(
            array(
                'weight' => round( $total_weight ),
                'value'    => round( $total_value ),
                'pay_type' => '' !== trim( (string) $order->get_meta( '_surenapost_payType', true ) )
                    ? (string) absint( $order->get_meta( '_surenapost_payType', true ) )
                    : '',
            )
        );
    }

    /**
     * AJAX: بروزرسانی وابستگی‌های سورنا پست
     */
    public function ajax_update_dependencies() {
        $this->assert_admin_ajax_request();

        // دریافت توکن API
        $api_manager = new Surenapost_Api_Manager();
        $token       = $api_manager->get_api_key();

        if ( empty( $token ) ) {
            wp_send_json_error( __( 'توکن API تنظیم نشده است. لطفاً ابتدا در تب «تنظیمات API» توکن سورنا پست را ذخیره کنید.', 'surenapost' ) );
        }

        // API جدید همه وابستگی‌ها را یکجا برمی‌گرداند و همگام‌سازی همیشه کامل است.
        $clear_existing = true;

        // بروزرسانی وابستگی‌ها
        $dependencies_manager = new Surenapost_Dependencies_Manager();
        $result               = $dependencies_manager->update_all_dependencies( $token, $clear_existing );

        if ( ! empty( $result['errors'] ) && empty( $result['details'] ) ) {
            // اگر همه خطا بودند
            wp_send_json_error(
                array(
                    'message' => __( 'خطا در بروزرسانی وابستگی‌ها', 'surenapost' ),
                    'errors'  => $result['errors'],
                )
            );
        } else {
            wp_send_json_success(
                array(
                    'message'        => __( 'بروزرسانی با موفقیت انجام شد.', 'surenapost' ),
                    'total_inserted' => $result['total_inserted'],
                    'total_skipped'  => $result['total_skipped'],
                    'details'        => $result['details'],
                    'errors'         => $result['errors'],
                )
            );
        }
    }

    /**
     * AJAX: ارسال سفارش به API سورناپست
     */
    public function ajax_send_order() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

        if ( ! $order instanceof WC_Order ) {
            wp_send_json_error( array( 'message' => __( 'سفارش یافت نشد.', 'surenapost' ) ) );
        }

        $input = array(
            'province_id'     => isset( $_POST['province_id'] ) ? absint( wp_unslash( $_POST['province_id'] ) ) : 0,
            'city_id'         => isset( $_POST['city_id'] ) ? absint( wp_unslash( $_POST['city_id'] ) ) : 0,
            'post_service_id' => isset( $_POST['post_service_id'] ) ? absint( wp_unslash( $_POST['post_service_id'] ) ) : 0,
            'packet_type'     => isset( $_POST['packet_type'] ) ? absint( wp_unslash( $_POST['packet_type'] ) ) : 0,
            'box_size'        => isset( $_POST['box_size'] ) ? absint( wp_unslash( $_POST['box_size'] ) ) : 0,
            // رشته خالی را از مقدار معتبر صفر جدا نگه می‌داریم.
            'pay_type'        => isset( $_POST['pay_type'] ) ? sanitize_text_field( wp_unslash( $_POST['pay_type'] ) ) : '',
            'standard'        => isset( $_POST['standard'] ) && '1' === (string) wp_unslash( $_POST['standard'] ),
            'weight'          => isset( $_POST['weight'] ) ? (float) wp_unslash( $_POST['weight'] ) : 0,
            'percel_value'    => isset( $_POST['percel_value'] ) ? (float) wp_unslash( $_POST['percel_value'] ) : 0,
            'codeposti_get'   => isset( $_POST['codeposti_get'] ) ? sanitize_text_field( wp_unslash( $_POST['codeposti_get'] ) ) : '',
            'mobile'          => isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '',
        );

        $result = $this->order_service->issue_order( $order, $input );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        $order = wc_get_order( $order_id );

        wp_send_json_success(
            array(
                'message'      => $result['message'],
                'tracking'     => $result['barcode'],
                'ui'           => $this->get_order_ui_payload( $order ),
            )
        );
    }
    /*
     * لغوبارکد:
     */
    public function ajax_suspend_barcode() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $result   = $this->order_service->suspend_barcode( $order_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        $order = wc_get_order( $order_id );

        wp_send_json_success(
            array(
                'message' => $result['message'],
                'ui'      => $this->get_order_ui_payload( $order ),
            )
        );
    }
    /**
     * AJAX: دریافت کد رهگیری
     */
    public function ajax_get_tracking() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $result   = $this->order_service->refresh_order( $order_id, 'tracking' );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        $order = wc_get_order( $order_id );
        $data  = array(
            'tracking' => $result['barcode'],
            'message'  => $result['message'],
            'status'   => $result['status_label'],
            'ui'       => $this->get_order_ui_payload( $order ),
        );

        if ( ! empty( $result['barcode'] ) ) {
            wp_send_json_success( $data );
        }

        wp_send_json_error( $data );
    }


    /**
     * AJAX: افزایش تعداد دفعات شروع عملیات چاپ سفارش.
     *
     * مرورگر نتیجه نهایی پنجره چاپ (Print یا Cancel) را در اختیار صفحه نمی‌گذارد؛
     * بنابراین شمارنده هنگام شروع هر چرخه چاپ افزایش داده می‌شود.
     */
    public function ajax_increment_print_count() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $order    = $order_id && function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

        if ( ! $order instanceof WC_Order ) {
            wp_send_json_error( array( 'message' => __( 'سفارش یافت نشد.', 'surenapost' ) ), 404 );
        }

        $print_count = absint( $order->get_meta( '_surenapost_print_count', true ) ) + 1;
        $order->update_meta_data( '_surenapost_print_count', $print_count );
        $order->save();

        wp_send_json_success(
            array(
                'count' => $print_count,
            )
        );
    }


    /**
     * افزودن metabox برای نمایش اطلاعات رهگیری
     */
    public function add_tracking_metabox() {
        // برای سیستم قدیمی
        add_meta_box(
            'surenapost_tracking_info',
            __( 'اطلاعات رهگیری سورناپست', 'surenapost' ),
            array( $this, 'display_tracking_metabox_content' ),
            'shop_order',
            'normal',
            'high'
        );

        // برای سیستم جدید HPOS؛ در ووکامرس‌های قدیمی ممکن است این تابع وجود نداشته باشد.
        if ( function_exists( 'wc_get_page_screen_id' ) ) {
            $screen = wc_get_page_screen_id( 'shop-order' );
            if ( $screen ) {
                add_meta_box(
                    'surenapost_tracking_info',
                    __( 'اطلاعات رهگیری سورناپست', 'surenapost' ),
                    array( $this, 'display_tracking_metabox_content_hpos' ),
                    $screen,
                    'normal',
                    'high'
                );
            }
        }
    }

    /**
     * محتوای metabox اطلاعات رهگیری در صفحه کلاسیک سفارش‌ها.
     *
     * نکته: بسته به نسخه ووکامرس، callback می‌تواند WP_Post یا خود سفارش را دریافت کند.
     * برای جلوگیری از نمایش باکس خالی، تبدیل context در یک تابع مشترک انجام می‌شود.
     *
     * @param WP_Post|WC_Abstract_Order|mixed $context اطلاعات صفحه جاری.
     */
    public function display_tracking_metabox_content( $context ) {
        $this->display_tracking_info_in_order_edit( $context );
    }

    /**
     * محتوای metabox اطلاعات رهگیری در صفحه HPOS سفارش‌ها.
     *
     * @param WP_Post|WC_Abstract_Order|mixed $context اطلاعات صفحه جاری.
     */
    public function display_tracking_metabox_content_hpos( $context ) {
        $this->display_tracking_info_in_order_edit( $context );
    }

    /**
     * آیا مقدار دریافت‌شده یک سفارش معتبر ووکامرس است؟
     *
     * WC_Abstract_Order به‌جای بررسی فقط WC_Order استفاده شده تا با کلاس‌های
     * توسعه‌یافته ووکامرس و افزونه‌های جانبی نیز سازگار باشد.
     *
     * @param mixed $order مقدار مورد بررسی.
     * @return bool
     */
    private function is_wc_order_object( $order ) {
        return is_object( $order ) && is_a( $order, 'WC_Abstract_Order' );
    }

    /**
     * پیدا کردن سفارش از context متاباکس، URL صفحه یا post جاری.
     *
     * این fallback برای سازگاری با صفحه کلاسیک post.php و صفحه جدید HPOS است.
     *
     * @param mixed $context اطلاعات callback متاباکس.
     * @return WC_Abstract_Order|false
     */
    private function resolve_order_from_admin_context( $context = null ) {
        if ( $this->is_wc_order_object( $context ) ) {
            return $context;
        }

        if ( ! function_exists( 'wc_get_order' ) ) {
            return false;
        }

        $order_id = 0;

        if ( is_numeric( $context ) ) {
            $order_id = absint( $context );
        } elseif ( is_object( $context ) ) {
            if ( isset( $context->ID ) ) {
                $order_id = absint( $context->ID );
            } elseif ( is_callable( array( $context, 'get_id' ) ) ) {
                $order_id = absint( $context->get_id() );
            }
        }

        // ساختار کلاسیک ووکامرس: wp-admin/post.php?post=123&action=edit
        if ( ! $order_id && isset( $_GET['post'] ) ) {
            $order_id = absint( wp_unslash( $_GET['post'] ) );
        }

        // ساختار HPOS ووکامرس: admin.php?page=wc-orders&action=edit&id=123
        if ( ! $order_id && isset( $_GET['id'] ) ) {
            $order_id = absint( wp_unslash( $_GET['id'] ) );
        }

        if ( ! $order_id && isset( $GLOBALS['post'] ) && is_object( $GLOBALS['post'] ) && isset( $GLOBALS['post']->ID ) ) {
            $order_id = absint( $GLOBALS['post']->ID );
        }

        if ( ! $order_id ) {
            return false;
        }

        $order = wc_get_order( $order_id );
        return $this->is_wc_order_object( $order ) ? $order : false;
    }

    /**
     * نمایش اطلاعات رهگیری سورناپست در صفحه ویرایش سفارش.
     *
     * @param WC_Abstract_Order|WP_Post|int|mixed $context اطلاعات سفارش یا صفحه.
     */
    public function display_tracking_info_in_order_edit( $context ) {
        $order = $this->resolve_order_from_admin_context( $context );

        if ( ! $this->is_wc_order_object( $order ) ) {
            echo '<div class="notice notice-error inline"><p>';
            echo esc_html__( 'اطلاعات سفارش برای نمایش پنل سورناپست پیدا نشد. صفحه را یک‌بار بروزرسانی کنید؛ اگر مشکل باقی ماند، شناسه سفارش را بررسی کنید.', 'surenapost' );
            echo '</p></div>';
            return;
        }

        echo $this->render_order_ui( $order, 'detail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    public function ajax_refresh_cancel_status() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $result   = $this->order_service->refresh_order( $order_id, 'cancel' );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        $order = wc_get_order( $order_id );

        wp_send_json_success(
            array(
                'message'      => $result['message'],
                'status_label' => $result['status_label'],
                'status_key'   => $result['status_key'],
                'barcode'      => $result['barcode'],
                'ui'           => $this->get_order_ui_payload( $order ),
            )
        );
    }

    /**
     * ثبت وضعیت کلی «ارسال شد» در ووکامرس.
     */
    public function register_surenapost_shipped_status() {
        register_post_status(
            Surenapost_Order_Service::WC_SHIPPED_POST_STATUS,
            array(
                'label'                     => __( 'ارسال شد', 'surenapost' ),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'ارسال شد <span class="count">(%s)</span>', 'ارسال شد <span class="count">(%s)</span>', 'surenapost' ),
            )
        );
    }

    /**
     * اضافه کردن وضعیت «ارسال شد» به فهرست وضعیت‌های سفارش ووکامرس.
     *
     * @param array $statuses وضعیت‌های ووکامرس.
     * @return array
     */
    public function add_surenapost_shipped_status( $statuses ) {
        $result = array();

        foreach ( $statuses as $key => $label ) {
            $result[ $key ] = $label;

            if ( 'wc-processing' === $key ) {
                $result[ Surenapost_Order_Service::WC_SHIPPED_POST_STATUS ] = __( 'ارسال شد', 'surenapost' );
            }
        }

        if ( ! isset( $result[ Surenapost_Order_Service::WC_SHIPPED_POST_STATUS ] ) ) {
            $result[ Surenapost_Order_Service::WC_SHIPPED_POST_STATUS ] = __( 'ارسال شد', 'surenapost' );
        }

        return $result;
    }

    /**
     * نمایش فیلتر وضعیت سورناپست در لیست سفارش‌ها.
     *
     * @param string $order_type نوع سفارش یا post type.
     * @param string $which      محل فیلتر.
     */
    public function render_surenapost_status_filter( $order_type = 'shop_order', $which = 'top' ) {
        unset( $which );

        if ( 'shop_order' !== $order_type ) {
            return;
        }

        $selected = $this->get_surenapost_status_filter_value();
        $options  = array(
            ''     => __( 'همه وضعیت‌های سورناپست', 'surenapost' ),
            'none' => __( 'ارسال نشده به سورناپست', 'surenapost' ),
            '1'    => __( 'در انتظار صدور بارکد', 'surenapost' ),
            '2'    => __( 'بارکد صادر شده', 'surenapost' ),
            '3'    => __( 'در انتظار لغو', 'surenapost' ),
            '4'    => __( 'لغو شده', 'surenapost' ),
        );

        echo '<select name="surenapost_status_filter" id="surenapost-status-filter">';
        foreach ( $options as $value => $label ) {
            echo '<option value="' . esc_attr( $value ) . '"' . selected( $selected, $value, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }

    /**
     * اعمال فیلتر روی جدول قدیمی سفارش‌ها.
     *
     * @param WP_Query $query کوئری وردپرس.
     */
    public function filter_legacy_orders_by_surenapost_status( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() || 'shop_order' !== $query->get( 'post_type' ) ) {
            return;
        }

        $condition = $this->get_surenapost_status_meta_condition();

        if ( empty( $condition ) ) {
            return;
        }

        $meta_query   = (array) $query->get( 'meta_query' );
        $meta_query[] = $condition;
        $query->set( 'meta_query', $meta_query );
    }

    /**
     * اعمال فیلتر روی جدول HPOS سفارش‌ها.
     *
     * @param array $args آرگومان‌های WC_Order_Query.
     * @return array
     */
    public function filter_hpos_orders_by_surenapost_status( $args ) {
        if ( ! is_admin() || ! isset( $_GET['page'] ) || 'wc-orders' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
            return $args;
        }

        $condition = $this->get_surenapost_status_meta_condition();

        if ( empty( $condition ) ) {
            return $args;
        }

        if ( ! isset( $args['meta_query'] ) || ! is_array( $args['meta_query'] ) ) {
            $args['meta_query'] = array();
        }

        $args['meta_query'][] = $condition;
        return $args;
    }

    /**
     * AJAX: دریافت HTML تازه یک سفارش بدون رفرش صفحه.
     */
    public function ajax_refresh_order_ui() {
        $this->assert_admin_ajax_request();

        $order_id = isset( $_REQUEST['order_id'] ) ? absint( wp_unslash( $_REQUEST['order_id'] ) ) : 0;
        $order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

        if ( ! $order instanceof WC_Order ) {
            wp_send_json_error( array( 'message' => __( 'سفارش یافت نشد.', 'surenapost' ) ) );
        }

        wp_send_json_success( array( 'ui' => $this->get_order_ui_payload( $order ) ) );
    }

    /**
     * AJAX: بروزرسانی خودکار سفارش‌های قابل مشاهده در صفحه بدون رفرش کامل.
     */
    public function ajax_refresh_visible_orders() {
        $this->assert_admin_ajax_request();

        $raw_ids   = isset( $_POST['order_ids'] ) ? wp_unslash( $_POST['order_ids'] ) : array();
        $order_ids = is_array( $raw_ids ) ? $raw_ids : explode( ',', (string) $raw_ids );
        $order_ids = array_slice( array_values( array_unique( array_filter( array_map( 'absint', $order_ids ) ) ) ), 0, 50 );

        if ( empty( $order_ids ) ) {
            wp_send_json_success( array( 'orders' => array() ) );
        }

        $results = $this->order_service->refresh_orders( $order_ids, 'poll' );

        if ( is_wp_error( $results ) ) {
            wp_send_json_error( array( 'message' => $results->get_error_message() ) );
        }

        $orders = array();
        foreach ( $order_ids as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order instanceof WC_Order ) {
                continue;
            }

            $orders[ $order_id ] = array(
                'ui'      => $this->get_order_ui_payload( $order ),
                'result'  => isset( $results[ $order_id ] ) ? $results[ $order_id ] : array(),
            );
        }

        wp_send_json_success( array( 'orders' => $orders ) );
    }

    /**
     * رندر مشترک اکشن‌ها برای ستون سفارش و صفحه جزئیات.
     *
     * @param WC_Order $order   سفارش.
     * @param string   $context column یا detail.
     * @return string
     */
    private function render_order_ui( $order, $context = 'column' ) {
        if ( ! $this->is_wc_order_object( $order ) ) {
            return '';
        }

        $order_id    = $order->get_id();
        $state       = $this->order_service->get_ui_state( $order );
        $print_count = absint( $order->get_meta( '_surenapost_print_count', true ) );
        $is_paid     = $order->is_paid();
        $attrs    = $this->get_issue_button_attributes( $order );

        // داده‌های سبک و محلی برای کپی سریع و تشخیص آماده‌بودن چاپ.
        $shipping_phone = is_callable( array( $order, 'get_shipping_phone' ) ) ? trim( (string) $order->get_shipping_phone() ) : trim( (string) $order->get_meta( '_shipping_phone', true ) );
        $recipient_phone = trim( (string) $order->get_billing_phone() );
        if ( '' === $recipient_phone ) {
            $recipient_phone = $shipping_phone;
        }

        $recipient_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
        if ( '' === $recipient_name ) {
            $recipient_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
        }

        $recipient_address = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() );
        if ( '' === $recipient_address ) {
            $recipient_address = trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() );
        }

        $recipient_postcode = trim( (string) $order->get_meta( '_surenapost_postcode', true ) );
        if ( '' === $recipient_postcode ) {
            $recipient_postcode = trim( (string) $order->get_shipping_postcode() );
        }
        if ( '' === $recipient_postcode ) {
            $recipient_postcode = trim( (string) $order->get_billing_postcode() );
        }

        $recipient_province = trim( (string) $order->get_meta( '_surenapost_province_name', true ) );
        if ( '' === $recipient_province ) {
            $recipient_province = trim( (string) $order->get_shipping_state() );
        }
        if ( '' === $recipient_province ) {
            $recipient_province = trim( (string) $order->get_billing_state() );
        }

        $recipient_city = trim( (string) $order->get_meta( '_surenapost_city_name', true ) );
        if ( '' === $recipient_city ) {
            $recipient_city = trim( (string) $order->get_shipping_city() );
        }
        if ( '' === $recipient_city ) {
            $recipient_city = trim( (string) $order->get_billing_city() );
        }

        $recipient_copy_text = implode( "\n", array_filter( array(
            sprintf( 'سفارش #%d', $order_id ),
            '' !== $recipient_name ? 'گیرنده: ' . $recipient_name : '',
            '' !== $recipient_phone ? 'تلفن: ' . $recipient_phone : '',
            '' !== $recipient_province ? 'استان: ' . $recipient_province : '',
            '' !== $recipient_city ? 'شهر: ' . $recipient_city : '',
            '' !== $recipient_address ? 'آدرس: ' . $recipient_address : '',
            '' !== $recipient_postcode ? 'کد پستی: ' . $recipient_postcode : '',
        ) ) );

        $print_missing = array();
        if ( empty( $state['tracking_code'] ) ) {
            $print_missing[] = 'کد رهگیری';
        }
        if ( '' === $recipient_name ) {
            $print_missing[] = 'نام گیرنده';
        }
        if ( '' === $recipient_phone ) {
            $print_missing[] = 'تلفن';
        }
        if ( '' === $recipient_province ) {
            $print_missing[] = 'استان';
        }
        if ( '' === $recipient_city ) {
            $print_missing[] = 'شهر';
        }
        if ( '' === $recipient_address ) {
            $print_missing[] = 'آدرس';
        }
        if ( '' === $recipient_postcode ) {
            $print_missing[] = 'کد پستی';
        }
        $is_print_ready = empty( $print_missing );

        ob_start();
        ?>
        <div id="<?php echo esc_attr( 'surenapost-order-ui-' . $context . '-' . $order_id ); ?>"
             class="surenapost-order-ui <?php echo esc_attr( 'surenapost-order-ui-' . $context ); ?>"
             data-order-id="<?php echo esc_attr( $order_id ); ?>"
             data-auto-refresh="<?php echo $state['auto_refresh'] ? '1' : '0'; ?>">
            <div class="surenapost-order-statuses">
                <?php echo $this->render_status_badges( $state ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php if ( 'column' === $context ) : ?>
                    <?php if ( $is_print_ready ) : ?>
                        <span class="surenapost-badge is-print-ready" title="<?php echo esc_attr__( 'اطلاعات لازم برای چاپ کامل است.', 'surenapost' ); ?>">
                            <?php echo esc_html__( '✓ آماده چاپ', 'surenapost' ); ?>
                        </span>
                    <?php endif; ?>
                    <span class="surenapost-badge is-print-count" title="<?php echo esc_attr__( 'تعداد دفعات شروع چاپ این سفارش', 'surenapost' ); ?>">
                        <?php echo esc_html( sprintf( __( 'چاپ: %d', 'surenapost' ), $print_count ) ); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="surenapost-order-actions">
                <?php if ( $state['can_issue'] ) : ?>
                    <button type="button" class="button button-primary surenapost-send-order"
                        <?php echo $this->render_html_attributes( $attrs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php disabled( ! $is_paid ); ?>>
                        <?php echo esc_html__( 'صدور سورناپست', 'surenapost' ); ?>
                    </button>
                <?php endif; ?>

                <?php if ( $state['is_pending_tracking'] ) : ?>
                    <button type="button" class="button surenapost_get_tracking_btn" data-order-id="<?php echo esc_attr( $order_id ); ?>">
                        <?php echo esc_html__( 'بروزرسانی وضعیت', 'surenapost' ); ?>
                    </button>
                <?php endif; ?>

                <?php if ( '' !== $recipient_copy_text ) : ?>
                    <button type="button" class="button surenapost-copy-text"
                            data-copy-text="<?php echo esc_attr( $recipient_copy_text ); ?>"
                            data-copy-success="<?php echo esc_attr__( 'اطلاعات گیرنده کپی شد.', 'surenapost' ); ?>">
                        <?php echo esc_html__( 'کپی گیرنده', 'surenapost' ); ?>
                    </button>
                <?php endif; ?>

                <?php if ( $state['has_tracking'] ) : ?>
                    <button type="button" class="button surenapost-copy-text"
                            data-copy-text="<?php echo esc_attr( $state['tracking_code'] ); ?>"
                            data-copy-success="<?php echo esc_attr__( 'کد رهگیری کپی شد.', 'surenapost' ); ?>">
                        <?php echo esc_html__( 'کپی رهگیری', 'surenapost' ); ?>
                    </button>
                    <button type="button" class="button surenapost-view-barcode"
                            data-order-id="<?php echo esc_attr( $order_id ); ?>"
                            data-tracking-code="<?php echo esc_attr( $state['tracking_code'] ); ?>"
                            data-province-name="<?php echo esc_attr( $order->get_meta( '_surenapost_province_name', true ) ); ?>"
                            data-city-name="<?php echo esc_attr( $order->get_meta( '_surenapost_city_name', true ) ); ?>"
                            data-tracking-time="<?php echo esc_attr( $order->get_meta( '_surenapost_times', true ) ); ?>">
                        <?php echo esc_html__( 'مشاهده بارکد', 'surenapost' ); ?>
                    </button>
                    <a href="<?php echo esc_url( $this->get_print_url( $order_id ) ); ?>" target="_blank" class="button">
                        <?php echo esc_html__( 'چاپ', 'surenapost' ); ?>
                    </a>
                    <button type="button" class="button button-link-delete surenapost-suspend-barcode" data-order-id="<?php echo esc_attr( $order_id ); ?>">
                        <?php echo esc_html__( 'لغو بارکد', 'surenapost' ); ?>
                    </button>
                <?php endif; ?>

                <?php if ( $state['is_cancel_requested'] ) : ?>
                    <button type="button" class="button surenapost-suspend-barcode-update" data-order-id="<?php echo esc_attr( $order_id ); ?>">
                        <?php echo esc_html__( 'بروزرسانی لغو', 'surenapost' ); ?>
                    </button>
                <?php endif; ?>
            </div>

            <?php if ( ! $is_paid && $state['can_issue'] ) : ?>
                <p class="surenapost-order-note"><?php echo esc_html__( 'برای صدور، سفارش باید پرداخت شده باشد.', 'surenapost' ); ?></p>
            <?php elseif ( $state['is_pending_tracking'] ) : ?>
                <p class="surenapost-order-note"><?php echo esc_html__( 'مرسوله در صف صدور بارکد است؛ وضعیت خودکار بروزرسانی می‌شود.', 'surenapost' ); ?></p>
            <?php elseif ( $state['is_cancel_requested'] ) : ?>
                <p class="surenapost-order-note"><?php echo esc_html__( 'درخواست لغو ثبت شده و نتیجه خودکار بررسی می‌شود.', 'surenapost' ); ?></p>
            <?php elseif ( $state['is_cancelled'] ) : ?>
                <p class="surenapost-order-note surenapost-order-note-danger"><?php echo esc_html__( 'این مرسوله لغو شده است.', 'surenapost' ); ?></p>
            <?php endif; ?>

            <?php if ( 'detail' === $context ) : ?>
                <?php echo $this->render_order_detail_table( $order, $state ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * رندر جدول اطلاعات تکمیلی در صفحه جزئیات سفارش.
     *
     * @param WC_Order $order سفارش.
     * @param array    $state وضعیت رابط.
     * @return string
     */
    private function render_order_detail_table( $order, $state ) {
        $rows = array(
            __( 'وضعیت API', 'surenapost' )        => $state['remote_status'],
            __( 'کد رهگیری', 'surenapost' )        => $state['tracking_code'],
            __( 'مقصد', 'surenapost' )             => trim( (string) $order->get_meta( '_surenapost_province_name', true ) . ' - ' . (string) $order->get_meta( '_surenapost_city_name', true ), ' -' ),
            __( 'وزن مرسوله', 'surenapost' )       => $order->get_meta( '_surenapost_weight', true ),
            __( 'ارزش مرسوله', 'surenapost' )      => $order->get_meta( '_surenapost_percelValue', true ),
            __( 'هزینه پست', 'surenapost' )        => $order->get_meta( '_surenapost_postage', true ),
            __( 'بیمه', 'surenapost' )             => $order->get_meta( '_surenapost_insurance', true ),
            __( 'مالیات', 'surenapost' )           => $order->get_meta( '_surenapost_tax', true ),
            __( 'مبلغ کل سورناپست', 'surenapost' ) => $order->get_meta( '_surenapost_totalPrice', true ),
            __( 'نوع پرداخت', 'surenapost' )        => $this->get_order_pay_type_label( $order ),
            __( 'مبلغ قابل پرداخت هنگام تحویل', 'surenapost' ) => $order->get_meta( '_surenapost_payTypeText', true ),
            __( 'نوع سرویس پستی', 'surenapost' )    => $order->get_meta( '_surenapost_postType', true ),
            __( 'تاریخ ثبت API', 'surenapost' )      => $order->get_meta( '_surenapost_remote_date', true ),
            __( 'زمان ثبت API', 'surenapost' )      => $order->get_meta( '_surenapost_remote_time', true ),
        );

        $sent_at = absint( $order->get_meta( '_surenapost_times', true ) );
        if ( $sent_at ) {
            $rows[ __( 'آخرین زمان ثبت', 'surenapost' ) ] = wp_date( 'Y/n/j H:i', $sent_at );
        }

        ob_start();
        ?>
        <table class="widefat striped surenapost-order-detail-table">
            <tbody>
            <?php foreach ( $rows as $label => $value ) : ?>
                <?php if ( '' === trim( (string) $value ) ) { continue; } ?>
                <tr>
                    <th><?php echo esc_html( $label ); ?></th>
                    <td><?php echo esc_html( $value ); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * رندر نشان‌های وضعیت.
     *
     * @param array $state وضعیت رابط.
     * @return string
     */
    private function render_status_badges( $state ) {
        $badges = array();

        if ( $state['is_cancelled'] ) {
            $badges[] = array( 'is-cancelled', __( 'لغو شده', 'surenapost' ) );
        } elseif ( $state['is_cancel_requested'] ) {
            $badges[] = array( 'is-danger', __( 'در انتظار لغو', 'surenapost' ) );
        } elseif ( $state['has_tracking'] ) {
            $badges[] = array( 'is-success', __( 'بارکد صادر شده', 'surenapost' ) );
        } elseif ( $state['is_pending_tracking'] ) {
            $badges[] = array( 'is-warning', __( 'در انتظار صدور بارکد', 'surenapost' ) );
        } else {
            $badges[] = array( 'is-neutral', __( 'ارسال نشده', 'surenapost' ) );
        }

        if ( '' !== $state['remote_status'] && ! in_array( $state['remote_status'], array( 'ثبت شده', 'در انتظار', 'لغو شده' ), true ) ) {
            $badges[] = array( 'is-remote', $state['remote_status'] );
        }

        $html = '';
        foreach ( $badges as $badge ) {
            $html .= '<span class="surenapost-badge ' . esc_attr( $badge[0] ) . '">' . esc_html( $badge[1] ) . '</span>';
        }

        return $html;
    }

    /**
     * اطلاعات سفارش لازم برای باز کردن فرم صدور.
     *
     * @param WC_Order $order سفارش.
     * @return array
     */
    private function get_issue_button_attributes( $order ) {
        $shipping_phone = is_callable( array( $order, 'get_shipping_phone' ) ) ? $order->get_shipping_phone() : $order->get_meta( '_shipping_phone', true );
        $billing_phone  = $order->get_billing_phone();
        $mobile         = $billing_phone ? $billing_phone : $shipping_phone;
        $saved_postcode = $order->get_meta( '_surenapost_postcode', true );
        $postcode       = $saved_postcode ? $saved_postcode : $order->get_shipping_postcode();
        $province_name  = $order->get_meta( '_surenapost_province_name', true );
        $state_name     = $province_name ? $province_name : $order->get_shipping_state();
        $address        = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() );

        return array(
            'data-order-id'          => $order->get_id(),
            'data-province-id'       => $order->get_meta( '_surenapost_province_id', true ),
            'data-city-id'           => $order->get_meta( '_surenapost_city_id', true ),
            'data-province-name'     => $province_name,
            'data-city-name'         => $order->get_meta( '_surenapost_city_name', true ),
            'data-shipping-name'     => trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() ),
            'data-shipping-address'  => $address,
            'data-shipping-phone'    => $mobile,
            'data-shipping-city'     => $order->get_shipping_city(),
            'data-shipping-state'    => $state_name,
            'data-shipping-postcode' => $postcode,
            'data-shipping-mobile'   => preg_replace( '/[^0-9]/', '', (string) $mobile ),
        );
    }

    /**
     * تبدیل آرایه ویژگی‌ها به HTML امن.
     *
     * @param array $attributes ویژگی‌ها.
     * @return string
     */
    private function render_html_attributes( $attributes ) {
        $html = '';
        foreach ( $attributes as $key => $value ) {
            $html .= ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
        }
        return $html;
    }

    /**
     * خروجی HTML مورد نیاز برای جایگزینی AJAX.
     *
     * @param WC_Order $order سفارش.
     * @return array
     */
    private function get_order_ui_payload( $order ) {
        if ( ! $order instanceof WC_Order ) {
            return array();
        }

        return array(
            'column' => $this->render_order_ui( $order, 'column' ),
            'detail' => $this->render_order_ui( $order, 'detail' ),
        );
    }

    /**
     * بررسی nonce و سطح دسترسی درخواست AJAX مدیریت.
     */
    private function assert_admin_ajax_request() {
        if ( false === check_ajax_referer( 'surenapost_admin_nonce', 'nonce', false ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'نشست مدیریت منقضی شده است. صفحه را یک‌بار تازه‌سازی کنید و دوباره تلاش کنید.', 'surenapost' ),
                    'code'    => 'surenapost_invalid_nonce',
                ),
                403
            );
        }

        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'شما دسترسی لازم را ندارید.', 'surenapost' ),
                    'code'    => 'surenapost_forbidden',
                ),
                403
            );
        }
    }

    /**
     * مقدار فیلتر وضعیت سورناپست از URL.
     *
     * @return string
     */
    private function get_surenapost_status_filter_value() {
        $value   = isset( $_GET['surenapost_status_filter'] ) ? sanitize_key( wp_unslash( $_GET['surenapost_status_filter'] ) ) : '';
        $allowed = array( '', 'none', '1', '2', '3', '4' );

        return in_array( $value, $allowed, true ) ? $value : '';
    }

    /**
     * شرط متای متناظر با فیلتر وضعیت.
     *
     * @return array
     */
    private function get_surenapost_status_meta_condition() {
        $value = $this->get_surenapost_status_filter_value();

        if ( '' === $value ) {
            return array();
        }

        if ( 'none' === $value ) {
            return array(
                'relation' => 'OR',
                array( 'key' => '_surenapost_status', 'compare' => 'NOT EXISTS' ),
                array( 'key' => '_surenapost_status', 'value' => '', 'compare' => '=' ),
                array( 'key' => '_surenapost_status', 'value' => '0', 'compare' => '=' ),
            );
        }

        return array(
            'key'     => '_surenapost_status',
            'value'   => $value,
            'compare' => '=',
        );
    }

    public function handle_refresh_locations_submit() {
        if ( ! is_admin() ) {
            return;
        }

        if ( ! isset( $_POST['surenapost_refresh_locations_submit'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
        }

        check_admin_referer( 'surenapost_refresh_locations_action', 'surenapost_refresh_locations_nonce' );

        $locations_db = new Surenapost_Locations_DB();
        $locations_db->maybe_create_tables();
        $result = $locations_db->refresh_all();

        // $redirect_url = wp_get_referer();
        // if ( ! $redirect_url ) {
        //     $redirect_url = admin_url();
        // }
        $redirect_url = add_query_arg(
            array(
                'page' => 'surenapost',
                'tab'  => 'update',
            ),
            admin_url( 'admin.php' )
        );

        $redirect_url = remove_query_arg(
            array(
                'surenapost_locations_updated',
                'surenapost_locations_message',
            ),
            $redirect_url
        );

        if ( is_wp_error( $result ) ) {
            $redirect_url = add_query_arg(
                array(
                    'surenapost_locations_updated' => '0',
                    'surenapost_locations_message' => rawurlencode( $result->get_error_message() ),
                ),
                $redirect_url
            );

            wp_safe_redirect( $redirect_url );
            exit;
        }

        $message = sprintf(
            'بروزرسانی با موفقیت انجام شد. %1$s استان بررسی شد، %2$s استان جدید اضافه شد، %3$s استان بروزرسانی شد، %4$s شهر بررسی شد، %5$s شهر جدید اضافه شد و %6$s شهر بروزرسانی شد.',
            isset( $result['provinces_total'] ) ? (int) $result['provinces_total'] : 0,
            isset( $result['provinces_inserted'] ) ? (int) $result['provinces_inserted'] : 0,
            isset( $result['provinces_updated'] ) ? (int) $result['provinces_updated'] : 0,
            isset( $result['cities_total'] ) ? (int) $result['cities_total'] : 0,
            isset( $result['cities_inserted'] ) ? (int) $result['cities_inserted'] : 0,
            isset( $result['cities_updated'] ) ? (int) $result['cities_updated'] : 0
        );

        if ( ! empty( $result['errors'] ) && is_array( $result['errors'] ) ) {
            $message .= ' ' . implode( ' | ', array_map( 'sanitize_text_field', $result['errors'] ) );
        }

        $redirect_url = add_query_arg(
            array(
                'surenapost_locations_updated' => '1',
                'surenapost_locations_message' => rawurlencode( $message ),
            ),
            $redirect_url
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }

    public function ajax_check_locations() {
        $this->assert_admin_ajax_request();

        /*
         * این بررسی باید دقیقاً با وضعیت صفحه راه‌اندازی یکسان باشد.
         * در API جدید، دریافت معتبر dependency/extra به معنی تکمیل همگام‌سازی است
         * و خالی بودن احتمالی یکی از گروه‌های شناخته‌شده نباید صدور را بی‌دلیل مسدود کند.
         */
        $locations_db         = new Surenapost_Locations_DB();
        $dependencies_manager = new Surenapost_Dependencies_Manager();

        $province_count = method_exists( $locations_db, 'count_provinces' ) ? (int) $locations_db->count_provinces() : 0;
        $city_count     = method_exists( $locations_db, 'count_cities' ) ? (int) $locations_db->count_cities() : 0;

        $locations_complete    = $province_count > 0 && $city_count > 0;
        $dependencies_complete = $dependencies_manager->has_successful_sync();
        $is_empty              = ! $locations_complete || ! $dependencies_complete;

        wp_send_json_success(
            array(
                'is_empty'               => $is_empty,
                'locations_complete'     => $locations_complete,
                'dependencies_complete'  => $dependencies_complete,
                'province_count'         => $province_count,
                'city_count'             => $city_count,
                'update_url'             => admin_url( 'admin.php?page=surenapost&tab=update' ),
            )
        );
    }

    /**
     * دریافت آی‌پی خروجی سرور فروشگاه از API سورناپست.
     *
     * @param bool $force_refresh نادیده گرفتن کش موقت.
     * @return array
     */
    public function get_server_ip_info( $force_refresh = false ) {
        $transient_key = 'surenapost_server_ip_info';

        if ( ! $force_refresh ) {
            $cached = get_transient( $transient_key );
            if ( is_array( $cached ) && isset( $cached['success'] ) ) {
                return $cached;
            }
        }

        $response = wp_remote_get(
            'https://post-api.sourena.shop/api/test/my-ip',
            array(
                'timeout' => 15,
                'headers' => array(
                    'Accept' => 'application/json, text/plain',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'ip'      => '',
                'message' => $response->get_error_message(),
            );
        }

        $http_code = (int) wp_remote_retrieve_response_code( $response );
        $body      = trim( (string) wp_remote_retrieve_body( $response ) );

        if ( $http_code < 200 || $http_code >= 300 ) {
            return array(
                'success' => false,
                'ip'      => '',
                'message' => sprintf(
                /* translators: %d: HTTP response code. */
                    __( 'دریافت آی‌پی از سرویس سورناپست ناموفق بود. کد پاسخ: %d', 'surenapost' ),
                    $http_code
                ),
            );
        }

        $ip = $this->extract_ip_from_response( $body );

        if ( '' === $ip ) {
            return array(
                'success' => false,
                'ip'      => '',
                'message' => __( 'پاسخ سرویس دریافت شد، اما آی‌پی معتبر داخل آن پیدا نشد.', 'surenapost' ),
            );
        }

        $result = array(
            'success' => true,
            'ip'      => $ip,
            'message' => '',
        );

        set_transient( $transient_key, $result, 5 * MINUTE_IN_SECONDS );
        update_option( 'surenapost_server_ip_last_seen', $ip, false );

        return $result;
    }

    /**
     * استخراج IPv4 یا IPv6 از پاسخ ساده یا JSON.
     *
     * @param string $body پاسخ خام API.
     * @return string
     */
    private function extract_ip_from_response( $body ) {
        $body = trim( (string) $body );

        if ( filter_var( trim( $body, " \t\n\r\0\x0B\"'" ), FILTER_VALIDATE_IP ) ) {
            return trim( $body, " \t\n\r\0\x0B\"'" );
        }

        $data = json_decode( $body, true );
        if ( JSON_ERROR_NONE === json_last_error() ) {
            $candidates = array();

            if ( is_string( $data ) ) {
                $candidates[] = $data;
            } elseif ( is_array( $data ) ) {
                foreach ( array( 'ip', 'output', 'message', 'data' ) as $key ) {
                    if ( isset( $data[ $key ] ) && is_string( $data[ $key ] ) ) {
                        $candidates[] = $data[ $key ];
                    }
                }

                if ( isset( $data['data']['ip'] ) && is_string( $data['data']['ip'] ) ) {
                    $candidates[] = $data['data']['ip'];
                }

                if ( isset( $data['output']['ip'] ) && is_string( $data['output']['ip'] ) ) {
                    $candidates[] = $data['output']['ip'];
                }
            }

            foreach ( $candidates as $candidate ) {
                $candidate = trim( $candidate );
                if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
                    return $candidate;
                }
            }
        }

        if ( preg_match_all( '/[0-9a-fA-F:.]+/', $body, $matches ) ) {
            foreach ( $matches[0] as $candidate ) {
                $candidate = trim( $candidate, " .,:;[](){}<>\"'" );
                if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
                    return $candidate;
                }
            }
        }

        return '';
    }

    /**
     * وضعیت چهار مرحله راه‌اندازی را برای داشبورد و صفحه راه‌اندازی برمی‌گرداند.
     *
     * @return array
     */
    public function get_setup_status() {
        $api_manager          = new Surenapost_Api_Manager();
        $dependencies_manager = new Surenapost_Dependencies_Manager();
        $locations_db         = new Surenapost_Locations_DB();
        $token_exists         = $api_manager->has_api_key();
        $confirmed_ip         = (string) get_option( 'surenapost_setup_confirmed_ip', '' );

        $sender = array(
            'name'     => trim( (string) get_option( 'surenapost_sender_name', get_bloginfo( 'name' ) ) ),
            'state'    => trim( (string) get_option( 'surenapost_sender_state', '' ) ),
            'city'     => trim( (string) get_option( 'surenapost_sender_city', get_option( 'woocommerce_store_city', '' ) ) ),
            'address'  => trim( (string) get_option( 'surenapost_sender_address', get_option( 'woocommerce_store_address', '' ) ) ),
            'postcode' => trim( (string) get_option( 'surenapost_sender_postcode', get_option( 'woocommerce_store_postcode', '' ) ) ),
            'phone'    => trim( (string) get_option( 'surenapost_sender_phone', get_option( 'woocommerce_store_phone', '' ) ) ),
        );

        $sender_complete = $token_exists;
        foreach ( $sender as $value ) {
            if ( '' === $value ) {
                $sender_complete = false;
                break;
            }
        }

        // مرحله ۳ نشان‌دهنده انجام موفق همگام‌سازی است، نه اجبار به پر بودن
        // همه گروه‌ها؛ API ممکن است در هر نسخه مجموعه متفاوتی برگرداند.
        $dependencies_complete = $dependencies_manager->has_successful_sync();

        $province_count     = (int) $locations_db->count_provinces();
        $city_count         = (int) $locations_db->count_cities();
        $locations_complete = $province_count > 0 && $city_count > 0;

        $steps = array(
            'ip' => array(
                'label'    => __( 'ثبت آی‌پی سایت و دریافت توکن', 'surenapost' ),
                'complete' => '' !== $confirmed_ip || $token_exists,
            ),
            'sender' => array(
                'label'    => __( 'ذخیره توکن و اطلاعات فرستنده', 'surenapost' ),
                'complete' => $sender_complete,
            ),
            'dependencies' => array(
                'label'    => __( 'دریافت لیست وابستگی‌ها', 'surenapost' ),
                'complete' => $dependencies_complete,
            ),
            'locations' => array(
                'label'    => __( 'دریافت لیست شهرها و استان‌ها', 'surenapost' ),
                'complete' => $locations_complete,
            ),
        );

        $completed = 0;
        foreach ( $steps as $step ) {
            if ( ! empty( $step['complete'] ) ) {
                $completed++;
            }
        }

        return array(
            'steps'                 => $steps,
            'completed'             => $completed,
            'total'                 => count( $steps ),
            'all_complete'          => $completed === count( $steps ),
            'token_exists'          => $token_exists,
            'confirmed_ip'          => $confirmed_ip,
            'sender'                => $sender,
            'sender_complete'       => $sender_complete,
            'dependencies_complete' => $dependencies_complete,
            'dependencies_last_sync'=> (string) get_option( 'surenapost_dependencies_last_refresh', '' ),
            'locations_complete'    => $locations_complete,
            'locations_last_sync'   => (string) $locations_db->get_last_refresh_time(),
            'province_count'        => $province_count,
            'city_count'            => $city_count,
        );
    }

    /**
     * پردازش دکمه‌های صفحه راه‌اندازی اولیه.
     */
    public function handle_setup_actions() {
        if ( ! is_admin() || ! isset( $_POST['surenapost_setup_action'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
        }

        check_admin_referer( 'surenapost_setup_action', 'surenapost_setup_nonce' );

        $action   = sanitize_key( wp_unslash( $_POST['surenapost_setup_action'] ) );
        $messages = array();
        $type     = 'success';

        if ( 'confirm_ip' === $action || 'refresh_ip' === $action ) {
            $ip_info = $this->get_server_ip_info( true );

            if ( empty( $ip_info['success'] ) ) {
                $this->set_setup_notice( 'error', array( $ip_info['message'] ) );
                $this->redirect_to_setup_page();
            }

            if ( 'confirm_ip' === $action ) {
                update_option( 'surenapost_setup_confirmed_ip', $ip_info['ip'], false );
                update_option( 'surenapost_setup_ip_confirmed_at', current_time( 'mysql' ), false );
                $messages[] = __( 'آی‌پی به عنوان ارسال‌شده برای سورناپست ثبت شد. پس از دریافت توکن، مرحله بعد را تکمیل کنید.', 'surenapost' );
            } else {
                $messages[] = __( 'آی‌پی سرور دوباره از سرویس سورناپست دریافت شد.', 'surenapost' );
            }

            $this->set_setup_notice( 'success', $messages );
            $this->redirect_to_setup_page();
        }

        $api_manager = new Surenapost_Api_Manager();
        $token       = $api_manager->get_api_key();

        if ( empty( $token ) ) {
            $this->set_setup_notice( 'error', array( __( 'ابتدا توکن سورناپست و اطلاعات فرستنده را ذخیره کنید.', 'surenapost' ) ) );
            $this->redirect_to_setup_page();
        }

        if ( 'sync_dependencies' === $action || 'sync_all' === $action ) {
            $dependencies_manager = new Surenapost_Dependencies_Manager();
            $dependencies_result  = $dependencies_manager->update_all_dependencies( $token, false );

            if ( ! empty( $dependencies_result['errors'] ) ) {
                $type       = empty( $dependencies_result['details'] ) ? 'error' : 'warning';
                $messages[] = empty( $dependencies_result['details'] )
                    ? __( 'همگام‌سازی وابستگی‌ها انجام نشد:', 'surenapost' )
                    : __( 'همگام‌سازی وابستگی‌ها با هشدار انجام شد:', 'surenapost' );
                foreach ( $dependencies_result['errors'] as $error ) {
                    $messages[] = sanitize_text_field( $error );
                }
            } else {
                update_option( 'surenapost_dependencies_last_refresh', current_time( 'mysql' ), false );
                $messages[] = __( 'وابستگی‌ها با موفقیت دریافت و ذخیره شدند.', 'surenapost' );
            }
        }

        if ( 'sync_locations' === $action || 'sync_all' === $action ) {
            $locations_db     = new Surenapost_Locations_DB();
            $locations_result = $locations_db->refresh_all();

            if ( is_wp_error( $locations_result ) ) {
                $type       = 'error';
                $messages[] = sprintf(
                /* translators: %s: API error message. */
                    __( 'دریافت شهرها و استان‌ها انجام نشد: %s', 'surenapost' ),
                    $locations_result->get_error_message()
                );
            } else {
                $messages[] = sprintf(
                /* translators: 1: provinces count, 2: cities count. */
                    __( 'شهرها و استان‌ها ذخیره شدند: %1$d استان و %2$d شهر.', 'surenapost' ),
                    isset( $locations_result['db_provinces_count'] ) ? (int) $locations_result['db_provinces_count'] : 0,
                    isset( $locations_result['db_cities_count'] ) ? (int) $locations_result['db_cities_count'] : 0
                );

                if ( ! empty( $locations_result['errors'] ) && is_array( $locations_result['errors'] ) ) {
                    if ( 'error' !== $type ) {
                        $type = 'warning';
                    }
                    foreach ( $locations_result['errors'] as $error ) {
                        $messages[] = sanitize_text_field( $error );
                    }
                }
            }
        }

        if ( empty( $messages ) ) {
            $type       = 'error';
            $messages[] = __( 'عملیات درخواستی شناخته نشد.', 'surenapost' );
        }

        $this->set_setup_notice( $type, $messages );
        $this->redirect_to_setup_page();
    }

    /**
     * دریافت و حذف پیام موقت صفحه راه‌اندازی.
     *
     * @return array|false
     */
    public function get_setup_notice() {
        $key    = 'surenapost_setup_notice_' . get_current_user_id();
        $notice = get_transient( $key );
        delete_transient( $key );

        return is_array( $notice ) ? $notice : false;
    }

    /**
     * ذخیره پیام موقت صفحه راه‌اندازی.
     *
     * @param string $type نوع پیام.
     * @param array  $messages متن پیام‌ها.
     */
    private function set_setup_notice( $type, $messages ) {
        $allowed_types = array( 'success', 'warning', 'error', 'info' );
        if ( ! in_array( $type, $allowed_types, true ) ) {
            $type = 'info';
        }

        set_transient(
            'surenapost_setup_notice_' . get_current_user_id(),
            array(
                'type'     => $type,
                'messages' => array_map( 'sanitize_text_field', (array) $messages ),
            ),
            MINUTE_IN_SECONDS
        );
    }

    /**
     * بازگشت امن به صفحه راه‌اندازی.
     */
    private function redirect_to_setup_page() {
        wp_safe_redirect( admin_url( 'admin.php?page=surenapost-setup' ) );
        exit;
    }

}


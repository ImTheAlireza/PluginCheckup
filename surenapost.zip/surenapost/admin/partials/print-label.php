<?php
/**
 * قالب چاپ برچسب سورناپست.
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$escape = static function ( $value ) {
    return esc_html( (string) $value );
};

$persian_number = static function ( $value ) {
    return strtr(
        (string) $value,
        array(
            '0' => '۰',
            '1' => '۱',
            '2' => '۲',
            '3' => '۳',
            '4' => '۴',
            '5' => '۵',
            '6' => '۶',
            '7' => '۷',
            '8' => '۸',
            '9' => '۹',
        )
    );
};

$display = static function ( $value, $fallback = '-' ) use ( $escape ) {
    $value = trim( (string) $value );
    return $escape( '' !== $value ? $value : $fallback );
};

$display_number = static function ( $value, $fallback = '-' ) use ( $persian_number, $escape ) {
    $value = trim( (string) $value );
    if ( '' === $value ) {
        return $escape( $fallback );
    }
    return $escape( $persian_number( $value ) );
};

$display_amount = static function ( $value, $fallback = '-' ) use ( $persian_number, $escape ) {
    $value = trim( (string) $value );
    if ( '' === $value ) {
        return $escape( $fallback );
    }
    $normalized = str_replace( array( ',', ' ', '٬' ), '', $value );
    if ( is_numeric( $normalized ) ) {
        $value = number_format( (float) $normalized, 0, '.', ',' );
    }
    return $escape( $persian_number( $value ) );
};

$tracking_code = isset( $print['tracking_code'] ) ? trim( (string) $print['tracking_code'] ) : '';
$qr_text       = isset( $print['qr_text'] ) ? trim( (string) $print['qr_text'] ) : '';
$products      = isset( $print['products'] ) && is_array( $print['products'] ) ? $print['products'] : array();
$print_mode           = isset( $print['print_mode'] ) ? sanitize_key( $print['print_mode'] ) : 'a5_products';

// سازگاری با تنظیمات نسخه‌های قبلی افزونه.
if ( 'full' === $print_mode ) {
    $print_mode = 'a5_products';
} elseif ( 'summary' === $print_mode ) {
    $print_mode = 'a6_no_products';
}

$print_modes = array(
    'a5_products'     => 'A5 با محصول',
    'a6_products'     => 'A6 با محصول',
    'a5_products_end' => 'A5 با محصول در انتها',
    'a6_products_end' => 'A6 با محصول در انتها',
    'a6_no_products'  => 'A6 بدون محصول',
    'a5_no_products'  => 'A5 بدون محصول',
);

if ( ! isset( $print_modes[ $print_mode ] ) ) {
    $print_mode = 'a5_products';
}

$print_size       = 0 === strpos( $print_mode, 'a6_' ) ? 'a6' : 'a5';
$products_at_end  = false !== strpos( $print_mode, '_products_end' );
$without_products = false !== strpos( $print_mode, '_no_products' );
$body_classes     = array(
    'size-' . $print_size,
    $products_at_end ? 'products-end' : 'products-inline',
);
if ( $without_products ) {
    $body_classes[] = 'no-products';
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html( 'چاپ سفارش #' . $print['order_id'] ); ?></title>
    <style id="surenapost-page-style">@page { size: <?php echo 'a6' === $print_size ? 'A6' : 'A5'; ?> portrait; margin: 5mm; }</style>
    <style>
        @font-face{
            font-family:'IRANSans';
            font-style:normal;
            font-weight:normal;
            font-display:block;
            src:url('<?php echo esc_url( $print['plugin_url'] . 'admin/fonts/eot/IRANSansWeb.eot' ); ?>');
            src:url('<?php echo esc_url( $print['plugin_url'] . 'admin/fonts/eot/IRANSansWeb.eot?#iefix' ); ?>') format('embedded-opentype'),
            url('<?php echo esc_url( $print['plugin_url'] . 'admin/fonts/woff2/IRANSansWeb.woff2' ); ?>') format('woff2'),
            url('<?php echo esc_url( $print['plugin_url'] . 'admin/fonts/woff/IRANSansWeb.woff' ); ?>') format('woff'),
            url('<?php echo esc_url( $print['plugin_url'] . 'admin/fonts/ttf/IRANSansWeb.ttf' ); ?>') format('truetype');
        }
        :root{--ink:#111;--soft:#666;--line:1px solid #111;--light-line:1px solid #999;--radius:5px}
        *,*::before,*::after{box-sizing:border-box}
        html,body{width:100%;max-width:100%;margin:0;padding:0;overflow-x:hidden}
        body{direction:rtl;text-align:right;color:var(--ink);font-family:'IRANSans',Tahoma,Arial,sans-serif;font-size:9.7pt;line-height:1.36;background:#f0f0f1;-webkit-print-color-adjust:exact;print-color-adjust:exact}
        .print-toolbar{position:sticky;top:0;z-index:1000;display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:6px;padding:4px 8px;background:#fff;border-bottom:1px solid #ccd0d4;box-shadow:0 1px 2px rgba(0,0,0,.05);font-size:13px}
        .print-toolbar label{font-weight:700}.print-toolbar select,.print-toolbar button{min-height:28px;border:1px solid #8c8f94;border-radius:4px;background:#fff;padding:2px 8px;font-family:inherit;font-size:13px}.print-toolbar button{cursor:pointer;background:#2271b1;border-color:#2271b1;color:#fff;font-weight:700;padding-inline:14px}.print-toolbar .print-hint{color:#50575e;font-size:12px}
        .sheet{margin:12px auto 24px;padding:1.6mm;background:#fff;box-shadow:0 1px 10px rgba(0,0,0,.13);max-width:100%}body.size-a5 .sheet{width:148mm}body.size-a6 .sheet{width:105mm;padding:.9mm;font-size:7.6pt;line-height:1.23}
        .frame{border:var(--line);border-radius:var(--radius);background:#fff;overflow:hidden;margin-bottom:.75mm}
        .company-header{display:grid;grid-template-columns:12mm minmax(0,1fr);align-items:center;gap:2mm;padding:1.2mm 2mm;text-align:center}.company-header img{display:block;width:18mm;height:14mm;object-fit:contain;margin:0 auto}.company-title{font-size:11.5pt;font-weight:800;line-height:1.2}.company-meta{font-size:8.4pt;font-weight:400;margin-top:.3mm}
        .sender-grid{display:grid;grid-template-columns:28% 72%}.sender-note,.sender-info{padding:1.1mm 1.6mm}.sender-note{border-left:var(--line);font-size:7.5pt;text-align:justify;font-weight:400}.order-code{border-top:var(--line);margin-top:.6mm;padding-top:.45mm;font-size:9pt;font-weight:800;text-align:center}.sender-info,.receiver-info{font-size:9.2pt;font-weight:400;line-height:1.38}.receiver-info{font-size:10.2pt;line-height:1.58}.label{font-weight:400}
        table{width:100%;border-collapse:collapse;table-layout:fixed}.products-table{margin-bottom:.75mm;border:var(--line);font-size:8.3pt;background:#fff}.products-table th,.products-table td{border-left:var(--light-line);border-bottom:var(--light-line);padding:.65mm .7mm;vertical-align:middle;overflow-wrap:anywhere}.products-table th:last-child,.products-table td:last-child{border-left:0}.products-table tbody tr:last-child td{border-bottom:0}.products-table thead th{background:#ececec;border-bottom:var(--line);font-weight:800;text-align:center}.products-table .col-row{width:7%;text-align:center}.products-table .col-product{width:51%}.products-table .col-qty{width:10%;text-align:center}.products-table .col-price{width:16%;text-align:center}body.no-products .products-table{display:none!important}.empty-products{text-align:center;color:var(--soft)}
        .payment-grid{display:grid;grid-template-columns:34% 66%;font-size:8.7pt;font-weight:700}.payment-grid>div{padding:.8mm 1.25mm}.payment-grid>div+div{border-right:var(--line)}
        .recipient-grid{display:grid;grid-template-columns:77% 23%}.receiver-info{padding:1mm 1.5mm}.signature-wrap{padding:.7mm;border-right:var(--line)}.signature-grid{display:grid;grid-template-columns:1fr 1fr;gap:.5mm;height:100%}.signature-box{min-height:11mm;border:var(--line);border-radius:4px;padding:.6mm;font-size:7.2pt;font-weight:700;text-align:center}
        .bottom-grid{display:grid;grid-template-columns:minmax(0,22fr) minmax(0,78fr);gap:.6mm;align-items:stretch}.bottom-grid>*{min-width:0;max-width:100%}.returns-box{padding:.75mm;margin-bottom:0}.returns-title{font-size:7.6pt;font-weight:800;margin-bottom:.25mm}.returns-grid{display:grid;grid-template-columns:1fr 1fr;gap:.22mm .4mm}.return-item{display:flex;align-items:flex-start;gap:.28mm;padding:.22mm 0;margin-top:4mm;font-size:6.3pt;font-weight:400;line-height:1.12}.checkbox{width:2mm;height:2mm;border:var(--line);flex:0 0 2mm;margin-top:.08mm}
        .postal-panel{padding:.9mm;margin-bottom:0}.postal-head{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:.5mm;border-bottom:var(--light-line);padding-bottom:.5mm;margin-bottom:.55mm}.service-pills{display:flex;flex-wrap:wrap;gap:.35mm}.pill,.data-pill{border:var(--line);border-radius:12px;background:#fff;text-align:center}.pill{font-weight:700}.data-pill{font-weight:400}.pill{padding:.34mm .75mm;font-size:7.7pt}.post-brand{display:flex;align-items:center;justify-content:center;gap:.35mm;white-space:nowrap;font-size:8.7pt;font-weight:800}.post-brand img{width:6.5mm;height:auto;display:block}.postal-body{display:grid;grid-template-columns:minmax(0,1fr) 41mm minmax(0,1fr);gap:.45mm;align-items:stretch}.postal-body>*{min-width:0}.data-stack{display:flex;flex-direction:column;gap:.35mm}.data-pill{padding:calc(.65mm + 2px) calc(.5mm + 2px);margin-bottom:.7mm;font-size:9.05pt;line-height:1.2;overflow-wrap:anywhere}.qr-zone{display:flex;align-items:center;justify-content:center;min-height:28mm;border-right:var(--light-line);border-left:var(--light-line);padding:.3mm}#qr-code{width:36mm;height:36mm;line-height:0;overflow:hidden;background:#fff}#qr-code canvas,#qr-code img,#qr-code svg,#qr-code table{display:block;width:100%!important;height:100%!important;margin:0 auto}.barcode-zone{border-top:var(--light-line);margin-top:8mm;padding-top:1.2mm;text-align:center}#barcode-main{display:block;width:78%;height:11mm;object-fit:fill;margin:0 auto}.tracking-text{font-weight:800;font-size:8.6pt;letter-spacing:.22mm;margin-top:.15mm;direction:ltr}.destination{margin-top:.6mm;border-top:var(--line);padding:.7mm 1mm .15mm;text-align:center;font-size:10pt;font-weight:700}.destination strong{font-size:12pt}
        body.size-a6 .company-header{grid-template-columns:8.5mm minmax(0,1fr);gap:.8mm;padding:.55mm .8mm}body.size-a6 .company-header img{width:12mm;height:10mm}body.size-a6 .company-title{font-size:8.7pt}body.size-a6 .company-meta{font-size:6.1pt;margin-top:.1mm}body.size-a6 .sender-grid{grid-template-columns:28% 72%}body.size-a6 .sender-note,body.size-a6 .sender-info{padding:.55mm .7mm}body.size-a6 .sender-note{font-size:5.5pt;line-height:1.12}body.size-a6 .order-code{margin-top:.25mm;padding-top:.22mm;font-size:6.5pt}body.size-a6 .sender-info{font-size:6.55pt;line-height:1.38}body.size-a6 .receiver-info{font-size:7.55pt;line-height:1.38}body.size-a6 .products-table{font-size:6.1pt;margin-bottom:.4mm}body.size-a6 .products-table th,body.size-a6 .products-table td{padding:.32mm .35mm}body.size-a6 .payment-grid{font-size:6.25pt}body.size-a6 .payment-grid>div{padding:.38mm .5mm}body.size-a6 .receiver-info{padding:.5mm .65mm}body.size-a6 .signature-wrap{padding:.38mm}body.size-a6 .signature-grid{gap:.25mm}body.size-a6 .signature-box{min-height:7mm;padding:.3mm;font-size:5.4pt}body.size-a6 .bottom-grid{grid-template-columns:minmax(0,21fr) minmax(0,79fr);gap:.3mm}body.size-a6 .returns-box,body.size-a6 .postal-panel{padding:.4mm}body.size-a6 .returns-title{font-size:5.6pt;margin-bottom:.12mm}body.size-a6 .returns-grid{gap:.1mm .18mm}body.size-a6 .return-item{gap:.14mm;padding:.17mm 0; ;font-size:4.7pt;font-weight:400;line-height:1.02}body.size-a6 .checkbox{width:1.35mm;height:1.35mm;flex-basis:1.35mm}body.size-a6 .postal-head{gap:.2mm;padding-bottom:.28mm;margin-bottom:.3mm}body.size-a6 .pill{padding:.17mm .34mm;font-size:5.7pt}body.size-a6 .post-brand{gap:.15mm;font-size:6.3pt}body.size-a6 .post-brand img{width:4.6mm}body.size-a6 .postal-body{grid-template-columns:minmax(0,1fr) 30mm minmax(0,1fr);gap:.18mm}body.size-a6 .data-stack{gap:.18mm}body.size-a6 .data-pill{padding:calc(.34mm + 2px) calc(.24mm + 2px);margin-bottom:.55mm;font-size:6.95pt;font-weight:400;line-height:1.12}body.size-a6 .qr-zone{min-height:20mm;padding:.12mm}body.size-a6 #qr-code{width:25mm;height:25mm}body.size-a6 .barcode-zone{margin-top:8mm;padding-top:.8mm}body.size-a6 #barcode-main{width:82%;height:8mm}body.size-a6 .tracking-text{font-size:6.3pt;letter-spacing:.14mm}body.size-a6 .destination{margin-top:.25mm;padding:.35mm .45mm .08mm;font-size:7.2pt}body.size-a6 .destination strong{font-size:8.8pt}body.size-a6 .frame{margin-bottom:.35mm;border-radius:3px}
        @media(max-width:700px){.print-toolbar .print-hint{display:none}.sheet{max-width:100%;box-shadow:none}}
        @media print{html,body{background:#fff!important;width:100%!important;max-width:100%!important;overflow:visible!important}.print-toolbar{display:none!important}.sheet{width:100%!important;max-width:100%!important;margin:0!important;box-shadow:none;overflow:hidden}body.size-a5 .sheet{padding:1.2mm}body.size-a6 .sheet{padding:.7mm}.sheet,.frame,.bottom-grid,.postal-panel,.postal-body,.returns-box{max-width:100%!important}.sheet,.frame,tr,td,th,img,canvas,svg{break-inside:avoid;page-break-inside:avoid}.products-table{break-inside:auto;page-break-inside:auto}.products-table tr{break-inside:avoid;page-break-inside:avoid}}
    </style>
    <script src="<?php echo esc_url( $print['plugin_url'] . 'admin/js/JsBarcode.all.min.js' ); ?>"></script>
    <script src="<?php echo esc_url( $print['plugin_url'] . 'admin/js/qrcode.js' ); ?>"></script>
</head>
<body class="<?php echo esc_attr( implode( ' ', $body_classes ) ); ?>">
<div class="print-toolbar" role="region" aria-label="تنظیمات چاپ">
    <label for="surenapost-print-mode">مدل چاپ:</label>
    <select id="surenapost-print-mode">
        <?php foreach ( $print_modes as $mode_key => $mode_label ) : ?>
            <option value="<?php echo esc_attr( $mode_key ); ?>" <?php selected( $print_mode, $mode_key ); ?>><?php echo esc_html( $mode_label ); ?></option>
        <?php endforeach; ?>
    </select>
    <button type="button" id="surenapost-print-button">چاپ</button>
    <span class="print-hint" id="surenapost-print-hint"><?php echo esc_html( $print_modes[ $print_mode ] ); ?></span>
</div>

<div class="sheet" id="surenapost-sheet">
    <header class="company-header frame">
        <img src="<?php echo esc_url( $print['plugin_url'] . 'admin/images/logosurena.jpg' ); ?>" alt="سورنا">
        <div>
            <div class="company-title">شرکت واسط اینترنتی: (سورنا وب هیرکان)</div>
            <div class="company-meta">نشانی اینترنتی شرکت: www.surena3d.com<br><span>تلفن پشتیبانی: 09115187998</span></div>
        </div>
    </header>

    <section class="sender-grid frame">
        <div class="sender-note">
            تمامی مسئولیت‌های مرتبط با محتوای سفارش، مطابقت سفارش با درخواست مشتری و رعایت قوانین مربوطه، بر عهده فروشگاه است.
            <div class="order-code">شناسه سفارش: <?php echo $display_number( $print['order_id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
        </div>
        <div class="sender-info">
            <div><span class="label">فرستنده (فروشگاه): </span><?php echo $display( $print['store_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <div><span class="label">استان: </span><?php echo $display( $print['store_state'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span style="margin-right:3mm;"><span class="label">شهر: </span><?php echo $display( $print['store_city'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></div>
            <div><span class="label">آدرس: </span><?php echo $display( $print['store_address'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <div><span class="label">کد پستی: </span><?php echo $display_number( $print['store_postcode'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span style="margin-right:3mm;"><span class="label">تلفن: </span><?php echo $display_number( $print['store_phone'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></div>
        </div>
    </section>

    <div id="products-anchor" aria-hidden="true"></div>
    <table class="products-table" id="surenapost-products-table">
        <thead><tr><th class="col-row">ردیف</th><th class="col-product">نوع محصول</th><th class="col-qty">تعداد</th><th class="col-price">قیمت واحد<br>(ریال)</th><th class="col-price">مبلغ کل<br>(ریال)</th></tr></thead>
        <tbody>
        <?php if ( empty( $products ) ) : ?>
            <tr><td colspan="5" class="empty-products">محصولی برای این سفارش ثبت نشده است.</td></tr>
        <?php else : ?>
            <?php foreach ( $products as $index => $product ) : ?>
                <tr>
                    <td class="col-row"><?php echo $display_number( $index + 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                    <td class="col-product"><?php echo $display( isset( $product['name'] ) ? $product['name'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                    <td class="col-qty"><?php echo $display_number( isset( $product['quantity'] ) ? $product['quantity'] : 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                    <td class="col-price"><?php echo $display_number( '0' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                    <td class="col-price"><?php echo $display_number( '0' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <section class="payment-grid frame">
        <div><span class="label">نوع پرداخت: </span><?php echo $display( $print['pay_type'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
        <div><span class="label">مبلغ قابل پرداخت هنگام تحویل: </span><?php echo $display_amount( $print['pay_type_text'], '۰' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
    </section>

    <section class="recipient-grid frame">
        <div class="receiver-info">
            <div><span class="label">گیرنده (خریدار): </span><?php echo $display( $print['receiver_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <div><span class="label">استان: </span><?php echo $display( $print['province_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span style="margin-right:3mm;"><span class="label">شهر: </span><?php echo $display( $print['city_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></div>
            <div><span class="label">آدرس: </span><?php echo $display( $print['receiver_address'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <div><span class="label">کد پستی: </span><?php echo $display_number( $print['receiver_postcode'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span style="margin-right:3mm;"><span class="label">تلفن همراه: </span><?php echo $display_number( $print['receiver_mobile'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></div>
        </div>
        <div class="signature-wrap"><div class="signature-grid"><div class="signature-box">محل مهر فروشگاه</div><div class="signature-box">محل امضای خریدار</div></div></div>
    </section>

    <div class="bottom-grid">
        <section class="returns-box frame">
            <div class="returns-title">علت برگشتی:</div>
            <div class="returns-grid">
                <div class="return-item"><span class="checkbox"></span><span>عدم اطلاع از سفارش</span></div>
                <div class="return-item"><span class="checkbox"></span><span>نقل مکان</span></div>
                <div class="return-item"><span class="checkbox"></span><span>عدم وجود وجه/کارت</span></div>
                <div class="return-item"><span class="checkbox"></span><span>مغایرت مبلغ فاکتور</span></div>
                <div class="return-item"><span class="checkbox"></span><span>درخواست بازگشایی</span></div>
                <div class="return-item"><span class="checkbox"></span><span>تأخیر در ارسال</span></div>
                <div class="return-item"><span class="checkbox"></span><span>انصراف از خرید</span></div>
                <div class="return-item"><span class="checkbox"></span><span>گیرنده شناخته نشد</span></div>
                <div class="return-item"><span class="checkbox"></span><span>سفارش تکراری</span></div>
                <div class="return-item"><span class="checkbox"></span><span>سایر موارد...</span></div>
            </div>
        </section>

        <section class="postal-panel frame">
            <div class="postal-head">
                <div class="service-pills"><div class="pill">نوع سرویس: <?php echo $display( $print['post_type'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="pill">سایز کارتن: <?php echo $display_number( $print['box_size'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>
                <div class="post-brand"><img src="<?php echo esc_url( $print['plugin_url'] . 'admin/images/postlogo.png' ); ?>" alt="پست">شرکت ملی پست ایران</div>
                <div></div>
            </div>
            <div class="postal-body">
                <div class="data-stack"><div class="data-pill"><?php echo $display( $print['store_city'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="data-pill"><?php echo $display( $print['city_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="data-pill"> <?php echo $display_amount( $print['postage'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="data-pill"> <?php echo $display_amount( $print['tax'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>

                <div class="qr-zone"><div id="qr-code"></div></div>
                <div class="data-stack"><div class="data-pill"><?php echo $display_number( $print['print_date'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="data-pill"><?php echo $display_number( $print['print_time'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="data-pill">وزن: <?php echo $display_amount( $print['weight'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> گرم</div></div>
            </div>
            <div class="barcode-zone"><img id="barcode-main" alt="بارکد مرسوله"><div class="tracking-text"><?php echo $display( $tracking_code ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>
        </section>
    </div>

    <div class="destination">مقصد: <strong><?php echo $display( $print['province_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> - <?php echo $display( $print['city_name'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong></div>
</div>

<script>
    (function(){
        'use strict';
        var trackingCode=<?php echo wp_json_encode( $tracking_code, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?>;
        var qrText=<?php echo wp_json_encode( $qr_text, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?>;
        var initialMode=<?php echo wp_json_encode( $print_mode ); ?>;
        var orderId=<?php echo absint( $print['order_id'] ); ?>;
        var printCountAjaxUrl=<?php echo wp_json_encode( $print['print_count_ajax_url'] ); ?>;
        var printCountNonce=<?php echo wp_json_encode( $print['print_count_nonce'] ); ?>;
        var printCountRecorded=false;
        var modes={
            a5_products:{size:'a5',products:'inline',label:'A5 با محصول'},
            a6_products:{size:'a6',products:'inline',label:'A6 با محصول'},
            a5_products_end:{size:'a5',products:'end',label:'A5 با محصول در انتها'},
            a6_products_end:{size:'a6',products:'end',label:'A6 با محصول در انتها'},
            a6_no_products:{size:'a6',products:'none',label:'A6 بدون محصول'},
            a5_no_products:{size:'a5',products:'none',label:'A5 بدون محصول'}
        };
        function buildBarcode(){if(!trackingCode||typeof JsBarcode==='undefined'){return;}try{JsBarcode('#barcode-main',trackingCode,{format:'CODE128',height:60,displayValue:false,width:1.7,textMargin:4,margin:2});}catch(error){console.error('Surenapost barcode error:',error);}}
        function buildQrCode(){var c=document.getElementById('qr-code');if(!c||!qrText||typeof QRCode==='undefined'){return;}try{c.innerHTML='';new QRCode(c,{text:qrText,width:180,height:180,correctLevel:QRCode.CorrectLevel.M});}catch(error){console.error('Surenapost QR error:',error);}}
        function applyLayout(modeKey){
            var cfg=modes[modeKey]||modes.a5_products;
            var body=document.body,table=document.getElementById('surenapost-products-table'),anchor=document.getElementById('products-anchor'),sheet=document.getElementById('surenapost-sheet'),pageStyle=document.getElementById('surenapost-page-style'),hint=document.getElementById('surenapost-print-hint');
            body.classList.remove('size-a5','size-a6','products-inline','products-end','no-products');
            body.classList.add('size-'+cfg.size);
            body.classList.add(cfg.products==='end'?'products-end':'products-inline');
            if(cfg.products==='none'){body.classList.add('no-products');}
            if(table&&sheet&&anchor){if(cfg.products==='end'){sheet.appendChild(table);}else{anchor.parentNode.insertBefore(table,anchor.nextSibling);}}
            if(pageStyle){pageStyle.textContent='@page { size: '+(cfg.size==='a6'?'A6':'A5')+' portrait; margin: 5mm; }';}
            if(hint){hint.textContent=cfg.label;}
        }
        var storageKey='surenapost_print_mode';
        function getSavedMode(){try{var saved=window.localStorage.getItem(storageKey);return saved&&modes[saved]?saved:'';}catch(error){return '';}}
        function saveMode(modeKey){if(!modes[modeKey]){return;}try{window.localStorage.setItem(storageKey,modeKey);}catch(error){}}
        function recordPrintCount(){
            if(printCountRecorded||!orderId||!printCountAjaxUrl||!printCountNonce){return;}
            printCountRecorded=true;
            try{
                var body=new URLSearchParams();
                body.set('action','surenapost_increment_print_count');
                body.set('nonce',printCountNonce);
                body.set('order_id',String(orderId));
                fetch(printCountAjaxUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),keepalive:true}).catch(function(){printCountRecorded=false;});
            }catch(error){printCountRecorded=false;}
        }
        window.addEventListener('load',function(){
            var select=document.getElementById('surenapost-print-mode'),button=document.getElementById('surenapost-print-button');
            var savedMode=getSavedMode();
            var activeMode=savedMode||initialMode;
            buildBarcode();
            buildQrCode();
            if(select&&modes[activeMode]){select.value=activeMode;}
            applyLayout(activeMode);
            if(select){select.addEventListener('change',function(){saveMode(this.value);applyLayout(this.value);});}
            if(button){button.addEventListener('click',function(){
                var mode=select?select.value:activeMode;
                saveMode(mode);
                applyLayout(mode);
                recordPrintCount();
                var doPrint=function(){window.print();};
                if(document.fonts&&document.fonts.ready){
                    try{document.fonts.load('12px IRANSans');}catch(error){}
                    document.fonts.ready.then(doPrint).catch(doPrint);
                }else{doPrint();}
            });}
        });
        window.addEventListener('beforeprint',function(){var select=document.getElementById('surenapost-print-mode');var mode=select?select.value:(getSavedMode()||initialMode);saveMode(mode);applyLayout(mode);recordPrintCount();});
        window.addEventListener('afterprint',function(){printCountRecorded=false;});
    }());
</script>
</body>
</html>


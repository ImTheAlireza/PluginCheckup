<?php
/**
 * چک‌لیست خلاصه راه‌اندازی در داشبورد.
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$setup_status = $this->get_setup_status();
$progress     = $setup_status['total'] > 0 ? (int) round( ( $setup_status['completed'] / $setup_status['total'] ) * 100 ) : 0;
?>

<div class="surenapost-setup-summary <?php echo esc_attr( $setup_status['all_complete'] ? 'is-complete' : 'is-pending' ); ?>">
    <div class="surenapost-setup-summary-header">
        <div>
            <h2><?php esc_html_e( 'وضعیت راه‌اندازی افزونه', 'surenapost' ); ?></h2>
            <p>
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: 1: completed steps, 2: all steps. */
                        __( '%1$d مرحله از %2$d مرحله تکمیل شده است.', 'surenapost' ),
                        (int) $setup_status['completed'],
                        (int) $setup_status['total']
                    )
                );
                ?>
            </p>
        </div>

        <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost-setup' ) ); ?>" class="button button-primary">
            <?php echo esc_html( $setup_status['all_complete'] ? __( 'بررسی راه‌اندازی', 'surenapost' ) : __( 'ادامه راه‌اندازی', 'surenapost' ) ); ?>
        </a>
    </div>

    <div class="surenapost-setup-progress" aria-label="<?php esc_attr_e( 'درصد پیشرفت راه‌اندازی', 'surenapost' ); ?>">
        <span style="width: <?php echo esc_attr( $progress ); ?>%;"></span>
    </div>

    <ul class="surenapost-setup-mini-list">
        <?php foreach ( $setup_status['steps'] as $step ) : ?>
            <li class="<?php echo esc_attr( $step['complete'] ? 'is-complete' : 'is-pending' ); ?>">
                <span class="dashicons <?php echo esc_attr( $step['complete'] ? 'dashicons-yes-alt' : 'dashicons-marker' ); ?>"></span>
                <?php echo esc_html( $step['label'] ); ?>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

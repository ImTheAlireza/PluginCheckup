<?php
/**
 * مسیر قدیمی چاپ؛ برای جلوگیری از دو قالب متفاوت، به قالب امن و جدید هدایت می‌شود.
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'surenapost' ) );
}

$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;
if ( ! $order_id ) {
	wp_die( esc_html__( 'شناسه سفارش نامعتبر است.', 'surenapost' ) );
}

$print_url = wp_nonce_url(
	add_query_arg(
		array(
			'action'   => 'surenapost_print_label',
			'order_id' => $order_id,
		),
		admin_url( 'admin-post.php' )
	),
	'surenapost_print_label_' . $order_id
);

wp_safe_redirect( $print_url );
exit;

<?php
/**
 * صفحه ادمین پلاگین
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$api_manager         = new Surenapost_Api_Manager();
$wallet_client       = new Surenapost_Wallet_Client();
$payments_client     = new Surenapost_Payments_Client();
$transactions_client = new Surenapost_Transactions_Client();
$save_success = false;

// پردازش فرم قبل از نمایش
// بررسی اینکه آیا فرم ارسال شده است
/*
if ( isset( $_POST['surenapost_save_api_key'] ) || isset( $_POST['submit'] ) ) {
    // بررسی nonce
    if ( isset( $_POST['surenapost_api_nonce'] ) && wp_verify_nonce( $_POST['surenapost_api_nonce'], 'surenapost_save_api_key' ) ) {
        // بررسی دسترسی
        if ( current_user_can( 'manage_options' ) ) {
            $api_key = isset( $_POST['surenapost_api_key'] ) ? sanitize_text_field( $_POST['surenapost_api_key'] ) : '';

            // ذخیره API Key
            update_option( 'surenapost_api_key', $api_key );

            // ذخیره تنظیمات
            $settings = array(
                'environment' => isset( $_POST['surenapost_environment'] ) ? sanitize_text_field( $_POST['surenapost_environment'] ) : 'production',
                'auto_sync'   => isset( $_POST['surenapost_auto_sync'] ) ? 1 : 0,
            );
            update_option( 'surenapost_api_settings', $settings );

            $api_key = isset( $_POST['surenapost_sender_name'] ) ? sanitize_text_field( $_POST['surenapost_sender_name'] ) : '';

            update_option( 'surenapost_sender_name', isset( $_POST['surenapost_sender_name'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_name'] ) ) : '' );
            update_option( 'surenapost_sender_state', isset( $_POST['surenapost_sender_state'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_state'] ) ) : '' );
            update_option( 'surenapost_sender_city', isset( $_POST['surenapost_sender_city'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_city'] ) ) : '' );
            update_option( 'surenapost_sender_address', isset( $_POST['surenapost_sender_address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['surenapost_sender_address'] ) ) : '' );
            update_option( 'surenapost_sender_postcode', isset( $_POST['surenapost_sender_postcode'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_postcode'] ) ) : '' );
            update_option( 'surenapost_sender_phone', isset( $_POST['surenapost_sender_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_phone'] ) ) : '' );

            // پیام موفقیت
            $save_success = true;
        }
    }
}
*/
$api_key     = $api_manager->get_api_key();
$settings    = $api_manager->get_api_settings();
$environment = isset( $settings['environment'] ) ? $settings['environment'] : 'production';
$auto_sync   = isset( $settings['auto_sync'] ) ? $settings['auto_sync'] : 0;
$print_mode  = isset( $settings['print_mode'] ) ? sanitize_key( $settings['print_mode'] ) : 'a5_products';
if ( 'full' === $print_mode ) {
    $print_mode = 'a5_products';
} elseif ( 'summary' === $print_mode ) {
    $print_mode = 'a6_no_products';
}
$allowed_print_modes = array( 'a5_products', 'a6_products', 'a5_products_end', 'a6_products_end', 'a6_no_products', 'a5_no_products' );
if ( ! in_array( $print_mode, $allowed_print_modes, true ) ) {
    $print_mode = 'a5_products';
}
// تعیین تب فعلی
 if ( isset( $_GET['page'] ) ) {
    $page = sanitize_text_field( $_GET['page'] );
    if ( $page === 'surenapost-setup' ) {
        $current_tab = 'setup';
    } elseif ( $page === 'surenapost-api-settings' ) {
        $current_tab = 'api';
    } elseif ( $page === 'surenapost-reports' ) {
        $current_tab = 'reports';
    } elseif ( $page === 'surenapost-pay' ) {
        $current_tab = 'pay';
    } elseif ( $page === 'surenapost-transactions' ) {
        $current_tab = 'transactions';
    } elseif ( $page === 'surenapost-update' ) {
        $current_tab = 'update';
    } elseif ( $page === 'surenapost-tracking' ) {
        $current_tab = 'tracking';
    } else {
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'dashboard';
    }
} else {
    $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'dashboard';
}


$tabs = array(
    'dashboard'    => __( 'داشبورد', 'surenapost' ),
    'setup'        => __( 'راه‌اندازی اولیه', 'surenapost' ),
    'api'          => __( 'تنظیمات API', 'surenapost' ),
    'reports'      => __( 'گزارش‌ها', 'surenapost' ),
    'pay'          => __( 'موجودی', 'surenapost' ),
    'transactions' => __( 'ریز تراکنش‌ها', 'surenapost' ),
    'tracking'     => __( 'لیست بارکدها', 'surenapost' ),
    'update'       => __( 'بروزرسانی وابستگی‌ها', 'surenapost' ),
);
?>

<div class="wrap surenapost-admin-wrap">
    <h1 class="surenapost-admin-title">
        <span class="dashicons dashicons-email-alt"></span>
        <?php echo esc_html__( 'سورنا پست', 'surenapost' ); ?>
    </h1>

    <nav class="nav-tab-wrapper surenapost-nav-tabs">
        <?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost&tab=' . $tab_key ) ); ?>"
               class="nav-tab <?php echo esc_attr( $current_tab === $tab_key ? 'nav-tab-active' : '' ); ?>">
                <?php echo esc_html( $tab_label ); ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="surenapost-tab-content">
        <?php if ( 'dashboard' === $current_tab ) : ?>
            <div class="surenapost-dashboard">
                <div class="surenapost-welcome-card">
                    <h2><?php echo esc_html__( 'خوش آمدید به پنل مدیریت سورنا پست', 'surenapost' ); ?></h2>
                    <p><?php echo esc_html__( 'از این پنل می‌توانید تمامی تنظیمات و خدمات پستی خود را مدیریت کنید.', 'surenapost' ); ?></p>
                </div>

                <?php include SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-setup-checklist.php'; ?>

                <div class="surenapost-status-cards">
                    <div class="surenapost-status-card <?php echo esc_attr( $api_manager->has_api_key() ? 'status-active' : 'status-inactive' ); ?>">
                        <div class="status-icon">
                            <span class="dashicons <?php echo esc_attr( $api_manager->has_api_key() ? 'dashicons-yes-alt' : 'dashicons-warning' ); ?>"></span>
                        </div>
                        <div class="status-content">
                            <h3><?php echo esc_html__( 'وضعیت API', 'surenapost' ); ?></h3>
                            <p>
                                <?php if ( $api_manager->has_api_key() ) : ?>
                                    <?php echo esc_html__( 'API Key تنظیم شده است', 'surenapost' ); ?>
                                <?php else : ?>
                                    <?php echo esc_html__( 'API Key تنظیم نشده است', 'surenapost' ); ?>
                                <?php endif; ?>
                            </p>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost&tab=api' ) ); ?>" class="button button-primary">
                                <?php echo esc_html__( 'تنظیم API Key', 'surenapost' ); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        <?php elseif ( 'setup' === $current_tab ) : ?>
            <?php include SURENAPOST_PLUGIN_DIR . 'admin/partials/surenapost-setup.php'; ?>

        <?php elseif ( 'api' === $current_tab ) : ?>
            <div class="surenapost-api-settings">
                <h2><?php echo esc_html__( 'تنظیمات API', 'surenapost' ); ?></h2>
                <p class="description"><?php echo esc_html__( 'API Key خود را از پنل مدیریت سورنا پست دریافت کرده و در اینجا وارد کنید.', 'surenapost' ); ?></p>

                <?php
                // نمایش پیام موفقیت
                if ( isset( $save_success ) && $save_success ) {
                    ?>
                    <div class="notice notice-success is-dismissible">
                        <p><strong><?php echo esc_html__( 'موفق:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'تنظیمات با موفقیت ذخیره شد.', 'surenapost' ); ?></p>
                    </div>
                    <?php
                }
                $api_manager->success_notice();
                $sender_name     = get_option( 'surenapost_sender_name', get_bloginfo( 'name' ) );

                $sender_state    = get_option( 'surenapost_sender_state', '' );
                $sender_city     = get_option( 'surenapost_sender_city', get_option( 'woocommerce_store_city', '' ) );
                $sender_address  = get_option( 'surenapost_sender_address', get_option( 'woocommerce_store_address', '' ) );
                $sender_postcode = get_option( 'surenapost_sender_postcode', get_option( 'woocommerce_store_postcode', '' ) );
                $sender_phone    = get_option( 'surenapost_sender_phone', get_option( 'woocommerce_store_phone', '' ) );
                ?>

                <form method="post" action="" class="surenapost-api-form">
                    <?php wp_nonce_field( 'surenapost_save_api_key', 'surenapost_api_nonce' ); ?>

                    <table class="form-table">
                        <tbody>
                        <tr>
                            <th scope="row">
                                <label for="surenapost_api_key"><?php echo esc_html__( 'API Key', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_api_key"
                                       name="surenapost_api_key"
                                       value="<?php echo esc_attr( $api_key ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'API Key خود را وارد کنید', 'surenapost' ); ?>" />
                                <p class="description">
                                    <?php echo esc_html__( 'API Key شما به صورت امن در دیتابیس ذخیره می‌شود.', 'surenapost' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_environment"><?php echo esc_html__( 'محیط', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <select id="surenapost_environment" name="surenapost_environment" class="regular-text">
                                    <option value="production" <?php selected( $environment, 'production' ); ?>>
                                        <?php echo esc_html__( 'تولید (Production)', 'surenapost' ); ?>
                                    </option>
                                    <option value="sandbox" <?php selected( $environment, 'sandbox' ); ?>>
                                        <?php echo esc_html__( 'تست (Sandbox)', 'surenapost' ); ?>
                                    </option>
                                </select>
                                <p class="description">
                                    <?php echo esc_html__( 'محیط API را انتخاب کنید.', 'surenapost' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_name"><?php echo esc_html__( 'نام فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_sender_name"
                                       name="surenapost_sender_name"
                                       value="<?php echo esc_attr( $sender_name ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'مثلاً نام فروشگاه یا نام فرستنده', 'surenapost' ); ?>" />
                                <p class="description">
                                    <?php echo esc_html__( 'این نام در برگه چاپ مرسوله نمایش داده می‌شود.', 'surenapost' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_state"><?php echo esc_html__( 'استان فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_sender_state"
                                       name="surenapost_sender_state"
                                       value="<?php echo esc_attr( $sender_state ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'مثلاً تهران', 'surenapost' ); ?>" />
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_city"><?php echo esc_html__( 'شهر فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_sender_city"
                                       name="surenapost_sender_city"
                                       value="<?php echo esc_attr( $sender_city ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'مثلاً تهران', 'surenapost' ); ?>" />
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_address"><?php echo esc_html__( 'آدرس فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
        <textarea id="surenapost_sender_address"
                  name="surenapost_sender_address"
                  rows="4"
                  class="large-text"
                  placeholder="<?php echo esc_attr__( 'آدرس کامل فرستنده', 'surenapost' ); ?>"><?php echo esc_textarea( $sender_address ); ?></textarea>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_postcode"><?php echo esc_html__( 'کد پستی فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_sender_postcode"
                                       name="surenapost_sender_postcode"
                                       value="<?php echo esc_attr( $sender_postcode ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'مثلاً 1234567890', 'surenapost' ); ?>" />
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="surenapost_sender_phone"><?php echo esc_html__( 'تلفن فرستنده', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <input type="text"
                                       id="surenapost_sender_phone"
                                       name="surenapost_sender_phone"
                                       value="<?php echo esc_attr( $sender_phone ); ?>"
                                       class="regular-text"
                                       placeholder="<?php echo esc_attr__( 'شماره تماس فرستنده', 'surenapost' ); ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="surenapost_print_mode"><?php echo esc_html__( 'حالت پیش‌فرض چاپ', 'surenapost' ); ?></label>
                            </th>
                            <td>
                                <select id="surenapost_print_mode" name="surenapost_print_mode" class="regular-text">
                                    <option value="a5_products" <?php selected( $print_mode, 'a5_products' ); ?>><?php echo esc_html__( 'A5 با محصول', 'surenapost' ); ?></option>
                                    <option value="a6_products" <?php selected( $print_mode, 'a6_products' ); ?>><?php echo esc_html__( 'A6 با محصول', 'surenapost' ); ?></option>
                                    <option value="a5_products_end" <?php selected( $print_mode, 'a5_products_end' ); ?>><?php echo esc_html__( 'A5 با محصول در انتها', 'surenapost' ); ?></option>
                                    <option value="a6_products_end" <?php selected( $print_mode, 'a6_products_end' ); ?>><?php echo esc_html__( 'A6 با محصول در انتها', 'surenapost' ); ?></option>
                                    <option value="a6_no_products" <?php selected( $print_mode, 'a6_no_products' ); ?>><?php echo esc_html__( 'A6 بدون محصول', 'surenapost' ); ?></option>
                                    <option value="a5_no_products" <?php selected( $print_mode, 'a5_no_products' ); ?>><?php echo esc_html__( 'A5 بدون محصول', 'surenapost' ); ?></option>
                                </select>
                                <p class="description">
                                    <?php echo esc_html__( 'این فقط حالت پیش‌فرض است؛ در صفحه چاپ می‌توانید قبل از چاپ، هر بار یکی از شش مدل را انتخاب کنید.', 'surenapost' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <?php echo esc_html__( 'همگام‌سازی خودکار', 'surenapost' ); ?>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox"
                                           name="surenapost_auto_sync"
                                           value="1"
                                        <?php checked( $auto_sync, 1 ); ?> />
                                    <?php echo esc_html__( 'فعال‌سازی همگام‌سازی خودکار', 'surenapost' ); ?>
                                </label>
                                <p class="description">
                                    <?php echo esc_html__( 'در صورت فعال بودن، اطلاعات به صورت خودکار همگام‌سازی می‌شود.', 'surenapost' ); ?>
                                </p>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <p class="submit">
                        <input type="hidden" name="surenapost_save_api_key" value="2">
                        <input type="submit" name="" id="surenapost_save_api_key" class="button button-primary" value="<?php echo esc_attr__( 'ذخیره تنظیمات', 'surenapost' ); ?>" />
                    </p>
                </form>

                <?php if ( $api_manager->has_api_key() ) : ?>
                    <div class="surenapost-api-status">
                        <h3><?php echo esc_html__( 'وضعیت اتصال', 'surenapost' ); ?></h3>
                        <p class="status-message">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <?php echo esc_html__( 'API Key تنظیم شده است و آماده استفاده می‌باشد.', 'surenapost' ); ?>
                        </p>
                    </div>
                    <div class="notice notice-warning inline" style="padding:12px 14px;">
                        <p style="margin:0 0 10px;">
                            <?php esc_html_e( 'توجه: قبل از ثبت درخواست، لیست شهرها، استان‌ها و اطلاعات وابسته را بروزرسانی کنید.', 'surenapost' ); ?>
                        </p>

                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost&tab=update' ) ); ?>"
                           class="button button-secondary">
                            <?php esc_html_e( 'بروزرسانی لیست‌ها', 'surenapost' ); ?>
                        </a>
                    </div>
                    <div class="surenapost-locations-cache-tools" style="margin-top:20px;display: none">
                        <h3><?php echo esc_html__( 'کش استان‌ها و شهرها', 'surenapost' ); ?></h3>
                        <p class="description">
                            <?php echo esc_html__( 'اگر در زمان اشتباه بودن توکن، لیست استان و شهر کش شده است، می‌توانید با دکمه زیر کش را پاک کنید تا اطلاعات جدید از API خوانده شود.', 'surenapost' ); ?>
                        </p>
                        <p>
                            <button type="button"
                                    class="button button-secondary"
                                    id="surenapost-clear-locations-cache">
                                <?php echo esc_html__( 'پاک کردن کش استان‌ها و شهرها', 'surenapost' ); ?>
                            </button>
                            <span id="surenapost-clear-locations-cache-message" style="margin-right:10px;"></span>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

        <?php
        elseif ( 'reports' === $current_tab ) :
            // دریافت پارامترهای فیلتر از URL
            $current_page    = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
            $per_page        = isset( $_GET['per_page'] ) ? absint( $_GET['per_page'] ) : 10;
            $payment_id      = isset( $_GET['payment_id'] ) ? sanitize_text_field( $_GET['payment_id'] ) : '';
            $start_date      = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : '';
            $end_date        = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : '';
            $gateway_filter  = isset( $_GET['gateway'] ) ? sanitize_text_field( $_GET['gateway'] ) : '';
            $status_filter   = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';

            // دریافت وابستگی‌های لیست پرداخت (درگاه‌ها و وضعیت‌ها)
            $dependencies = $payments_client->fetch_dependencies( $api_key );

            if ( is_wp_error( $dependencies ) ) {
                // در صورت خطا، از مقادیر پیش‌فرض استفاده می‌کنیم
                $gateways = $payments_client->fetch_gateways( $api_key );
                $statuses = $payments_client->fetch_statuses( $api_key );
            } else {
                $gateways = isset( $dependencies['gateways'] ) ? $dependencies['gateways'] : array();
                $statuses = isset( $dependencies['statuses'] ) ? $dependencies['statuses'] : array();
            }

            // آماده‌سازی پارامترهای درخواست
            $payment_params = array(
                'page'       => $current_page,
                'per_page'   => $per_page,
                'payment_id' => $payment_id,
                'start_date' => $start_date,
                'end_date'   => $end_date,
                'gateway'    => $gateway_filter,
                'status'     => $status_filter,
            );

            // دریافت داده‌های پرداخت
            $payments_data = $payments_client->fetch_payments( $api_key, $payment_params );
            ?>
            <div class="surenapost-reports">
                <h2><?php echo esc_html__( 'گزارش پرداخت‌ها', 'surenapost' ); ?></h2>
                <p class="description"><?php echo esc_html__( 'لیست تمامی پرداخت‌های فروشگاه در این بخش نمایش داده می‌شود.', 'surenapost' ); ?></p>

                <?php if ( ! $api_manager->has_api_key() ) : ?>
                    <div class="notice notice-error">
                        <p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'لطفاً ابتدا API Key را در تب تنظیمات API وارد کنید.', 'surenapost' ); ?></p>
                    </div>
                <?php else : ?>
                    <!-- فرم جستجو و فیلتر -->
                    <div class="surenapost-reports-filters">
                        <form method="get" action="" class="surenapost-filter-form">
                            <input type="hidden" name="page" value="<?php echo esc_attr( isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : 'surenapost-reports' ); ?>">
                            <input type="hidden" name="tab" value="reports">

                            <table class="form-table">
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        <label for="payment_id"><?php echo esc_html__( 'شناسه پرداخت', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="payment_id"
                                               name="payment_id"
                                               value="<?php echo esc_attr( $payment_id ); ?>"
                                               class="regular-text"
                                               placeholder="<?php echo esc_attr__( 'شناسه پرداخت', 'surenapost' ); ?>">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="start_date"><?php echo esc_html__( 'تاریخ شروع', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="start_date"
                                               name="start_date"
                                               value="<?php echo esc_attr( $start_date ); ?>"
                                               class="regular-text"
                                               placeholder="<?php echo esc_attr__( 'مثال: 01-01-1404', 'surenapost' ); ?>">
                                        <p class="description"><?php echo esc_html__( 'فرمت: DD-MM-YYYY (مثال: 01-01-1404)', 'surenapost' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="end_date"><?php echo esc_html__( 'تاریخ پایان', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="end_date"
                                               name="end_date"
                                               value="<?php echo esc_attr( $end_date ); ?>"
                                               class="regular-text"
                                               placeholder="<?php echo esc_attr__( 'مثال: 31-12-1404', 'surenapost' ); ?>">
                                        <p class="description"><?php echo esc_html__( 'فرمت: DD-MM-YYYY (مثال: 31-12-1404)', 'surenapost' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="gateway"><?php echo esc_html__( 'درگاه پرداخت', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <select id="gateway" name="gateway" class="regular-text">
                                            <option value=""><?php echo esc_html__( 'همه', 'surenapost' ); ?></option>
                                            <?php if ( is_array( $gateways ) ) : ?>
                                                <?php foreach ( $gateways as $gateway_key => $gateway_label ) : ?>
                                                    <option value="<?php echo esc_attr( $gateway_key ); ?>" <?php selected( $gateway_filter, $gateway_key ); ?>>
                                                        <?php echo esc_html( $gateway_label ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="status"><?php echo esc_html__( 'وضعیت', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <select id="status" name="status" class="regular-text">
                                            <option value=""><?php echo esc_html__( 'همه', 'surenapost' ); ?></option>
                                            <?php if ( is_array( $statuses ) ) : ?>
                                                <?php foreach ( $statuses as $status_key => $status_label ) : ?>
                                                    <option value="<?php echo esc_attr( $status_key ); ?>" <?php selected( $status_filter, $status_key ); ?>>
                                                        <?php echo esc_html( $status_label ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="per_page"><?php echo esc_html__( 'تعداد در هر صفحه', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <select id="per_page" name="per_page" class="regular-text">
                                            <option value="10" <?php selected( $per_page, 10 ); ?>>10</option>
                                            <option value="25" <?php selected( $per_page, 25 ); ?>>25</option>
                                            <option value="50" <?php selected( $per_page, 50 ); ?>>50</option>
                                            <option value="100" <?php selected( $per_page, 100 ); ?>>100</option>
                                        </select>
                                    </td>
                                </tr>
                                </tbody>
                            </table>

                            <p class="submit">
                                <input type="submit" name="filter_payments" class="button button-primary" value="<?php echo esc_attr__( 'جستجو', 'surenapost' ); ?>">
                                <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost-reports&tab=reports' ) ); ?>" class="button">
                                    <?php echo esc_html__( 'پاک کردن فیلترها', 'surenapost' ); ?>
                                </a>
                            </p>
                        </form>
                    </div>

                    <!-- جدول پرداخت‌ها -->
                    <div class="surenapost-payments-table">
                        <?php if ( is_wp_error( $payments_data ) ) : ?>
                            <div class="notice notice-error">
                                <p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html( $payments_data->get_error_message() ); ?></p>
                            </div>
                        <?php else :
                            $payments = isset( $payments_data['output']['data'] ) ? $payments_data['output']['data'] : ( isset( $payments_data['data'] ) ? $payments_data['data'] : array() );
                            $total_items = isset( $payments_data['output']['total'] ) ? $payments_data['output']['total'] : ( isset( $payments_data['total'] ) ? $payments_data['total'] : 0 );
                            $total_pages = isset( $payments_data['output']['last_page'] ) ? $payments_data['output']['last_page'] : ( isset( $payments_data['last_page'] ) ? $payments_data['last_page'] : 1 );
                            ?>

                            <?php if ( empty( $payments ) ) : ?>
                            <div class="notice notice-info">
                                <p><?php echo esc_html__( 'هیچ پرداختی یافت نشد.', 'surenapost' ); ?></p>
                            </div>
                        <?php else : ?>
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                <tr>
                                    <th scope="col"><?php echo esc_html__( 'شناسه', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'مبلغ (تومان)', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'درگاه پرداخت', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'وضعیت', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'توضیحات', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'زمان شروع', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'زمان تکمیل', 'surenapost' ); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $payments as $payment ) :
                                    $payment_id_val = isset( $payment['id'] ) ? $payment['id'] : '';
                                    $amount = isset( $payment['amount'] ) ? $payment['amount'] : 0;
                                    $gateway = isset( $payment['gateway'] ) ? $payment['gateway'] : '';
                                    $status = isset( $payment['status'] ) ? $payment['status'] : '';
                                    $description = isset( $payment['description'] ) ? $payment['description'] : '';
                                    $registration_time = isset( $payment['registration_time'] ) ? $payment['registration_time'] : '';
                                    $completion_time = isset( $payment['completion_time'] ) ? $payment['completion_time'] : '';

                                    // تبدیل وضعیت به متن قابل خواندن
                                    $status_label = $status;
                                    if ( is_array( $statuses ) && isset( $statuses[ $status ] ) ) {
                                        $status_label = $statuses[ $status ];
                                    }

                                    // تبدیل درگاه به متن قابل خواندن
                                    $gateway_label = $gateway;
                                    if ( is_array( $gateways ) && isset( $gateways[ $gateway ] ) ) {
                                        $gateway_label = $gateways[ $gateway ];
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html( $payment_id_val ); ?></td>
                                        <td><?php echo esc_html( number_format( $amount ) ); ?></td>
                                        <td><?php echo esc_html( $gateway_label ); ?></td>
                                        <td>
                                                    <span class="payment-status status-<?php echo esc_attr( $status ); ?>">
                                                        <?php echo esc_html( $status_label ); ?>
                                                    </span>
                                        </td>
                                        <td><?php echo esc_html( $description ); ?></td>
                                        <td><?php echo esc_html( $registration_time ); ?></td>
                                        <td><?php echo esc_html( $completion_time ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>

                            <!-- صفحه‌بندی -->
                            <?php if ( $total_pages > 1 ) :
                                $base_url = admin_url( 'admin.php?page=surenapost-reports&tab=reports' );
                                $base_url = add_query_arg( array(
                                    'payment_id' => $payment_id,
                                    'start_date' => $start_date,
                                    'end_date' => $end_date,
                                    'gateway' => $gateway_filter,
                                    'status' => $status_filter,
                                    'per_page' => $per_page,
                                ), $base_url );
                                ?>
                                <div class="surenapost-pagination">
                                    <?php
                                    echo paginate_links( array(
                                        'base' => $base_url . '%_%',
                                        'format' => '&paged=%#%',
                                        'current' => $current_page,
                                        'total' => $total_pages,
                                        'prev_text' => __( '&laquo; قبلی', 'surenapost' ),
                                        'next_text' => __( 'بعدی &raquo;', 'surenapost' ),
                                    ) );
                                    ?>
                                </div>
                                <p class="surenapost-pagination-info">
                                    <?php
                                    printf(
                                        esc_html__( 'نمایش %d تا %d از %d پرداخت', 'surenapost' ),
                                        ( ( $current_page - 1 ) * $per_page ) + 1,
                                        min( $current_page * $per_page, $total_items ),
                                        $total_items
                                    );
                                    ?>
                                </p>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php
        elseif ( 'pay' === $current_tab ) : ?>
            <div class="surenapost-pay modern-wallet">
                <h2><?php echo esc_html__( 'موجودی کیف‌پول', 'surenapost' ); ?></h2>
                <div class="surenapost-wallet-status">
                    <?php
                    $wallet_info = $wallet_client->fetch_balance( $api_key );
                    if ( is_wp_error( $wallet_info ) ) {
                        ?>
                        <div class="wallet-error">
                            <p><?php echo esc_html( $wallet_info->get_error_message() ); ?></p>
                        </div>
                        <?php
                    } else {
                        $balance           = isset( $wallet_info['balance'] ) ? $wallet_info['balance'] : 0;
                        $credit_limit      = isset( $wallet_info['credit_limit'] ) ? $wallet_info['credit_limit'] : 0;
                        $available_balance = isset( $wallet_info['available_balance'] ) ? $wallet_info['available_balance'] : ( $balance + $credit_limit );
                        ?>
                        <div class="wallet-item balance">
                            <span class="icon">💰</span>
                            <p><?php echo esc_html__( 'موجودی فعلی کیف‌پول:', 'surenapost' ) . ' ' . esc_html( number_format($balance )); ?></p>
                        </div>
                        <div class="wallet-item credit">
                            <span class="icon">📝</span>
                            <p><?php echo esc_html__( 'مقدار مجوز خرید اعتباری:', 'surenapost' ) . ' ' . esc_html( number_format($credit_limit )); ?></p>
                        </div>
                        <div class="wallet-item available">
                            <span class="icon">✅</span>
                            <p><?php echo esc_html__( 'موجودی قابل استفاده (موجودی + اعتبار):', 'surenapost' ) . ' ' . esc_html(number_format( $available_balance ) ); ?></p>
                        </div>
                        <?php
                    }
                    ?>
                    <a href="#" id="openWalletModal" class="button button-primary">
                        افزایش اعتبار
                    </a>

                    <div id="walletModal" style="display:none;">
                        <div class="wallet-modal-content">
                            <h3>افزایش اعتبار کیف پول</h3>

                            <input type="number" id="wallet_amount" placeholder="مبلغ (تومان)" min="1000">

                            <button id="walletSubmit" class="button button-primary">
                                پرداخت
                            </button>

                            <button id="walletClose" class="button">
                                انصراف
                            </button>
                        </div>
                    </div>


                </div>
            </div>

        <?php
        elseif ( 'transactions' === $current_tab ) :
            // دریافت پارامترهای فیلتر از URL
            $current_page    = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
            $per_page        = isset( $_GET['per_page'] ) ? absint( $_GET['per_page'] ) : 10;
            $start_date      = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : '';
            $end_date        = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : '';
            $type_filter     = isset( $_GET['type'] ) ? sanitize_text_field( $_GET['type'] ) : '';

            // دریافت وابستگی‌های لیست تراکنش‌ها (نوع تراکنش)
            $dependencies = $transactions_client->fetch_dependencies( $api_key );

            if ( is_wp_error( $dependencies ) ) {
                // در صورت خطا، از مقادیر پیش‌فرض استفاده می‌کنیم
                $types = $transactions_client->get_default_types();
            } else {
                $types = isset( $dependencies['types'] ) ? $dependencies['types'] : array();
            }

            // آماده‌سازی پارامترهای درخواست
            $transaction_params = array(
                'page'       => $current_page,
                'per_page'   => $per_page,
                'start_date' => $start_date,
                'end_date'   => $end_date,
                'type'       => $type_filter,
            );

            // دریافت داده‌های تراکنش
            $transactions_data = $transactions_client->fetch_transactions( $api_key, $transaction_params );
            ?>
            <div class="surenapost-transactions">
                <h2><?php echo esc_html__( 'ریز تراکنش‌های کیف‌پول', 'surenapost' ); ?></h2>
                <p class="description"><?php echo esc_html__( 'لیست تمامی تراکنش‌هایی که در کیف‌پول اتفاق افتاده است.', 'surenapost' ); ?></p>

                <?php if ( ! $api_manager->has_api_key() ) : ?>
                    <div class="notice notice-error">
                        <p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'لطفاً ابتدا API Key را در تب تنظیمات API وارد کنید.', 'surenapost' ); ?></p>
                    </div>
                <?php else : ?>
                    <!-- فرم جستجو و فیلتر -->
                    <div class="surenapost-transactions-filters">
                        <form method="get" action="" class="surenapost-filter-form">
                            <input type="hidden" name="page" value="<?php echo esc_attr( isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : 'surenapost-transactions' ); ?>">
                            <input type="hidden" name="tab" value="transactions">

                            <table class="form-table">
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        <label for="start_date"><?php echo esc_html__( 'تاریخ شروع', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="start_date"
                                               name="start_date"
                                               value="<?php echo esc_attr( $start_date ); ?>"
                                               class="regular-text"
                                               placeholder="<?php echo esc_attr__( 'مثال: 01-01-1404', 'surenapost' ); ?>">
                                        <p class="description"><?php echo esc_html__( 'فرمت: DD-MM-YYYY (مثال: 01-01-1404)', 'surenapost' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="end_date"><?php echo esc_html__( 'تاریخ پایان', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="end_date"
                                               name="end_date"
                                               value="<?php echo esc_attr( $end_date ); ?>"
                                               class="regular-text"
                                               placeholder="<?php echo esc_attr__( 'مثال: 31-12-1404', 'surenapost' ); ?>">
                                        <p class="description"><?php echo esc_html__( 'فرمت: DD-MM-YYYY (مثال: 31-12-1404)', 'surenapost' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="type"><?php echo esc_html__( 'نوع تراکنش', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <select id="type" name="type" class="regular-text">
                                            <option value=""><?php echo esc_html__( 'همه', 'surenapost' ); ?></option>
                                            <?php if ( is_array( $types ) ) : ?>
                                                <?php foreach ( $types as $type_key => $type_label ) : ?>
                                                    <option value="<?php echo esc_attr( $type_key ); ?>" <?php selected( $type_filter, $type_key ); ?>>
                                                        <?php echo esc_html( $type_label ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="per_page"><?php echo esc_html__( 'تعداد در هر صفحه', 'surenapost' ); ?></label>
                                    </th>
                                    <td>
                                        <select id="per_page" name="per_page" class="regular-text">
                                            <option value="10" <?php selected( $per_page, 10 ); ?>>10</option>
                                            <option value="25" <?php selected( $per_page, 25 ); ?>>25</option>
                                            <option value="50" <?php selected( $per_page, 50 ); ?>>50</option>
                                            <option value="100" <?php selected( $per_page, 100 ); ?>>100</option>
                                        </select>
                                    </td>
                                </tr>
                                </tbody>
                            </table>

                            <p class="submit">
                                <input type="submit" name="filter_transactions" class="button button-primary" value="<?php echo esc_attr__( 'جستجو', 'surenapost' ); ?>">
                                <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost-transactions&tab=transactions' ) ); ?>" class="button">
                                    <?php echo esc_html__( 'پاک کردن فیلترها', 'surenapost' ); ?>
                                </a>
                            </p>
                        </form>
                    </div>

                    <!-- جدول تراکنش‌ها -->
                    <div class="surenapost-transactions-table">
                        <?php if ( is_wp_error( $transactions_data ) ) : ?>
                            <div class="notice notice-error">
                                <p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html( $transactions_data->get_error_message() ); ?></p>
                            </div>
                        <?php else :
                            $transactions = isset( $transactions_data['output']['data'] ) ? $transactions_data['output']['data'] : ( isset( $transactions_data['data'] ) ? $transactions_data['data'] : array() );
                            $total_items = isset( $transactions_data['output']['total'] ) ? $transactions_data['output']['total'] : ( isset( $transactions_data['total'] ) ? $transactions_data['total'] : 0 );
                            $total_pages = isset( $transactions_data['output']['last_page'] ) ? $transactions_data['output']['last_page'] : ( isset( $transactions_data['last_page'] ) ? $transactions_data['last_page'] : 1 );
                            ?>

                            <?php if ( empty( $transactions ) ) : ?>
                            <div class="notice notice-info">
                                <p><?php echo esc_html__( 'هیچ تراکنشی یافت نشد.', 'surenapost' ); ?></p>
                            </div>
                        <?php else : ?>
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                <tr>
                                    <th scope="col"><?php echo esc_html__( 'مبلغ (تومان)', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'نوع تراکنش', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'توضیحات', 'surenapost' ); ?></th>
                                    <th scope="col"><?php echo esc_html__( 'زمان تراکنش', 'surenapost' ); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $transactions as $transaction ) :
                                    $amount = isset( $transaction['amount'] ) ? $transaction['amount'] : 0;
                                    $type = isset( $transaction['type'] ) ? $transaction['type'] : '';
                                    $description = isset( $transaction['description'] ) ? $transaction['description'] : '';
                                    $date = isset( $transaction['date'] ) ? $transaction['date'] : '';

                                    // تبدیل نوع تراکنش به متن قابل خواندن
                                    $type_label = $type;
                                    if ( is_array( $types ) && isset( $types[ $type ] ) ) {
                                        $type_label = $types[ $type ];
                                    }

                                    // تعیین کلاس برای نمایش مبلغ (مثبت/منفی)
                                    $amount_class = ( $amount >= 0 ) ? 'amount-positive' : 'amount-negative';
                                    ?>
                                    <tr>
                                        <td class="<?php echo esc_attr( $amount_class ); ?>">
                                            <?php echo esc_html( number_format( $amount ) ); ?>
                                        </td>
                                        <td>
                                                    <span class="transaction-type type-<?php echo esc_attr( $type ); ?>">
                                                        <?php echo esc_html( $type_label ); ?>
                                                    </span>
                                        </td>
                                        <td><?php echo esc_html( $description ); ?></td>
                                        <td><?php echo esc_html( $date ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>

                            <!-- صفحه‌بندی -->
                            <?php if ( $total_pages > 1 ) :
                                $base_url = admin_url( 'admin.php?page=surenapost-transactions&tab=transactions' );
                                $base_url = add_query_arg( array(
                                    'start_date' => $start_date,
                                    'end_date' => $end_date,
                                    'type' => $type_filter,
                                    'per_page' => $per_page,
                                ), $base_url );
                                ?>
                                <div class="surenapost-pagination">
                                    <?php
                                    echo paginate_links( array(
                                        'base' => $base_url . '%_%',
                                        'format' => '&paged=%#%',
                                        'current' => $current_page,
                                        'total' => $total_pages,
                                        'prev_text' => __( '&laquo; قبلی', 'surenapost' ),
                                        'next_text' => __( 'بعدی &raquo;', 'surenapost' ),
                                    ) );
                                    ?>
                                </div>
                                <p class="surenapost-pagination-info">
                                    <?php
                                    printf(
                                        esc_html__( 'نمایش %d تا %d از %d تراکنش', 'surenapost' ),
                                        ( ( $current_page - 1 ) * $per_page ) + 1,
                                        min( $current_page * $per_page, $total_items ),
                                        $total_items
                                    );
                                    ?>
                                </p>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

        <?php elseif ( 'tracking' === $current_tab ) : ?>
            <?php
            // دریافت پارامترهای جستجو و صفحه‌بندی
            $search_date     = isset( $_GET['time1w'] ) ? sanitize_text_field( $_GET['time1w'] ) : '';
            $order_id_filter = isset( $_GET['priceid'] ) ? intval( $_GET['priceid'] ) : 0;
            $status_filter   = isset( $_GET['post_s'] ) ? sanitize_text_field( $_GET['post_s'] ) : '9';
            $current_page    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
            $per_page        = isset( $_GET['per_page'] ) ? max( 10, absint( $_GET['per_page'] ) ) : 20;

            // فقط سفارش‌هایی نمایش داده شوند که واقعاً وارد جریان سورناپست شده‌اند.
            // وضعیت صفر یا متای ناموجود یعنی هنوز هیچ عملیات سورناپستی برای سفارش انجام نشده است.
            $meta_query = array(
                'relation' => 'AND',
                array(
                    'key'     => '_surenapost_status',
                    'value'   => array( '1', '2', '3', '4' ),
                    'compare' => 'IN',
                ),
            );

            // فیلتر اختیاری بر اساس وضعیت سورناپست.
            if ( in_array( $status_filter, array( '1', '2', '3', '4' ), true ) ) {
                $meta_query[] = array(
                    'key'     => '_surenapost_status',
                    'value'   => $status_filter,
                    'compare' => '=',
                );
            }

            // فیلتر بر اساس تاریخ (اختیاری) - اگر پر شد، فقط همان روز را در نظر می‌گیریم
            if ( ! empty( $search_date ) ) {
                $start_timestamp = strtotime( $search_date . ' 00:00:00' );
                $end_timestamp   = strtotime( $search_date . ' 23:59:59' );
                if ( $start_timestamp && $end_timestamp ) {
                    $meta_query[] = array(
                        'key'     => '_surenapost_times',
                        'value'   => array( $start_timestamp, $end_timestamp ),
                        'compare' => 'BETWEEN',
                        'type'    => 'NUMERIC',
                    );
                }
            }

            /**
             * ساخت query برای دریافت سفارش‌ها با صفحه‌بندی.
             *
             * در HPOS استفاده از meta_query در wc_get_orders مسیر استاندارد است.
             * در ذخیره‌سازی کلاسیک سفارش‌ها، برای سازگاری با نسخه‌های مختلف ووکامرس
             * مستقیماً از WP_Query استفاده می‌کنیم؛ چون بعضی نسخه‌ها meta_query را در
             * WC_Order_Query کلاسیک نادیده می‌گیرند و تمام سفارش‌ها را برمی‌گردانند.
             */
            $filtered_orders = array();
            $total_items     = 0;
            $total_pages     = 1;
            $order_util      = '\Automattic\WooCommerce\Utilities\OrderUtil';
            $hpos_enabled    = class_exists( $order_util )
                && is_callable( array( $order_util, 'custom_orders_table_usage_is_enabled' ) )
                && $order_util::custom_orders_table_usage_is_enabled();

            if ( $hpos_enabled ) {
                $args = array(
                    'type'       => 'shop_order',
                    'status'     => 'any',
                    'orderby'    => 'date',
                    'order'      => 'DESC',
                    'limit'      => $per_page,
                    'page'       => $current_page,
                    'paginate'   => true,
                    'meta_query' => $meta_query,
                );

                if ( $order_id_filter > 0 ) {
                    $args['include'] = array( $order_id_filter );
                }

                $orders_data    = wc_get_orders( $args );
                $filtered_orders = isset( $orders_data->orders ) ? $orders_data->orders : array();
                $total_items     = isset( $orders_data->total ) ? (int) $orders_data->total : count( $filtered_orders );
                $total_pages     = isset( $orders_data->max_num_pages ) ? (int) $orders_data->max_num_pages : 1;
            } else {
                $legacy_args = array(
                    'post_type'      => 'shop_order',
                    'post_status'    => function_exists( 'wc_get_order_statuses' ) ? array_keys( wc_get_order_statuses() ) : 'any',
                    'posts_per_page' => $per_page,
                    'paged'          => $current_page,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'fields'         => 'ids',
                    'meta_query'     => $meta_query,
                );

                if ( $order_id_filter > 0 ) {
                    $legacy_args['post__in'] = array( $order_id_filter );
                }

                $legacy_query = new WP_Query( $legacy_args );
                foreach ( $legacy_query->posts as $legacy_order_id ) {
                    $legacy_order = wc_get_order( $legacy_order_id );
                    if ( $legacy_order ) {
                        $filtered_orders[] = $legacy_order;
                    }
                }

                $total_items = (int) $legacy_query->found_posts;
                $total_pages = max( 1, (int) $legacy_query->max_num_pages );
            }

            // محافظ نهایی: حتی اگر یک نسخه خاص ووکامرس query را نادیده گرفت،
            // سفارش بدون وضعیت سورناپست نباید وارد جدول شود.
            $filtered_orders = array_values(
                array_filter(
                    $filtered_orders,
                    static function ( $order ) use ( $status_filter ) {
                        if ( ! $order instanceof WC_Abstract_Order ) {
                            return false;
                        }

                        $order_surenapost_status = (string) $order->get_meta( '_surenapost_status', true );
                        if ( ! in_array( $order_surenapost_status, array( '1', '2', '3', '4' ), true ) ) {
                            return false;
                        }

                        return ! in_array( $status_filter, array( '1', '2', '3', '4' ), true )
                            || $order_surenapost_status === $status_filter;
                    }
                )
            );
            ?>
            <div class="surenapost-tab-content">
                <h2><?php echo esc_html__( 'لیست رهگیری', 'surenapost' ); ?></h2>

                <form method="get" action="" class="inline-form" style="margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-start;">
                    <input type="hidden" name="page" value="surenapost-tracking">

                    <!-- تاریخ شمسی -->
                    <div style="flex: 1 1 200px; min-width: 180px; display: flex; flex-direction: column;">
                        <label for="time1w"><?php echo esc_html__( 'تاریخ (جلالی)', 'surenapost' ); ?></label>
                        <input type="text"
                               name="time1w"
                               id="time1w"
                               value="<?php echo esc_attr( $search_date ); ?>"
                               class="regular-text jdatepicker"
                               placeholder="<?php echo esc_attr__( 'مثال: 1403-01-01', 'surenapost' ); ?>">
                        <p class="description" style="margin: 3px 0 0; font-size: 11px;"><?php echo esc_html__( 'تاریخ را به‌صورت شمسی (YYYY-MM-DD) وارد کنید. در صورت خالی بودن، همه روزها نمایش داده می‌شود.', 'surenapost' ); ?></p>
                    </div>

                    <!-- کد سفارش -->
                    <div style="flex: 1 1 150px; min-width: 120px; display: flex; flex-direction: column;">
                        <label for="priceid"><?php echo esc_html__( 'کد سفارش', 'surenapost' ); ?></label>
                        <input type="number"
                               name="priceid"
                               id="priceid"
                               value="<?php echo esc_attr( $order_id_filter ); ?>"
                               class="regular-text"
                               placeholder="<?php echo esc_attr__( 'همه', 'surenapost' ); ?>">
                    </div>

                    <!-- وضعیت رهگیری -->
                    <div style="flex: 1 1 180px; min-width: 150px; display: flex; flex-direction: column;">
                        <label for="post_s"><?php echo esc_html__( 'وضعیت رهگیری', 'surenapost' ); ?></label>
                        <select name="post_s" id="post_s" class="regular-text">
                            <option value="9" <?php selected( $status_filter, '9' ); ?>><?php echo esc_html__( 'همه', 'surenapost' ); ?></option>
                            <option value="2" <?php selected( $status_filter, '2' ); ?>><?php echo esc_html__( 'رهگیری جدید دارد', 'surenapost' ); ?></option>
                            <option value="1" <?php selected( $status_filter, '1' ); ?>><?php echo esc_html__( 'در انتظار بارکد', 'surenapost' ); ?></option>
                            <option value="3" <?php selected( $status_filter, '3' ); ?>><?php echo esc_html__( 'در انتظار لغو', 'surenapost' ); ?></option>
                            <option value="4" <?php selected( $status_filter, '4' ); ?>><?php echo esc_html__( 'لغو شده', 'surenapost' ); ?></option>
                        </select>
                    </div>

                    <!-- دکمه جستجو -->
                    <div style="flex: 0 0 auto; display: flex; flex-direction: column; justify-content: flex-end;">
                        <button type="submit" class="button button-primary"><?php echo esc_html__( 'جستجو', 'surenapost' ); ?></button>
                    </div>
                </form>

                <style>
                    /* زیر هم شدن فرم در موبایل */
                    @media screen and (max-width: 600px) {
                        form.inline-form > div {
                            flex: 1 1 100% !important;
                        }
                    }
                </style>

                <script>
                    jQuery(document).ready(function($){
                        if ($.fn.jalaliDatepicker) {
                            $('#time1w').jalaliDatepicker({
                                format: 'YYYY-MM-DD',
                                changeMonth: true,
                                changeYear: true,
                                showButtonPanel: true,
                                autoClose: true
                            });
                        }
                    });
                </script>
                <div class="surenapost-tracking-table">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th><?php echo esc_html__( 'شماره سفارش', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'نام', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'بارکد', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'وضعیت', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'شهر', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'تاریخ', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'ساعت', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'وزن (گرم)', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'تعداد چاپ', 'surenapost' ); ?></th>
                            <th><?php echo esc_html__( 'عملیات', 'surenapost' ); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if ( ! empty( $filtered_orders ) ) : ?>
                            <?php $i = ( ( $current_page - 1 ) * $per_page ) + 1; foreach ( $filtered_orders as $order ) :
                                $tracking_code = $order->get_meta( '_surenapost_tracking', true );
                                $surenapost_status = $order->get_meta( '_surenapost_status', true );
                                $surenapost_times = $order->get_meta( '_surenapost_times', true );
                                $surenapost_weight = $order->get_meta( '_surenapost_weight', true );
                                $print_count = absint( $order->get_meta( '_surenapost_print_count', true ) );
                                $city_name = $order->get_meta( '_surenapost_city_name', true );
                                $customer_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
                                if ( empty( $customer_name ) ) {
                                    $customer_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
                                }

                                // تعیین وضعیت
                                $status_text = '';
                                if ( empty( $surenapost_status ) || $surenapost_status === '0' ) {
                                    $status_text = __( 'رهگیری ندارد', 'surenapost' );
                                } elseif ( $surenapost_status === '1' ) {
                                    $status_text = __( 'در انتظار رهگیری', 'surenapost' );
                                }  elseif ( $surenapost_status === '3' ) {
                                    $status_text = __( 'در انتظار لغو', 'surenapost' );
                                } elseif ( $surenapost_status === '4' ) {
                                    $status_text = __( 'لغو شده', 'surenapost' );
                                } elseif ( $surenapost_status === '2' || ( ! empty( $tracking_code ) && strlen( $tracking_code ) > 3 ) ) {
                                    $status_text = __( 'رهگیری دارد', 'surenapost' );
                                }
                                ?>
                                <tr>
                                    <td><?php echo esc_html( $i ); ?></td>
                                    <td><?php echo esc_html( $order->get_id() ); ?></td>
                                    <td><?php echo esc_html( $customer_name ?: '-' ); ?></td>
                                    <td><?php echo esc_html( $tracking_code ?: '-' ); ?></td>
                                    <td><?php echo esc_html( $status_text ); ?></td>
                                    <td><?php echo esc_html( $city_name ?: '-' ); ?></td>
                                    <td><?php echo $surenapost_times ? esc_html( wp_date( 'Y/n/j', $surenapost_times ) ) : '-'; ?></td>
                                    <td><?php echo $surenapost_times ? esc_html( wp_date( 'H:i', $surenapost_times ) ) : '-'; ?></td>
                                    <td><?php echo esc_html( $surenapost_weight ?: '-' ); ?></td>
                                    <td><strong><?php echo esc_html( $print_count ); ?></strong></td>
                                    <td>
                                        <?php if ( ! empty( $tracking_code ) && strlen( $tracking_code ) > 3 ) :

$print_url = wp_nonce_url(
    add_query_arg(
        array(
            'action'   => 'surenapost_print_label',
            'order_id' => absint(  $order->get_id() ),
        ),
        admin_url( 'admin-post.php' )
    ),
    'surenapost_print_label_' . absint( $order->get_id() )
);
?>
                                            <a href="<?php echo esc_url( $print_url ); ?>" target="_blank" class="button button-primary">
                                                چاپ کد رهگیری
                                            </a>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php $i++; endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="11" style="text-align: center; padding: 20px;">
                                    <?php echo esc_html__( 'هیچ سفارشی یافت نشد.', 'surenapost' ); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>

                    <?php if ( $total_pages > 1 ) :
                        $base_url = admin_url( 'admin.php?page=surenapost&tab=tracking' );
                        $base_url = add_query_arg( array(
                            'time1w'  => $search_date,
                            'priceid' => $order_id_filter,
                            'post_s'  => $status_filter,
                            'per_page'=> $per_page,
                        ), $base_url );
                        ?>
                        <div class="surenapost-pagination">
                            <?php
                            echo paginate_links( array(
                                'base'      => $base_url . '%_%',
                                'format'    => '&paged=%#%',
                                'current'   => $current_page,
                                'total'     => $total_pages,
                                'prev_text' => __( '&laquo; قبلی', 'surenapost' ),
                                'next_text' => __( 'بعدی &raquo;', 'surenapost' ),
                            ) );
                            ?>
                        </div>
                        <p class="surenapost-pagination-info">
                            <?php
                            printf(
                                esc_html__( 'نمایش %d تا %d از %d سفارش', 'surenapost' ),
                                ( ( $current_page - 1 ) * $per_page ) + 1,
                                min( $current_page * $per_page, $total_items ),
                                $total_items
                            );
                            ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ( 'update' === $current_tab ) : ?>
            <?php
            $dependencies_manager = new Surenapost_Dependencies_Manager();
            $update_message      = '';
            $update_error        = '';

            // پردازش درخواست بروزرسانی (POST)
            if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['update_dependencies'] ) && check_admin_referer( 'surenapost_update_dependencies', 'surenapost_update_nonce' ) ) {
                if ( empty( $api_key ) ) {
                    $update_error = __( 'لطفا ابتدا در تب «تنظیمات API» توکن سورنا پست را ذخیره کنید.', 'surenapost' );
                } else {
                    $clear_existing = true; // API جدید همیشه جایگزینی کامل انجام می‌دهد.
                    $result         = $dependencies_manager->update_all_dependencies( $api_key, $clear_existing );

                    if ( ! empty( $result['errors'] ) && empty( $result['details'] ) ) {
                        $update_error = implode( '<br>', $result['errors'] );
                    } else {
                        $total_inserted = $result['total_inserted'];
                        $total_skipped  = $result['total_skipped'];

                        if ( $total_inserted > 0 || $total_skipped > 0 ) {
                            $update_message = '<div class="notice notice-success is-dismissible">';
                            $update_message .= '<p><strong>' . esc_html__( 'موفق:', 'surenapost' ) . '</strong> ' . esc_html__( 'بروزرسانی با موفقیت انجام شد.', 'surenapost' ) . '</p>';
                            $update_message .= '<ul style="margin: 10px 0; padding-right: 20px;">';
                            $update_message .= '<li>' . esc_html__( 'تعداد رکوردهای جدید:', 'surenapost' ) . ' <strong>' . $total_inserted . '</strong></li>';
                            $update_message .= '<li>' . esc_html__( 'تعداد رکوردهای نادیده گرفته شده:', 'surenapost' ) . ' <strong>' . $total_skipped . '</strong></li>';
                            $update_message .= '</ul>';

                            if ( ! empty( $result['details'] ) ) {
                                $update_message .= '<h4 style="margin-top: 15px;">' . esc_html__( 'جزئیات:', 'surenapost' ) . '</h4>';
                                $update_message .= '<ul style="margin: 10px 0; padding-right: 20px;">';
                                foreach ( $result['details'] as $type => $detail ) {
                                    $update_message .= '<li><strong>' . esc_html( $detail['label'] ) . ':</strong> ';
                                    $update_message .= esc_html__( 'جدید:', 'surenapost' ) . ' ' . $detail['inserted'] . ', ';
                                    $update_message .= esc_html__( 'موجود:', 'surenapost' ) . ' ' . $detail['skipped'] . ', ';
                                    $update_message .= esc_html__( 'جمع:', 'surenapost' ) . ' ' . $detail['total'];
                                    $update_message .= '</li>';
                                }
                                $update_message .= '</ul>';
                            }

                            if ( ! empty( $result['errors'] ) ) {
                                $update_message .= '<p style="color: #d63638; margin-top: 10px;"><strong>' . esc_html__( 'هشدار:', 'surenapost' ) . '</strong> ' . implode( '<br>', array_map( 'esc_html', $result['errors'] ) ) . '</p>';
                            }

                            $update_message .= '</div>';
                        } elseif ( empty( $update_error ) ) {
                            $update_message = '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'هیچ داده جدیدی برای بروزرسانی یافت نشد.', 'surenapost' ) . '</p></div>';
                        }
                    }
                }
            }
            ?>
            <div class="surenapost-tab-content">
                <div class="card" style="max-width: 900px; padding: 16px;">

                <h2>1 - <?php echo esc_html__( 'بروزرسانی وابستگی‌های سورنا پست', 'surenapost' ); ?></h2>

                <?php if ( ! empty( $update_message ) ) : ?>
                    <?php echo wp_kses_post( $update_message ); ?>
                <?php endif; ?>

                <?php if ( ! empty( $update_error ) ) : ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php echo wp_kses_post( $update_error ); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ( ! $api_manager->has_api_key() ) : ?>
                    <div class="notice notice-warning">
                        <p><?php echo esc_html__( 'لطفا ابتدا در تب «تنظیمات API» توکن سورنا پست را ذخیره کنید.', 'surenapost' ); ?></p>
                    </div>
                <?php else : ?>
                    <div style="margin-top: 25px;">
                        <p><?php echo esc_html__( 'با کلیک بر روی دکمه زیر، همه وابستگی‌ها از مسیر جدید dependency/extra دریافت و به‌صورت کامل جایگزین می‌شوند:', 'surenapost' ); ?></p>
                        <ul style="margin: 15px 0; padding-right: 20px;">
                            <li><?php echo esc_html__( 'postType (خدمات پست)', 'surenapost' ); ?></li>
                            <li><?php echo esc_html__( 'packetType (انواع بسته)', 'surenapost' ); ?></li>
                            <li><?php echo esc_html__( 'boxSize (اندازه‌های جعبه)', 'surenapost' ); ?></li>
                            <li><?php echo esc_html__( 'payType (انواع پرداخت)', 'surenapost' ); ?></li>
                        </ul>

                        <form method="post" action="">
                            <?php wp_nonce_field( 'surenapost_update_dependencies', 'surenapost_update_nonce' ); ?>
                            <input type="hidden" name="update_dependencies" value="1">
                            <p class="submit">
                                <button type="submit" class="button button-primary"><?php echo esc_html__( 'بروزرسانی', 'surenapost' ); ?></button>
                            </p>
                        </form>
                    </div>
                    </div>

                    <?php
                    $locations_db   = new Surenapost_Locations_DB();
                    $last_refresh   = $locations_db->get_last_refresh_time();
                    $province_count = $locations_db->count_provinces();
                    $city_count     = $locations_db->count_cities();

                    if ( isset( $_GET['surenapost_locations_updated'] ) ) {
                        $is_success = '1' === (string) $_GET['surenapost_locations_updated'];
                        $message    = isset( $_GET['surenapost_locations_message'] )
                            ? sanitize_text_field( wp_unslash( $_GET['surenapost_locations_message'] ) )
                            : '';

                        echo '<div class="notice ' . ( $is_success ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>';
                        echo esc_html( $message );
                        echo '</p></div>';
                    }
                    ?>

                    <div class="card" style="max-width: 900px; padding: 16px;">
                        <h2>2- <?php esc_html_e( 'بروزرسانی شهر و استان', 'surenapost' ); ?></h2>

                        <p style="margin-bottom: 12px;">
                            <?php esc_html_e( 'با زدن این دکمه، اگر جدول‌های شهر و استان ساخته نشده باشند ایجاد می‌شوند و سپس اطلاعات از API دریافت و در دیتابیس وردپرس ذخیره می‌شوند.', 'surenapost' ); ?>
                        </p>

                        <p style="margin-bottom: 12px; line-height: 1.8;">
                            <strong><?php esc_html_e( 'تعداد استان‌ها:', 'surenapost' ); ?></strong>
                            <?php echo esc_html( $province_count ); ?>
                            <br>
                            <strong><?php esc_html_e( 'تعداد شهرها:', 'surenapost' ); ?></strong>
                            <?php echo esc_html( $city_count ); ?>
                            <br>
                            <strong><?php esc_html_e( 'آخرین بروزرسانی:', 'surenapost' ); ?></strong>
                            <?php echo $last_refresh ? esc_html( $last_refresh ) : esc_html__( 'هنوز انجام نشده', 'surenapost' ); ?>
                        </p>

                        <form method="post" action="">
                            <?php wp_nonce_field( 'surenapost_refresh_locations_action', 'surenapost_refresh_locations_nonce' ); ?>
                            <input type="hidden" name="surenapost_refresh_locations_submit" value="1">

                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'بروزرسانی شهر و استان', 'surenapost' ); ?>
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>


         <?php endif; ?>

    </div>
</div>

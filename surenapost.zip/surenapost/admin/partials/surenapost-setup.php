<?php
/**
 * صفحه راه‌اندازی اولیه سورناپست.
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$setup_status = $this->get_setup_status();
$setup_notice = $this->get_setup_notice();
$ip_info      = $this->get_server_ip_info();
$progress     = $setup_status['total'] > 0 ? (int) round( ( $setup_status['completed'] / $setup_status['total'] ) * 100 ) : 0;
$sender       = $setup_status['sender'];

$step_class = static function ( $is_complete ) {
    return $is_complete ? 'is-complete' : 'is-pending';
};

$step_badge = static function ( $is_complete ) {
    return $is_complete ? __( 'تکمیل شده', 'surenapost' ) : __( 'نیازمند اقدام', 'surenapost' );
};
?>

<div class="surenapost-setup-page">
    <div class="surenapost-setup-hero">
        <div>
            <h2><?php esc_html_e( 'راه‌اندازی اولیه سورناپست', 'surenapost' ); ?></h2>
            <p><?php esc_html_e( 'این چهار مرحله را به‌ترتیب انجام دهید تا فروشگاه برای ثبت و ارسال مرسوله آماده شود.', 'surenapost' ); ?></p>
        </div>

        <div class="surenapost-setup-progress-box">
            <strong>
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: 1: completed steps, 2: all steps. */
                        __( '%1$d از %2$d مرحله', 'surenapost' ),
                        (int) $setup_status['completed'],
                        (int) $setup_status['total']
                    )
                );
                ?>
            </strong>
            <div class="surenapost-setup-progress">
                <span style="width: <?php echo esc_attr( $progress ); ?>%;"></span>
            </div>
        </div>
    </div>

    <?php if ( is_array( $setup_notice ) && ! empty( $setup_notice['messages'] ) ) : ?>
        <div class="notice notice-<?php echo esc_attr( $setup_notice['type'] ); ?> inline surenapost-setup-notice">
            <?php foreach ( $setup_notice['messages'] as $message ) : ?>
                <p><?php echo esc_html( $message ); ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ( $setup_status['token_exists'] ) : ?>
        <div class="surenapost-sync-all-bar">
            <div>
                <strong><?php esc_html_e( 'همگام‌سازی سریع اطلاعات پایه', 'surenapost' ); ?></strong>
                <p><?php esc_html_e( 'با یک کلیک، وابستگی‌ها و سپس لیست شهرها و استان‌ها دریافت می‌شوند.', 'surenapost' ); ?></p>
            </div>

            <form method="post" action="" class="surenapost-setup-action-form">
                <?php wp_nonce_field( 'surenapost_setup_action', 'surenapost_setup_nonce' ); ?>
                <input type="hidden" name="surenapost_setup_action" value="sync_all">
                <button type="submit" class="button button-primary">
                    <?php esc_html_e( 'همگام‌سازی اطلاعات پایه', 'surenapost' ); ?>
                </button>
            </form>
        </div>
    <?php endif; ?>

    <div class="surenapost-setup-grid">
        <section class="surenapost-setup-card <?php echo esc_attr( $step_class( $setup_status['steps']['ip']['complete'] ) ); ?>">
            <div class="surenapost-setup-card-head">
                <span class="surenapost-setup-number">۱</span>
                <div>
                    <h3><?php esc_html_e( 'دریافت و ارسال آی‌پی سایت', 'surenapost' ); ?></h3>
                    <span class="surenapost-setup-badge"><?php echo esc_html( $step_badge( $setup_status['steps']['ip']['complete'] ) ); ?></span>
                </div>
            </div>

            <p><?php esc_html_e( 'این آی‌پی خروجی سرور فروشگاه است. آن را کپی کنید و برای شرکت سورناپست بفرستید تا ثبت شود. پس از ثبت آی‌پی، توکن را از سورناپست دریافت کنید.', 'surenapost' ); ?></p>

            <?php if ( ! empty( $ip_info['success'] ) ) : ?>
                <div class="surenapost-ip-box">
                    <code id="surenapost-server-ip"><?php echo esc_html( $ip_info['ip'] ); ?></code>
                    <button type="button" class="button button-secondary surenapost-copy-ip" data-copy-target="#surenapost-server-ip">
                        <?php esc_html_e( 'کپی آی‌پی', 'surenapost' ); ?>
                    </button>
                    <span class="surenapost-copy-message" aria-live="polite"></span>
                </div>
            <?php else : ?>
                <div class="notice notice-error inline">
                    <p><?php echo esc_html( $ip_info['message'] ); ?></p>
                </div>
            <?php endif; ?>

            <?php if ( ! empty( $setup_status['confirmed_ip'] ) ) : ?>
                <p class="surenapost-setup-meta">
                    <?php
                    echo esc_html(
                        sprintf(
                            /* translators: %s: confirmed IP. */
                            __( 'آی‌پی تأییدشده قبلی: %s', 'surenapost' ),
                            $setup_status['confirmed_ip']
                        )
                    );
                    ?>
                </p>
            <?php endif; ?>

            <div class="surenapost-setup-actions">
                <?php if ( ! empty( $ip_info['success'] ) ) : ?>
                    <form method="post" action="" class="surenapost-setup-action-form">
                        <?php wp_nonce_field( 'surenapost_setup_action', 'surenapost_setup_nonce' ); ?>
                        <input type="hidden" name="surenapost_setup_action" value="confirm_ip">
                        <button type="submit" class="button button-primary">
                            <?php esc_html_e( 'آی‌پی را برای سورناپست ارسال کردم', 'surenapost' ); ?>
                        </button>
                    </form>
                <?php endif; ?>

                <form method="post" action="" class="surenapost-setup-action-form">
                    <?php wp_nonce_field( 'surenapost_setup_action', 'surenapost_setup_nonce' ); ?>
                    <input type="hidden" name="surenapost_setup_action" value="refresh_ip">
                    <button type="submit" class="button button-secondary">
                        <?php esc_html_e( 'دریافت مجدد آی‌پی', 'surenapost' ); ?>
                    </button>
                </form>
            </div>
        </section>

        <section class="surenapost-setup-card <?php echo esc_attr( $step_class( $setup_status['steps']['sender']['complete'] ) ); ?>">
            <div class="surenapost-setup-card-head">
                <span class="surenapost-setup-number">۲</span>
                <div>
                    <h3><?php esc_html_e( 'ذخیره توکن و اطلاعات فرستنده', 'surenapost' ); ?></h3>
                    <span class="surenapost-setup-badge"><?php echo esc_html( $step_badge( $setup_status['steps']['sender']['complete'] ) ); ?></span>
                </div>
            </div>

            <p><?php esc_html_e( 'بعد از دریافت توکن، اطلاعات فروشگاه را وارد کنید. همین اطلاعات در بخش تنظیمات API نیز قابل ویرایش باقی می‌مانند.', 'surenapost' ); ?></p>

            <form method="post" action="" class="surenapost-api-form surenapost-setup-sender-form">
                <?php wp_nonce_field( 'surenapost_save_api_key', 'surenapost_api_nonce' ); ?>
                <input type="hidden" name="surenapost_save_api_key" value="1">
                <input type="hidden" name="surenapost_return_page" value="setup">
                <input type="hidden" name="surenapost_environment" value="production">

                <div class="surenapost-setup-fields">
                    <label>
                        <span><?php esc_html_e( 'توکن سورناپست', 'surenapost' ); ?></span>
                        <input type="text" id="surenapost_api_key" name="surenapost_api_key" value="<?php echo esc_attr( ( new Surenapost_Api_Manager() )->get_api_key() ); ?>" required>
                    </label>
                    <label>
                        <span><?php esc_html_e( 'نام فرستنده', 'surenapost' ); ?></span>
                        <input type="text" name="surenapost_sender_name" value="<?php echo esc_attr( $sender['name'] ); ?>" required>
                    </label>
                    <label>
                        <span><?php esc_html_e( 'استان فرستنده', 'surenapost' ); ?></span>
                        <input type="text" name="surenapost_sender_state" value="<?php echo esc_attr( $sender['state'] ); ?>" required>
                    </label>
                    <label>
                        <span><?php esc_html_e( 'شهر فرستنده', 'surenapost' ); ?></span>
                        <input type="text" name="surenapost_sender_city" value="<?php echo esc_attr( $sender['city'] ); ?>" required>
                    </label>
                    <label class="is-wide">
                        <span><?php esc_html_e( 'آدرس کامل فرستنده', 'surenapost' ); ?></span>
                        <textarea name="surenapost_sender_address" rows="3" required><?php echo esc_textarea( $sender['address'] ); ?></textarea>
                    </label>
                    <label>
                        <span><?php esc_html_e( 'کد پستی فرستنده', 'surenapost' ); ?></span>
                        <input type="text" name="surenapost_sender_postcode" value="<?php echo esc_attr( $sender['postcode'] ); ?>" required>
                    </label>
                    <label>
                        <span><?php esc_html_e( 'شماره تماس فرستنده', 'surenapost' ); ?></span>
                        <input type="text" name="surenapost_sender_phone" value="<?php echo esc_attr( $sender['phone'] ); ?>" required>
                    </label>
                </div>

                <button type="submit" class="button button-primary">
                    <?php esc_html_e( 'ذخیره توکن و اطلاعات فرستنده', 'surenapost' ); ?>
                </button>
            </form>
        </section>

        <section class="surenapost-setup-card <?php echo esc_attr( $step_class( $setup_status['steps']['dependencies']['complete'] ) ); ?>">
            <div class="surenapost-setup-card-head">
                <span class="surenapost-setup-number">۳</span>
                <div>
                    <h3><?php esc_html_e( 'دریافت لیست وابستگی‌ها', 'surenapost' ); ?></h3>
                    <span class="surenapost-setup-badge"><?php echo esc_html( $step_badge( $setup_status['steps']['dependencies']['complete'] ) ); ?></span>
                </div>
            </div>

            <p><?php esc_html_e( 'خدمات پستی، انواع بسته و اندازه‌های جعبه از API دریافت و در وردپرس ذخیره می‌شوند.', 'surenapost' ); ?></p>

            <?php if ( ! empty( $setup_status['dependencies_last_sync'] ) ) : ?>
                <p class="surenapost-setup-meta">
                    <?php echo esc_html( sprintf( __( 'آخرین همگام‌سازی: %s', 'surenapost' ), $setup_status['dependencies_last_sync'] ) ); ?>
                </p>
            <?php endif; ?>

            <form method="post" action="" class="surenapost-setup-action-form">
                <?php wp_nonce_field( 'surenapost_setup_action', 'surenapost_setup_nonce' ); ?>
                <input type="hidden" name="surenapost_setup_action" value="sync_dependencies">
                <button type="submit" class="button button-primary" <?php disabled( ! $setup_status['token_exists'] ); ?>>
                    <?php esc_html_e( 'دریافت و ذخیره وابستگی‌ها', 'surenapost' ); ?>
                </button>
            </form>
        </section>

        <section class="surenapost-setup-card <?php echo esc_attr( $step_class( $setup_status['steps']['locations']['complete'] ) ); ?>">
            <div class="surenapost-setup-card-head">
                <span class="surenapost-setup-number">۴</span>
                <div>
                    <h3><?php esc_html_e( 'دریافت لیست شهرها و استان‌ها', 'surenapost' ); ?></h3>
                    <span class="surenapost-setup-badge"><?php echo esc_html( $step_badge( $setup_status['steps']['locations']['complete'] ) ); ?></span>
                </div>
            </div>

            <p><?php esc_html_e( 'لیست استان‌ها و شهرها از API دریافت می‌شود تا در زمان ثبت سفارش قابل انتخاب باشد.', 'surenapost' ); ?></p>

            <p class="surenapost-setup-meta">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: 1: province count, 2: city count. */
                        __( '%1$d استان و %2$d شهر ذخیره شده است.', 'surenapost' ),
                        (int) $setup_status['province_count'],
                        (int) $setup_status['city_count']
                    )
                );
                ?>
                <?php if ( ! empty( $setup_status['locations_last_sync'] ) ) : ?>
                    <br>
                    <?php echo esc_html( sprintf( __( 'آخرین همگام‌سازی: %s', 'surenapost' ), $setup_status['locations_last_sync'] ) ); ?>
                <?php endif; ?>
            </p>

            <form method="post" action="" class="surenapost-setup-action-form">
                <?php wp_nonce_field( 'surenapost_setup_action', 'surenapost_setup_nonce' ); ?>
                <input type="hidden" name="surenapost_setup_action" value="sync_locations">
                <button type="submit" class="button button-primary" <?php disabled( ! $setup_status['token_exists'] ); ?>>
                    <?php esc_html_e( 'دریافت شهرها و استان‌ها', 'surenapost' ); ?>
                </button>
            </form>
        </section>
    </div>

    <?php if ( $setup_status['all_complete'] ) : ?>
        <div class="notice notice-success inline surenapost-setup-finished">
            <p><strong><?php esc_html_e( 'راه‌اندازی تکمیل شد.', 'surenapost' ); ?></strong></p>
            <p><?php esc_html_e( 'فروشگاه به سورناپست متصل است و اطلاعات پایه موردنیاز دریافت شده‌اند.', 'surenapost' ); ?></p>
            <p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=surenapost' ) ); ?>" class="button button-primary">
                    <?php esc_html_e( 'بازگشت به داشبورد', 'surenapost' ); ?>
                </a>
            </p>
        </div>
    <?php endif; ?>
</div>

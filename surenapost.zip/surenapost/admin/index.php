<?php
/**
 * فایل امنیتی
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

// Silence is golden.


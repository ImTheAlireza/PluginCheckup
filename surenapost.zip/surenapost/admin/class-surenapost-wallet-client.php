<?php
/**
 * کلاینت موجودی کیف‌پول سورناپست
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * کلاس کلاینت کیف‌پول
 */
class Surenapost_Wallet_Client {

    /**
     * آدرس API موجودی
     *
     * @var string
     */
    private $endpoint = 'https://post-api.sourena.shop/api/wallet/balance';
     private $increase_endpoint = 'https://post-api.sourena.shop/api/wallet/increase';
    /**
     * زمان تایم‌اوت درخواست
     *
     * @var int
     */
    private $timeout = 30;

    /**
     * دریافت موجودی بر اساس توکن
     *
     * @param string $token
     *
     * @return string|WP_Error
     */
    public function fetch_balance( $token ) {
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $response = wp_remote_get(
            $this->endpoint,
            array(
                'timeout' => $this->timeout,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept'        => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
        }

        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_error', json_last_error_msg() );
        }

        /**
         * نمایش پیام واقعی خطای API
         * نمونه پاسخ:
         * array(
         *     'status' => false,
         *     'error'  => 'آی پی شما ثبت نشده است',
         * )
         */
        if ( isset( $data['status'] ) && false === $data['status'] ) {
            $error_message = isset( $data['error'] )
                ? $data['error']
                : __( 'خطایی از سمت سرویس رخ داده است.', 'surenapost' );

            return new WP_Error(
                'api_error',
                sanitize_text_field( $error_message )
            );
        }

        $output = array();

        if ( isset( $data['output'] ) && is_array( $data['output'] ) ) {
            $output = $data['output'];
        } elseif ( isset( $data['balance'] ) ) {
            // پشتیبانی از ساختار ساده‌تر
            $output['balance'] = $data['balance'];
        }

        if ( empty( $output ) ) {
            return new WP_Error( 'no_balance', __( 'فیلد موجودی در پاسخ یافت نشد.', 'surenapost' ) );
        }

        return array(
            'balance'            => isset( $output['balance'] ) ? $output['balance'] : null,
            'credit_limit'       => isset( $output['credit_limit'] ) ? $output['credit_limit'] : null,
            'available_balance'  => isset( $output['available_balance'] ) ? $output['available_balance'] : null,
        );
    }

    /**
     * افزایش موجودی از طریق درگاه سپ
     *
     * @param string $token
     * @param int    $amount  مبلغ به تومان
     *
     * @return array|WP_Error
     */
    public function increase_wallet( $token, $amount ) {

        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
        }

        $amount = intval( $amount );
        if ( $amount <= 0 ) {
            return new WP_Error( 'invalid_amount', __( 'مبلغ نامعتبر است.', 'surenapost' ) );
        }

        $response = wp_remote_post(
            $this->increase_endpoint,
            [
                'timeout' => $this->timeout,
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                ],
                'body' => wp_json_encode([
                    'amount' => $amount,
                    'gateway' => 'saderat'
                ]),
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'http_error', sprintf( 'HTTP %s: %s', $code, $body ) );
        }

        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_error', json_last_error_msg() );
        }

        if ( empty( $data['output']['url'] ) ) {

            return new WP_Error( 'no_payment_url', __( 'لینک درگاه پرداخت دریافت نشد.', 'surenapost' ) );
        }

        return [
            'url' => esc_url_raw( $data['output']['url'] ),
        ];
    }

}



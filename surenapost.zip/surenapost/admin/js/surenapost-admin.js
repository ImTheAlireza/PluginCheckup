/**
 * اسکریپت‌های ادمین پلاگین سورنا پست
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

 (function($) {
	'use strict';

	$(document).ready(function() {

		// اعتبارسنجی فرم API Key
		$('.surenapost-api-form').on('submit', function(e) {
			var apiKey = $('#surenapost_api_key').val().trim();

			if (!apiKey) {
				e.preventDefault();
				alert('لطفاً API Key را وارد کنید.');
				$('#surenapost_api_key').focus();
				return false;
			}

			// نمایش پیام در حال ذخیره
			var submitButton = $(this).find('input[type="submit"]');
			submitButton.prop('disabled', true).val('در حال ذخیره...');
		});

		// نمایش/مخفی کردن API Key
		var apiKeyInput = $('#surenapost_api_key');
		if (apiKeyInput.length && apiKeyInput.val()) {
			// می‌توانید یک دکمه برای نمایش/مخفی کردن اضافه کنید
		}

		// انیمیشن کارت‌های وضعیت
		$('.surenapost-status-card').each(function(index) {
			$(this).css({
				'animation-delay': (index * 0.1) + 's'
			});
		});

		// پاک کردن کش استان‌ها و شهرها
		$(document).on('click', '#surenapost-clear-locations-cache', function(e){
			e.preventDefault();

			var $btn  = $(this);
			var $msg  = $('#surenapost-clear-locations-cache-message');
			var originalText = $btn.text();

			$btn.prop('disabled', true).text('در حال پاک‌سازی...');
			$msg.text('');

			$.post(
				wallet_ajax.ajax_url,
				{
					action: 'surenapost_clear_locations_cache',
					nonce: wallet_ajax.nonce
				},
				function(response){
					$btn.prop('disabled', false).text(originalText);

					if (response && response.success) {
						$msg.css('color', '#198754').text('کش با موفقیت پاک شد.');
					} else {
						var errorMsg = (response && response.data) || 'خطا در پاک کردن کش.';
						$msg.css('color', '#d63638').text(errorMsg);
						alert('خطا در پاک کردن کش استان‌ها و شهرها:\n\n' + errorMsg);
					}
				},
				'json'
			).fail(function(xhr, status, error){
				$btn.prop('disabled', false).text(originalText);
				$msg.css('color', '#d63638').text('خطا در ارتباط با سرور.');
				alert('خطا در ارتباط با سرور هنگام پاک کردن کش:\n\n' + error);
			});
		});

	});


	jQuery(document).ready(function($){

		$('#openWalletModal').on('click', function(e){
			e.preventDefault();
			$('#walletModal').fadeIn();
		});

		$('#walletClose').on('click', function(){
			$('#walletModal').fadeOut();
		});

		$('#walletSubmit').on('click', function(){

			let amount = $('#wallet_amount').val();
			if (!amount || amount <= 0) { alert('مبلغ معتبر وارد کنید'); return; }
			// console.log(wallet_ajax);
			$.post(wallet_ajax.ajax_url, {
				action: 'increase_wallet',
				amount: amount,
				nonce: wallet_ajax.nonce
			}, function(response){
				if (response.success) {
					console.log(response);
					window.location.href = response.data.url;
					//alert(response.data);

				} else {
					alert(response.data);
				}
			});

		});
	});

})(jQuery);



(function($) {
	'use strict';

	function copyText(text, callback) {
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(text).then(function() {
				callback(true);
			}).catch(function() {
				callback(false);
			});
			return;
		}

		var $temp = $('<textarea>');
		$('body').append($temp);
		$temp.val(text).select();
		var copied = document.execCommand('copy');
		$temp.remove();
		callback(copied);
	}

	$(document).on('click', '.surenapost-copy-ip', function() {
		var $button = $(this);
		var target = $button.data('copy-target');
		var text = $(target).text().trim();
		var $message = $button.siblings('.surenapost-copy-message');

		copyText(text, function(copied) {
			$message.text(copied ? 'آی‌پی کپی شد.' : 'کپی خودکار انجام نشد؛ آی‌پی را دستی کپی کنید.');
		});
	});

	$(document).on('submit', '.surenapost-setup-action-form', function() {
		var $button = $(this).find('button[type="submit"]');
		$button.prop('disabled', true).text('در حال انجام...');
	});
})(jQuery);

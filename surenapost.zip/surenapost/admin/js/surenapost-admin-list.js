/**
 * رابط مدرن سفارش‌های سورناپست در مدیریت ووکامرس.
 *
 * ستون لیست سفارش‌ها و متاباکس صفحه جزئیات از یک HTML مشترک استفاده می‌کنند.
 * همه عملیات با AJAX انجام می‌شوند و فقط همان کارت سفارش بروزرسانی می‌شود.
 *
 * @package Surenapost
 */
(function($) {
	'use strict';

	var provincesCache = null;
	var citiesCache = {};
	var dependenciesCache = null;
	var polling = false;

	function ajaxConfig() {
		return window.wallet_ajax || {};
	}

	function escapeHtml(value) {
		return $('<div>').text(value == null ? '' : String(value)).html();
	}

	function responseMessage(response, fallback) {
		var data = response && response.data;

		if (typeof data === 'string' && data) {
			return data;
		}

		if (data && typeof data.message === 'string' && data.message) {
			return data.message;
		}

		return fallback || 'خطایی رخ داده است.';
	}

	function readableAjaxError(xhr, textStatus, errorThrown) {
		var message = 'ارتباط با سرور برقرار نشد.';
		var responseText = xhr && typeof xhr.responseText === 'string' ? xhr.responseText.trim() : '';
		var parsed;

		if (xhr && xhr.responseJSON) {
			return responseMessage(xhr.responseJSON, message);
		}

		if (responseText === '-1') {
			return 'نشست مدیریت منقضی شده است. صفحه را یک‌بار تازه‌سازی کنید و دوباره تلاش کنید.';
		}

		if (responseText) {
			try {
				parsed = JSON.parse(responseText);
				message = responseMessage(parsed, message);
				if (message !== 'ارتباط با سرور برقرار نشد.') {
					return message;
				}
			} catch (ignore) {
				// پاسخ HTML یا متن خام سرور را پایین‌تر به پیام قابل فهم تبدیل می‌کنیم.
			}
		}

		if (textStatus === 'timeout') {
			return 'پاسخ سرور بیش از حد طول کشید. اتصال سرور سایت به API سورناپست را بررسی کنید.';
		}

		if (xhr && xhr.status === 403) {
			return 'درخواست مجاز نیست یا نشست مدیریت منقضی شده است. صفحه را تازه‌سازی کنید و دوباره تلاش کنید.';
		}

		if (xhr && xhr.status >= 500) {
			return 'سرور سایت هنگام بروزرسانی سورناپست خطای داخلی داد (HTTP ' + xhr.status + '). گزارش خطای وردپرس یا لاگ PHP را بررسی کنید.';
		}

		if (textStatus === 'parsererror') {
			return 'پاسخ نامعتبر از سرور سایت دریافت شد. احتمالاً یک خطای PHP یا خروجی HTML قبل از پاسخ AJAX ایجاد شده است.';
		}

		if (xhr && xhr.status) {
			message += ' (HTTP ' + xhr.status + ')';
		} else if (errorThrown) {
			message += ' (' + errorThrown + ')';
		}

		return message;
	}

	function api(action, data, method) {
		var deferred = $.Deferred();
		var config = ajaxConfig();
		var payload = $.extend({}, data || {}, {
			action: action,
			nonce: config.nonce || ''
		});

		if (!config.ajax_url) {
			deferred.reject('آدرس AJAX وردپرس در صفحه بارگذاری نشده است. صفحه را با Ctrl + F5 تازه‌سازی کنید.');
			return deferred.promise();
		}

		$.ajax({
			url: config.ajax_url,
			method: method || 'POST',
			dataType: 'json',
			timeout: 45000,
			data: payload
		}).done(function(response) {
			if (response && response.success) {
				deferred.resolve(response.data || {});
				return;
			}

			deferred.reject(responseMessage(response, 'عملیات انجام نشد.'));
		}).fail(function(xhr, textStatus, errorThrown) {
			deferred.reject(readableAjaxError(xhr, textStatus, errorThrown));
		});

		return deferred.promise();
	}

	function showToast(message, type) {
		var $toast = $('<div class="surenapost-toast" role="status" aria-live="polite"></div>');
		$toast.addClass(type === 'error' ? 'is-error' : 'is-success').text(message || 'انجام شد.');
		$('body').append($toast);

		window.setTimeout(function() {
			$toast.addClass('is-visible');
		}, 20);

		window.setTimeout(function() {
			$toast.removeClass('is-visible');
			window.setTimeout(function() {
				$toast.remove();
			}, 250);
		}, 4200);
	}

	function applyUiPayload(ui) {
		if (!ui) {
			return;
		}

		if (ui.column) {
			var columnOrderId = $(ui.column).first().attr('data-order-id');
			var $column = $('.surenapost-order-ui-column[data-order-id="' + columnOrderId + '"]');
			if ($column.length) {
				$column.replaceWith(ui.column);
			}
		}

		if (ui.detail) {
			var detailOrderId = $(ui.detail).first().attr('data-order-id');
			var $detail = $('.surenapost-order-ui-detail[data-order-id="' + detailOrderId + '"]');
			if ($detail.length) {
				$detail.replaceWith(ui.detail);
			}
		}
	}

	function setButtonLoading($button, loadingText) {
		if (!$button || !$button.length) {
			return function() {};
		}

		var originalText = $button.text();
		$button.prop('disabled', true).addClass('is-loading').text(loadingText);

		return function() {
			$button.prop('disabled', false).removeClass('is-loading').text(originalText);
		};
	}

	function refreshOrderUi(orderId) {
		return api('surenapost_refresh_order_ui', { order_id: orderId }).done(function(data) {
			applyUiPayload(data.ui);
		});
	}

	function collectAutoRefreshOrderIds() {
		var ids = [];
		$('.surenapost-order-ui[data-auto-refresh="1"]').each(function() {
			var id = parseInt($(this).data('order-id'), 10);
			if (id && $.inArray(id, ids) === -1) {
				ids.push(id);
			}
		});
		return ids.slice(0, 50);
	}

	function refreshVisibleOrders() {
		var ids = collectAutoRefreshOrderIds();
		if (!ids.length || polling || document.hidden) {
			return;
		}

		polling = true;
		api('surenapost_refresh_visible_orders', { order_ids: ids }).done(function(data) {
			$.each(data.orders || {}, function(orderId, orderData) {
				applyUiPayload(orderData.ui);
			});
		}).always(function() {
			polling = false;
		});
	}

	function buildOptions(items, placeholder, selectedValue) {
		var html = '<option value="">' + escapeHtml(placeholder) + '</option>';
		$.each(items || [], function(index, item) {
			var selected = String(item.id) === String(selectedValue || '') ? ' selected' : '';
			html += '<option value="' + escapeHtml(item.id) + '"' + selected + '>' + escapeHtml(item.name) + '</option>';
		});
		return html;
	}

	function destroyOrderModal() {
		var $modal = $('#surenapost-order-modal');

		if ($.fn.select2 && $modal.length) {
			$modal.find('.surenapost-select.select2-hidden-accessible').each(function() {
				$(this).select2('destroy');
			});
		}

		$modal.remove();
		$('body').removeClass('surenapost-modal-open');
	}

	function maybeEnhanceSelects($root) {
		if (!$.fn.select2) {
			return;
		}

		$root.find('.surenapost-select').each(function() {
			var $select = $(this);

			if ($select.hasClass('select2-hidden-accessible')) {
				$select.select2('destroy');
			}

			/*
			 * Keep Select2 outside the scrollable modal panel. Select2 calculates
			 * document offsets for its detached dropdown; appending that dropdown
			 * back into the panel can double the offset on classic WP order screens.
			 */
			$select.select2({
				width: '100%',
				dir: 'rtl',
				dropdownParent: $('body')
			});
		});
	}

	function getProvinces() {
		if (provincesCache) {
			return $.Deferred().resolve(provincesCache).promise();
		}

		return api('surenapost_get_provinces', {}, 'GET').then(function(data) {
			provincesCache = data.output || data || [];
			return provincesCache;
		});
	}

	function getCities(provinceId) {
		var key = String(provinceId || '');
		if (!key) {
			return $.Deferred().resolve([]).promise();
		}

		if (citiesCache[key]) {
			return $.Deferred().resolve(citiesCache[key]).promise();
		}

		return api('surenapost_get_cities', { province_id: provinceId }, 'GET').then(function(data) {
			citiesCache[key] = data.output || data || [];
			return citiesCache[key];
		});
	}

	function getDependencies() {
		if (dependenciesCache) {
			return $.Deferred().resolve(dependenciesCache).promise();
		}

		return api('surenapost_get_dependencies', {}, 'GET').then(function(data) {
			dependenciesCache = data || {};
			return dependenciesCache;
		});
	}

	function modalHtml(orderId, triggerData) {
		return '' +
			'<div id="surenapost-order-modal" class="surenapost-modal" role="dialog" aria-modal="true" aria-labelledby="surenapost-order-modal-title">' +
			'<div class="surenapost-modal-backdrop surenapost-close-modal"></div>' +
			'<div class="surenapost-modal-panel">' +
			'<button type="button" class="surenapost-modal-close surenapost-close-modal" aria-label="بستن">×</button>' +
			'<h2 id="surenapost-order-modal-title">صدور مرسوله سورناپست برای سفارش #' + escapeHtml(orderId) + '</h2>' +
			'<p class="surenapost-modal-description">اطلاعات مقصد و مشخصات بسته را بررسی کنید. پس از ثبت، وضعیت همین سفارش بدون رفرش صفحه بروزرسانی می‌شود.</p>' +
			'<div class="surenapost-recipient-summary">' +
			'<strong>گیرنده:</strong> ' + escapeHtml(triggerData.shippingName || '-') + '<br>' +
			'<strong>آدرس:</strong> ' + escapeHtml(triggerData.shippingAddress || '-') +
			'</div>' +
			'<form id="surenapost-order-form">' +
			'<input type="hidden" name="order_id" value="' + escapeHtml(orderId) + '">' +
			'<div class="surenapost-modal-grid">' +
			'<label><span>استان مقصد</span><select class="surenapost-select" id="surenapost-province" name="province_id" required><option>در حال بارگذاری...</option></select></label>' +
			'<label><span>شهر مقصد</span><select class="surenapost-select" id="surenapost-city" name="city_id" required disabled><option value="">ابتدا استان را انتخاب کنید</option></select></label>' +
			'<label><span>نوع ارسال پستی <small>(اختیاری)</small></span><select class="surenapost-select" id="surenapost-post-service" name="post_service_id"><option>در حال بارگذاری...</option></select></label>' +
			'<label><span>نوع بسته</span><select class="surenapost-select" id="surenapost-packet-type" name="packet_type" required><option>در حال بارگذاری...</option></select></label>' +
			'<label><span>سایز بسته</span><select class="surenapost-select" id="surenapost-box-size" name="box_size" required><option>در حال بارگذاری...</option></select></label>' +
			'<label><span>نوع پرداخت</span><select class="surenapost-select" id="surenapost-pay-type" name="pay_type" required><option>در حال بارگذاری...</option></select></label>' +
			'<label><span>وزن کل بسته (گرم)</span><input type="number" name="weight" id="surenapost-weight" min="1" step="1" required></label>' +
			'<label><span>ارزش مرسوله (تومان)</span><input type="number" name="percel_value" id="surenapost-value" min="0" step="1" required></label>' +
			'<label><span>شماره موبایل گیرنده</span><input type="text" name="mobile" value="' + escapeHtml(triggerData.shippingMobile || triggerData.shippingPhone || '') + '" required></label>' +
			'<label><span>کد پستی گیرنده</span><input type="text" name="codeposti_get" value="' + escapeHtml(triggerData.shippingPostcode || '') + '" maxlength="10" inputmode="numeric" required></label>' +
			'</div>' +
			'<label class="surenapost-standard-field"><input type="checkbox" name="standard" value="1" checked> ابعاد بسته استاندارد است.</label>' +
			'<div class="surenapost-modal-actions"><button type="submit" class="button button-primary">ثبت و ارسال به سورناپست</button><button type="button" class="button surenapost-close-modal">انصراف</button></div>' +
			'<p class="surenapost-modal-message" aria-live="polite"></p>' +
			'</form>' +
			'</div>' +
			'</div>';
	}

	function serializeForm($form) {
		var payload = {};
		$.each($form.serializeArray(), function(index, field) {
			payload[field.name] = field.value;
		});
		payload.standard = $form.find('[name="standard"]').is(':checked') ? '1' : '0';
		return payload;
	}

	function openOrderModal($trigger) {
		var data = {
			shippingName: $trigger.data('shipping-name'),
			shippingAddress: $trigger.data('shipping-address'),
			shippingPhone: $trigger.data('shipping-phone'),
			shippingMobile: $trigger.data('shipping-mobile'),
			shippingPostcode: $trigger.data('shipping-postcode'),
			provinceId: $trigger.data('province-id'),
			cityId: $trigger.data('city-id')
		};
		var orderId = parseInt($trigger.data('order-id'), 10);
		var $modal;
		var $form;
		var $message;

		if (!orderId) {
			showToast('شناسه سفارش نامعتبر است.', 'error');
			return;
		}

		api('surenapost_check_locations', {}, 'GET').done(function(check) {
			if (check.is_empty) {
				var missingParts = [];

				if (check.locations_complete === false) {
					missingParts.push('استان‌ها و شهرها');
				}

				if (check.dependencies_complete === false) {
					missingParts.push('وابستگی‌ها');
				}

				var missingText = missingParts.length ? missingParts.join(' و ') : 'اطلاعات پایه';
				showToast(missingText + ' هنوز همگام‌سازی نشده است.', 'error');
				if (check.update_url && window.confirm(missingText + ' ناقص است. به صفحه بروزرسانی برویم؟')) {
					window.location.href = check.update_url;
				}
				return;
			}

			destroyOrderModal();
			$('body').append(modalHtml(orderId, data)).addClass('surenapost-modal-open');
			$modal = $('#surenapost-order-modal');
			$form = $('#surenapost-order-form');
			$message = $form.find('.surenapost-modal-message');
			$modal.addClass('is-visible');

			$.when(getProvinces(), getDependencies(), api('surenapost_get_order_info', { order_id: orderId }, 'GET'))
				.done(function(provinces, dependencies, orderInfo) {
					var provinceId = data.provinceId || '';
					$('#surenapost-province').html(buildOptions(provinces, 'استان را انتخاب کنید', provinceId));
					$('#surenapost-post-service').html(buildOptions(dependencies.post_services, 'بدون انتخاب نوع ارسال (اختیاری)'));
					$('#surenapost-packet-type').html(buildOptions(dependencies.packet_types, 'نوع بسته را انتخاب کنید'));
					$('#surenapost-box-size').html(buildOptions(dependencies.box_sizes, 'سایز بسته را انتخاب کنید'));
					var selectedPayType = (orderInfo.pay_type !== '' && orderInfo.pay_type !== null && typeof orderInfo.pay_type !== 'undefined')
						? orderInfo.pay_type
						: '1';
					$('#surenapost-pay-type').html(buildOptions(dependencies.pay_types, 'نوع پرداخت را انتخاب کنید', selectedPayType));
					$('#surenapost-weight').val(orderInfo.weight || '');
					$('#surenapost-value').val(orderInfo.value || 0);

					if (provinceId) {
						getCities(provinceId).done(function(cities) {
							$('#surenapost-city').html(buildOptions(cities, 'شهر را انتخاب کنید', data.cityId)).prop('disabled', false);
							maybeEnhanceSelects($modal);
						});
					}

					maybeEnhanceSelects($modal);
				})
				.fail(function(message) {
					$message.addClass('is-error').text(message);
				});
		}).fail(function(message) {
			showToast(message, 'error');
		});
	}

	$(document).on('click', '.surenapost-send-order', function(event) {
		event.preventDefault();
		openOrderModal($(this));
	});

	$(document).on('change', '#surenapost-province', function() {
		var provinceId = $(this).val();
		var $city = $('#surenapost-city');

		if (!provinceId) {
			$city.prop('disabled', true).html('<option value="">ابتدا استان را انتخاب کنید</option>');
			return;
		}

		$city.prop('disabled', true).html('<option value="">در حال بارگذاری...</option>');

		getCities(provinceId).done(function(cities) {
			$city.html(buildOptions(cities, 'شهر را انتخاب کنید')).prop('disabled', false);
			maybeEnhanceSelects($('#surenapost-order-modal'));
		}).fail(function(message) {
			showToast(message, 'error');
		});
	});

	$(document).on('submit', '#surenapost-order-form', function(event) {
		event.preventDefault();
		var $form = $(this);
		var payload = serializeForm($form);
		var $button = $form.find('button[type="submit"]');
		var restore = setButtonLoading($button, 'در حال ارسال...');
		var $message = $form.find('.surenapost-modal-message').removeClass('is-error is-success').text('');
		payload.province_name = $('#surenapost-province option:selected').text();
		payload.city_name = $('#surenapost-city option:selected').text();

		api('surenapost_save_order_destination', payload)
			.then(function() {
				return api('surenapost_send_order', payload);
			})
			.done(function(data) {
				applyUiPayload(data.ui);
				destroyOrderModal();
				showToast(data.message || 'سفارش با موفقیت ارسال شد.', 'success');
			})
			.fail(function(message) {
				$message.addClass('is-error').text(message);
			})
			.always(restore);
	});

	$(document).on('click', '.surenapost_get_tracking_btn', function(event) {
		event.preventDefault();
		var $button = $(this);
		var restore = setButtonLoading($button, 'در حال بررسی...');
		api('surenapost_get_tracking', { order_id: $button.data('order-id') })
			.done(function(data) {
				applyUiPayload(data.ui);
				showToast(data.message || 'وضعیت بروزرسانی شد.', 'success');
			})
			.fail(function(message) {
				refreshOrderUi($button.data('order-id'));
				showToast(message, 'error');
			})
			.always(restore);
	});

	$(document).on('click', '.surenapost-suspend-barcode', function(event) {
		event.preventDefault();
		if (!window.confirm('درخواست لغو این بارکد برای سورناپست ارسال شود؟')) {
			return;
		}

		var $button = $(this);
		var restore = setButtonLoading($button, 'در حال ثبت لغو...');
		api('surenapost_suspend_barcode', { order_id: $button.data('order-id') })
			.done(function(data) {
				applyUiPayload(data.ui);
				showToast(data.message || 'درخواست لغو ثبت شد.', 'success');
			})
			.fail(function(message) {
				showToast(message, 'error');
			})
			.always(restore);
	});

	$(document).on('click', '.surenapost-suspend-barcode-update', function(event) {
		event.preventDefault();
		var $button = $(this);
		var restore = setButtonLoading($button, 'در حال بررسی...');
		api('surenapost_refresh_cancel_status', { order_id: $button.data('order-id') })
			.done(function(data) {
				applyUiPayload(data.ui);
				showToast(data.message || 'وضعیت لغو بروزرسانی شد.', 'success');
			})
			.fail(function(message) {
				showToast(message, 'error');
			})
			.always(restore);
	});

	function copyTextToClipboard(text) {
		var deferred = $.Deferred();

		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(String(text || '')).then(function() {
				deferred.resolve();
			}).catch(function() {
				deferred.reject();
			});
			return deferred.promise();
		}

		var $textarea = $('<textarea readonly></textarea>')
			.val(String(text || ''))
			.css({position: 'fixed', top: '-9999px', left: '-9999px', opacity: 0})
			.appendTo('body');

		try {
			$textarea[0].focus();
			$textarea[0].select();
			if (document.execCommand('copy')) {
				deferred.resolve();
			} else {
				deferred.reject();
			}
		} catch (error) {
			deferred.reject();
		}

		$textarea.remove();
		return deferred.promise();
	}

	$(document).on('click', '.surenapost-copy-text', function(event) {
		event.preventDefault();
		var $button = $(this);
		var text = $button.attr('data-copy-text') || '';

		if (!text) {
			showToast('اطلاعاتی برای کپی وجود ندارد.', 'error');
			return;
		}

		copyTextToClipboard(text).done(function() {
			showToast($button.attr('data-copy-success') || 'کپی شد.', 'success');
		}).fail(function() {
			showToast('کپی خودکار انجام نشد. لطفاً دوباره تلاش کنید.', 'error');
		});
	});

	$(document).on('click', '.surenapost-view-barcode', function(event) {
		event.preventDefault();
		var $button = $(this);
		var html = '' +
			'<div id="surenapost-barcode-modal" class="surenapost-modal is-visible" role="dialog" aria-modal="true">' +
			'<div class="surenapost-modal-backdrop surenapost-close-barcode-modal"></div>' +
			'<div class="surenapost-modal-panel surenapost-barcode-panel">' +
			'<button type="button" class="surenapost-modal-close surenapost-close-barcode-modal" aria-label="بستن">×</button>' +
			'<h2>بارکد مرسوله سفارش #' + escapeHtml($button.data('order-id')) + '</h2>' +
			'<div class="surenapost-barcode-value">' + escapeHtml($button.data('tracking-code')) + '</div>' +
			'<p>مقصد: ' + escapeHtml(($button.data('province-name') || '') + ' ' + ($button.data('city-name') || '')) + '</p>' +
			'<button type="button" class="button surenapost-close-barcode-modal">بستن</button>' +
			'</div>' +
			'</div>';

		$('#surenapost-barcode-modal').remove();
		$('body').append(html);
	});

	$(document).on('click', '.surenapost-close-modal', function(event) {
		event.preventDefault();
		destroyOrderModal();
	});

	$(document).on('click', '.surenapost-close-barcode-modal', function(event) {
		event.preventDefault();
		$('#surenapost-barcode-modal').remove();
	});

	$(document).on('keydown', function(event) {
		if (event.key === 'Escape') {
			destroyOrderModal();
			$('#surenapost-barcode-modal').remove();
		}
	});

	$(function() {
		var interval = parseInt(ajaxConfig().poll_interval, 10) || 60000;
		window.setInterval(refreshVisibleOrders, interval);
	});
})(jQuery);

<?php
/**
 * سرویس مشترک سفارش‌های سورناپست.
 *
 * تمام عملیات وضعیت سفارش، کرون و لغو بارکد از این کلاس عبور می‌کند تا
 * صفحه لیست سفارش‌ها و صفحه جزئیات سفارش منطق تکراری نداشته باشند.
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Surenapost_Order_Service {

	const CRON_HOOK     = 'surenapost_refresh_pending_orders';
	const CRON_SCHEDULE = 'surenapost_every_five_minutes';
	const CRON_LOCK     = 'surenapost_refresh_pending_orders_lock';

	const STATUS_NONE             = '0';
	const STATUS_PENDING_TRACKING = '1';
	const STATUS_TRACKED          = '2';
	const STATUS_PENDING_CANCEL   = '3';
	const STATUS_CANCELLED        = '4';

	/**
	 * شناسه کوتاه وضعیت کلی ووکامرس.
	 *
	 * مقدار ذخیره‌شده در دیتابیس با پیشوند wc- باید حداکثر ۲۰ کاراکتر باشد.
	 */
	const WC_SHIPPED_STATUS      = 'surena-shipped';
	const WC_SHIPPED_POST_STATUS = 'wc-surena-shipped';

	/**
	 * اضافه کردن بازه پنج‌دقیقه‌ای به WP-Cron.
	 *
	 * @param array $schedules بازه‌های موجود.
	 * @return array
	 */
	public static function add_cron_schedule( $schedules ) {
		if ( ! isset( $schedules[ self::CRON_SCHEDULE ] ) ) {
			$schedules[ self::CRON_SCHEDULE ] = array(
				'interval' => 5 * MINUTE_IN_SECONDS,
				'display'  => __( 'هر پنج دقیقه یک‌بار', 'surenapost' ),
			);
		}

		return $schedules;
	}

	/**
	 * زمان‌بندی رویداد در صورت نبودن آن.
	 * این متد علاوه بر فعال‌سازی، هنگام اجرای افزونه هم صدا زده می‌شود تا
	 * فروشگاه‌هایی که نسخه قبلی افزونه را بروزرسانی می‌کنند نیز کرون داشته باشند.
	 */
	public static function ensure_cron_scheduled() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
		}
	}

	/**
	 * حذف تمام زمان‌بندی‌های افزونه.
	 */
	public static function clear_cron_schedule() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * اجرای رویداد کرون.
	 */
	public function cron_refresh_pending_orders() {
		$this->refresh_pending_orders( 100 );
	}

	/**
	 * دریافت وضعیت سفارش‌های در انتظار رهگیری یا لغو و اعمال نتیجه.
	 *
	 * @param int $limit حداکثر سفارش در هر اجرای کرون.
	 * @return array|WP_Error
	 */
	public function refresh_pending_orders( $limit = 100 ) {
		if ( get_transient( self::CRON_LOCK ) ) {
			return new WP_Error( 'surenapost_cron_locked', __( 'یک بروزرسانی دیگر در حال اجرا است.', 'surenapost' ) );
		}

		set_transient( self::CRON_LOCK, 1, 4 * MINUTE_IN_SECONDS );

		try {
			$order_ids = $this->get_pending_order_ids( $limit );

			if ( empty( $order_ids ) ) {
				return array();
			}

			return $this->refresh_orders( $order_ids, 'cron' );
		} finally {
			delete_transient( self::CRON_LOCK );
		}
	}

	/**
	 * دریافت شناسه سفارش‌های در انتظار با API ووکامرس؛ بدون SQL مستقیم.
	 *
	 * @param int $limit حداکثر تعداد سفارش.
	 * @return int[]
	 */
	public function get_pending_order_ids( $limit = 100 ) {
		$limit      = max( 1, absint( $limit ) );
		$meta_query = array(
			array(
				'key'     => '_surenapost_status',
				'value'   => array( self::STATUS_PENDING_TRACKING, self::STATUS_PENDING_CANCEL ),
				'compare' => 'IN',
			),
		);

		if ( $this->is_hpos_enabled() && function_exists( 'wc_get_orders' ) ) {
			$order_ids = wc_get_orders(
				array(
					'limit'      => $limit,
					'return'     => 'ids',
					'orderby'    => 'date',
					'order'      => 'ASC',
					'type'       => 'shop_order',
					'status'     => array_keys( wc_get_order_statuses() ),
					'meta_query' => $meta_query,
				)
			);
		} else {
			$order_ids = get_posts(
				array(
					'post_type'      => 'shop_order',
					'post_status'    => array_keys( wc_get_order_statuses() ),
					'fields'         => 'ids',
					'posts_per_page' => $limit,
					'orderby'        => 'date',
					'order'          => 'ASC',
					'meta_query'     => $meta_query,
				)
			);
		}

		return array_values( array_filter( array_map( 'absint', is_array( $order_ids ) ? $order_ids : array() ) ) );
	}

	/**
	 * آیا ذخیره‌سازی HPOS ووکامرس فعال است؟
	 *
	 * @return bool
	 */
	private function is_hpos_enabled() {
		return class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/**
	 * بروزرسانی یک سفارش.
	 *
	 * @param int|string $order_id شناسه سفارش.
	 * @param string     $context  زمینه اجرا: tracking، cancel، cron یا poll.
	 * @return array|WP_Error
	 */
	public function refresh_order( $order_id, $context = 'tracking' ) {
		$order_id = absint( $order_id );
		$order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'surenapost_order_not_found', __( 'سفارش یافت نشد.', 'surenapost' ) );
		}

		$result = $this->refresh_orders( array( $order_id ), $context );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( isset( $result[ $order_id ] ) ) {
			return $result[ $order_id ];
		}

		return array(
			'order_id'     => $order_id,
			'changed'      => false,
			'status_key'   => 'pending',
			'status_label' => '',
			'barcode'      => '',
			'message'      => __( 'مرسوله هنوز در صف پردازش سورناپست است.', 'surenapost' ),
		);
	}

	/**
	 * بروزرسانی گروهی سفارش‌ها با یک درخواست API.
	 *
	 * @param array  $order_ids شناسه سفارش‌ها.
	 * @param string $context   زمینه اجرا.
	 * @return array|WP_Error خروجی ایندکس‌شده با شناسه سفارش.
	 */
	public function refresh_orders( $order_ids, $context = 'poll' ) {
		$order_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $order_ids ) ) ) );

		if ( empty( $order_ids ) ) {
			return array();
		}

		$results = array();

		try {
			foreach ( array_chunk( $order_ids, 50 ) as $chunk ) {
				$remote = $this->request_statuses_from_api( $chunk );

				if ( is_wp_error( $remote ) ) {
					return $remote;
				}

				foreach ( $chunk as $order_id ) {
					$order = wc_get_order( $order_id );

					if ( ! $order instanceof WC_Order ) {
						continue;
					}

					$item = isset( $remote['items'][ (string) $order_id ] ) ? $remote['items'][ (string) $order_id ] : null;

					if ( ! is_array( $item ) ) {
						$results[ $order_id ] = array(
							'order_id'     => $order_id,
							'changed'      => false,
							'status_key'   => 'pending',
							'status_label' => '',
							'barcode'      => '',
							'message'      => __( 'مرسوله هنوز در صف پردازش سورناپست است.', 'surenapost' ),
						);
						continue;
					}

					$results[ $order_id ] = $this->apply_remote_item_to_order( $order, $item, $context );
				}
			}
		} catch ( \Throwable $throwable ) {
			return $this->create_unexpected_error( $throwable, 'refresh_orders' );
		}

		return $results;
	}

	/**
	 * ارسال درخواست گروهی بررسی وضعیت به API سورناپست.
	 *
	 * @param array $order_ids شناسه سفارش‌ها.
	 * @return array|WP_Error
	 */
	public function request_statuses_from_api( $order_ids ) {
		$token = $this->get_api_key();

		if ( '' === $token ) {
			return new WP_Error( 'surenapost_missing_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$payload = wp_json_encode(
			array(
				'orderIds' => array_values( array_map( 'strval', (array) $order_ids ) ),
			),
			JSON_UNESCAPED_UNICODE
		);

		/*
		 * API سورناپست برای check-status یک GET همراه با بدنه JSON می‌خواهد.
		 * لایه HTTP وردپرس بدنه GET را به query string تبدیل می‌کند و در PHP 8+
		 * برای JSON رشته‌ای به http_build_query() خطا می‌دهد. بنابراین فقط برای
		 * همین endpoint از ارسال‌کننده اختصاصی GET-with-body استفاده می‌کنیم.
		 */
		$response = $this->send_json_get_with_body(
			'https://post-api.sourena.shop/api/order/check-status',
			$payload,
			array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
			30
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$http_code = isset( $response['http_code'] ) ? (int) $response['http_code'] : 0;
		$body      = isset( $response['body'] ) ? (string) $response['body'] : '';

		if ( '' === trim( $body ) ) {
			return new WP_Error( 'surenapost_empty_status_body', __( 'پاسخ خالی از سرویس بررسی وضعیت دریافت شد.', 'surenapost' ) );
		}

		$decoded = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return new WP_Error(
				'surenapost_invalid_status_json',
				sprintf( __( 'پاسخ سرویس بررسی وضعیت قابل خواندن نیست: %s', 'surenapost' ), json_last_error_msg() ),
				array( 'http_code' => $http_code )
			);
		}

		if ( $http_code < 200 || $http_code >= 300 || ( isset( $decoded['status'] ) && false === $decoded['status'] ) ) {
			return new WP_Error(
				'surenapost_status_api_error',
				$this->extract_api_error_message( $decoded, __( 'دریافت وضعیت سفارش‌ها از سورناپست ناموفق بود.', 'surenapost' ) ),
				array(
					'http_code' => $http_code,
					'response'  => $decoded,
				)
			);
		}

		$items = array();

		if ( isset( $decoded['output'] ) && is_array( $decoded['output'] ) ) {
			foreach ( $decoded['output'] as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['orderId'] ) ) {
					continue;
				}

				$items[ (string) $item['orderId'] ] = $item;
			}
		}

		return array(
			'http_code' => $http_code,
			'response'  => $decoded,
			'items'     => $items,
		);
	}

	/**
	 * ارسال GET همراه با بدنه JSON برای endpoint غیرمعمول check-status.
	 *
	 * در حالت عادی درخواست‌های HTTP افزونه با API استاندارد وردپرس ارسال
	 * می‌شوند. این helper فقط برای endpoint بررسی وضعیت استفاده می‌شود، چون
	 * آن endpoint مطابق قرارداد سورناپست GET-with-body می‌خواهد.
	 *
	 * @param string $url     آدرس ثابت endpoint.
	 * @param string $payload بدنه JSON.
	 * @param array  $headers هدرهای درخواست.
	 * @param int    $timeout مهلت پاسخ به ثانیه.
	 * @return array|WP_Error
	 */
	private function send_json_get_with_body( $url, $payload, $headers, $timeout = 30 ) {
		$timeout      = max( 1, absint( $timeout ) );
		$header_lines = array();

		foreach ( (array) $headers as $name => $value ) {
			$header_lines[] = sanitize_key( (string) $name ) . ': ' . trim( (string) $value );
		}

		$header_lines[] = 'User-Agent: WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' );

		if ( function_exists( 'curl_init' ) ) {
			$handle = curl_init();

			if ( false === $handle ) {
				return new WP_Error( 'surenapost_status_curl_init_error', __( 'امکان ایجاد ارتباط با سرویس بررسی وضعیت وجود ندارد.', 'surenapost' ) );
			}

			$options = array(
				CURLOPT_URL            => $url,
				CURLOPT_CUSTOMREQUEST  => 'GET',
				CURLOPT_POSTFIELDS     => (string) $payload,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTPHEADER     => $header_lines,
				CURLOPT_TIMEOUT        => $timeout,
				CURLOPT_CONNECTTIMEOUT => min( 10, $timeout ),
				CURLOPT_FOLLOWLOCATION => false,
				CURLOPT_MAXREDIRS      => 0,
				CURLOPT_SSL_VERIFYPEER => true,
				CURLOPT_SSL_VERIFYHOST => 2,
			);

			$ca_bundle = ABSPATH . WPINC . '/certificates/ca-bundle.crt';
			if ( is_readable( $ca_bundle ) ) {
				$options[ CURLOPT_CAINFO ] = $ca_bundle;
			}

			curl_setopt_array( $handle, $options );
			$body      = curl_exec( $handle );
			$http_code = (int) curl_getinfo( $handle, CURLINFO_HTTP_CODE );
			$error     = curl_error( $handle );
			curl_close( $handle );

			if ( false === $body ) {
				return new WP_Error(
					'surenapost_status_http_error',
					sprintf( __( 'خطا در ارتباط با سرویس بررسی وضعیت: %s', 'surenapost' ), $error )
				);
			}

			return array(
				'http_code' => $http_code,
				'body'      => (string) $body,
			);
		}

		if ( ini_get( 'allow_url_fopen' ) ) {
			$ssl_options = array(
				'verify_peer'      => true,
				'verify_peer_name' => true,
			);

			$ca_bundle = ABSPATH . WPINC . '/certificates/ca-bundle.crt';
			if ( is_readable( $ca_bundle ) ) {
				$ssl_options['cafile'] = $ca_bundle;
			}

			$context = stream_context_create(
				array(
					'http' => array(
						'method'        => 'GET',
						'header'        => implode( "\r\n", $header_lines ),
						'content'       => (string) $payload,
						'timeout'       => $timeout,
						'ignore_errors' => true,
					),
					'ssl'  => $ssl_options,
				)
			);

			$body = @file_get_contents( $url, false, $context ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

			if ( false === $body ) {
				$error = error_get_last();
				return new WP_Error(
					'surenapost_status_stream_error',
					sprintf(
						__( 'خطا در ارتباط با سرویس بررسی وضعیت: %s', 'surenapost' ),
						isset( $error['message'] ) ? $error['message'] : __( 'پاسخی از سرور دریافت نشد.', 'surenapost' )
					)
				);
			}

			$http_code = 0;
			if ( isset( $http_response_header ) && is_array( $http_response_header ) ) {
				foreach ( $http_response_header as $header_line ) {
					if ( preg_match( '/^HTTP\/\S+\s+(\d{3})/', $header_line, $matches ) ) {
						$http_code = (int) $matches[1];
					}
				}
			}

			return array(
				'http_code' => $http_code,
				'body'      => (string) $body,
			);
		}

		return new WP_Error(
			'surenapost_status_transport_missing',
			__( 'برای ارتباط با سرویس بررسی وضعیت، افزونه PHP cURL یا allow_url_fopen باید روی سرور فعال باشد.', 'surenapost' )
		);
	}


	/**
	 * اعمال پاسخ یک سفارش روی متای ووکامرس.
	 *
	 * @param WC_Order $order   سفارش ووکامرس.
	 * @param array    $item    خروجی API.
	 * @param string   $context زمینه اجرا.
	 * @return array
	 */
	public function apply_remote_item_to_order( $order, $item, $context = 'poll' ) {
		$status_label         = $this->get_remote_status_label( $item );
		$status_key           = $this->normalize_remote_status( $status_label );
		$barcode              = $this->extract_barcode( $item );
		$current_status       = (string) $order->get_meta( '_surenapost_status', true );
		$previous_status      = $current_status;
		$previous_label       = (string) $order->get_meta( '_surenapost_remote_status_label', true );
		$previous_barcode     = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );
		$is_cancel_flow       = self::STATUS_PENDING_CANCEL === $current_status || 'cancel' === $context;
		$message              = __( 'وضعیت سفارش بروزرسانی شد.', 'surenapost' );

		$order->update_meta_data( '_surenapost_remote_status_label', $status_label );
		$order->update_meta_data( '_surenapost_remote_status_key', $status_key );

		$this->apply_costs_to_order( $order, $item );

		if ( $is_cancel_flow && 'cancelled' !== $status_key ) {
			$order->update_meta_data( '_surenapost_status', self::STATUS_PENDING_CANCEL );
			$message = __( 'درخواست لغو هنوز در انتظار تایید نهایی سورناپست است.', 'surenapost' );
		} elseif ( 'cancelled' === $status_key ) {
			$order->update_meta_data( '_surenapost_status', self::STATUS_CANCELLED );
			$order->update_meta_data( '_surenapost_tracking', '' );

			// مطابق نسخه PHP خام، هزینه‌های مرسوله لغوشده دیگر معتبر نیستند.
			foreach ( array( '_surenapost_postage', '_surenapost_insurance', '_surenapost_tax', '_surenapost_totalPrice' ) as $meta_key ) {
				$order->delete_meta_data( $meta_key );
			}

			$message = __( 'مرسوله در سورناپست لغو شد.', 'surenapost' );
		} elseif ( strlen( $barcode ) > 3 ) {
			$order->update_meta_data( '_surenapost_tracking', $barcode );
			$order->update_meta_data( '_surenapost_status', self::STATUS_TRACKED );

			if ( ! $order->get_meta( '_surenapost_times', true ) ) {
				$order->update_meta_data( '_surenapost_times', time() );
			}

			$this->mark_order_as_shipped( $order, $barcode );
			$message = __( 'بارکد سورناپست صادر شد و وضعیت سفارش به «ارسال شد» تغییر کرد.', 'surenapost' );
		} elseif ( 'pending' === $status_key || 'registered' === $status_key || 'unknown' === $status_key ) {
			$order->update_meta_data( '_surenapost_status', self::STATUS_PENDING_TRACKING );
			$message = __( 'مرسوله هنوز در صف دریافت بارکد است.', 'surenapost' );
		} elseif ( 'not_found' === $status_key ) {
			$message = __( 'سفارش در پاسخ سورناپست یافت نشد.', 'surenapost' );
		}

		$new_status = (string) $order->get_meta( '_surenapost_status', true );
		$changed    = $previous_status !== $new_status || $previous_label !== $status_label || $previous_barcode !== $barcode;

		if ( $changed && '' !== $status_label && $previous_label !== $status_label ) {
			$order->add_order_note(
				sprintf(
					/* translators: %s: remote Sourenapost status. */
					__( 'وضعیت سورناپست به «%s» تغییر کرد.', 'surenapost' ),
					$status_label
				)
			);
		}

		$order->save();

		return array(
			'order_id'     => $order->get_id(),
			'changed'      => $changed,
			'status_key'   => $status_key,
			'status_label' => $status_label,
			'barcode'      => strlen( $barcode ) > 3 ? $barcode : '',
			'message'      => $message,
		);
	}


	/**
	 * ارسال سفارش به سورناپست و ذخیره وضعیت اولیه مرسوله.
	 *
	 * صفحه لیست سفارش و صفحه جزئیات هر دو از همین سرویس استفاده می‌کنند.
	 *
	 * @param WC_Order $order سفارش ووکامرس.
	 * @param array    $input داده‌های فرم صدور.
	 * @return array|WP_Error
	 */
	public function issue_order( $order, $input ) {
		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'surenapost_order_not_found', __( 'سفارش یافت نشد.', 'surenapost' ) );
		}

		if ( ! $order->is_paid() ) {
			return new WP_Error( 'surenapost_order_not_paid', __( 'برای صدور مرسوله، سفارش باید پرداخت شده باشد.', 'surenapost' ) );
		}

		$current_status   = (string) $order->get_meta( '_surenapost_status', true );
		$existing_barcode = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );

		if ( self::STATUS_PENDING_TRACKING === $current_status ) {
			return new WP_Error( 'surenapost_already_pending', __( 'این مرسوله قبلاً ارسال شده و در انتظار صدور بارکد است.', 'surenapost' ) );
		}

		if ( self::STATUS_TRACKED === $current_status || strlen( $existing_barcode ) > 3 ) {
			return new WP_Error( 'surenapost_already_tracked', __( 'برای این سفارش قبلاً بارکد صادر شده است.', 'surenapost' ) );
		}

		if ( self::STATUS_PENDING_CANCEL === $current_status ) {
			return new WP_Error( 'surenapost_cancel_pending', __( 'این مرسوله در انتظار لغو است.', 'surenapost' ) );
		}

		if ( self::STATUS_CANCELLED === $current_status ) {
			return new WP_Error( 'surenapost_cancelled', __( 'این مرسوله لغو شده و برای همین سفارش قابل صدور مجدد نیست.', 'surenapost' ) );
		}

		$province_id     = isset( $input['province_id'] ) ? absint( $input['province_id'] ) : 0;
		$city_id         = isset( $input['city_id'] ) ? absint( $input['city_id'] ) : 0;
		$post_service_id = isset( $input['post_service_id'] ) ? absint( $input['post_service_id'] ) : 0;
		if ( $post_service_id <= 0 ) {
			$post_service_id = 1;
		}
		$packet_type     = isset( $input['packet_type'] ) ? absint( $input['packet_type'] ) : 0;
		$box_size        = isset( $input['box_size'] ) ? absint( $input['box_size'] ) : 0;
		$pay_type_raw    = isset( $input['pay_type'] ) ? trim( (string) $input['pay_type'] ) : '';
		$pay_type        = '' !== $pay_type_raw && is_numeric( $pay_type_raw ) ? (int) $pay_type_raw : null;
		$standard        = ! empty( $input['standard'] );
		$weight          = isset( $input['weight'] ) ? (float) $input['weight'] : 0;
		$parcel_value    = isset( $input['percel_value'] ) ? (float) $input['percel_value'] : 0;

		if ( $province_id <= 0 || $city_id <= 0 ) {
			return new WP_Error( 'surenapost_destination_required', __( 'استان و شهر مقصد را انتخاب کنید.', 'surenapost' ) );
		}

		// انتخاب نوع ارسال در فرم اختیاری است؛ در صورت خالی بودن، شناسه خدمات پستی ۱ ارسال می‌شود.
		// مقدار صفر برای payType نیز معتبر است.
		if ( $packet_type <= 0 || $box_size <= 0 || null === $pay_type || $pay_type < 0 ) {
			return new WP_Error( 'surenapost_dependencies_required', __( 'نوع بسته، سایز بسته و نوع پرداخت را کامل انتخاب کنید.', 'surenapost' ) );
		}

		if ( $weight <= 0 ) {
			return new WP_Error( 'surenapost_weight_required', __( 'وزن مرسوله را به گرم وارد کنید.', 'surenapost' ) );
		}

		if ( $parcel_value < 0 ) {
			return new WP_Error( 'surenapost_value_invalid', __( 'ارزش مرسوله نامعتبر است.', 'surenapost' ) );
		}

		$mobile = $this->normalize_digits( isset( $input['mobile'] ) ? $input['mobile'] : '' );
		if ( '' === $mobile ) {
			$mobile = $this->get_order_phone( $order );
		}

		if ( strlen( $mobile ) < 10 ) {
			return new WP_Error( 'surenapost_mobile_required', __( 'شماره موبایل گیرنده معتبر نیست. آن را در فرم صدور وارد کنید.', 'surenapost' ) );
		}

		$postcode = $this->normalize_digits( isset( $input['codeposti_get'] ) ? $input['codeposti_get'] : '' );
		if ( '' === $postcode ) {
			$postcode = $this->get_order_postcode( $order );
		}

		if ( 10 !== strlen( $postcode ) ) {
			return new WP_Error( 'surenapost_postcode_required', __( 'کد پستی گیرنده باید دقیقاً ۱۰ رقم باشد.', 'surenapost' ) );
		}

		$full_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
		if ( '' === $full_name ) {
			$full_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		}

		if ( '' === $full_name ) {
			return new WP_Error( 'surenapost_receiver_name_required', __( 'نام گیرنده در سفارش ثبت نشده است.', 'surenapost' ) );
		}

		$name_parts = preg_split( '/\s+/', $full_name, 2 );
		$name       = isset( $name_parts[0] ) ? $name_parts[0] : $full_name;
		$family     = isset( $name_parts[1] ) && '' !== $name_parts[1] ? $name_parts[1] : $name;
		$address    = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() );

		if ( '' === $address ) {
			$address = trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() );
		}

		if ( '' === $address ) {
			return new WP_Error( 'surenapost_address_required', __( 'آدرس گیرنده در سفارش ثبت نشده است.', 'surenapost' ) );
		}

		$products = array();
		foreach ( $order->get_items() as $item ) {
			if ( is_callable( array( $item, 'get_name' ) ) ) {
				$products[] = $item->get_name();
			}
		}

		$token = $this->get_api_key();
		if ( '' === $token ) {
			return new WP_Error( 'surenapost_missing_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$city_surena_id = absint( $order->get_meta( '_surenapost_city_surena_id', true ) );
		if ( $city_surena_id <= 0 ) {
			$city_surena_id = $city_id;
		}

		$order_data = array(
			'orderId'       => (string) $order->get_id(),
			'name'          => $name,
			'family'        => $family,
			'mobile'        => $mobile,
			'postalCode'    => $postcode,
			'address'       => $address,
			'product'       => $products,
			'cityId'        => $city_surena_id,
			'weight'        => (int) round( $weight ),
			'percelValue'   => (int) round( $parcel_value ),
			'extra'         => array(
				'packetType' => $packet_type,
				'standard'   => $standard,
				'boxSize'    => $box_size,
				'payType'    => $pay_type,
			),
		);

		// API فیلد postServiceId را الزامی می‌داند؛ مقدار پیش‌فرض ۱ است.
		$order_data['postServiceId'] = $post_service_id;

		$response = wp_remote_post(
			'https://post-api.sourena.shop/api/order',
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => wp_json_encode( $order_data, JSON_UNESCAPED_UNICODE ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'surenapost_issue_http_error',
				sprintf( __( 'خطا در ارتباط با API سورناپست: %s', 'surenapost' ), $response->get_error_message() )
			);
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$body      = (string) wp_remote_retrieve_body( $response );
		$decoded   = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return new WP_Error( 'surenapost_issue_invalid_json', __( 'پاسخ API صدور مرسوله قابل خواندن نیست.', 'surenapost' ) );
		}

		$api_success = ( isset( $decoded['status'] ) && true === $decoded['status'] ) || ( isset( $decoded['success'] ) && true === $decoded['success'] );
		if ( $http_code < 200 || $http_code >= 300 || ! $api_success ) {
			return new WP_Error(
				'surenapost_issue_api_error',
				$this->extract_api_error_message( $decoded, __( 'ارسال سفارش به سورناپست ناموفق بود.', 'surenapost' ) ),
				array( 'response' => $decoded )
			);
		}

		$order->update_meta_data( '_surenapost_status', self::STATUS_PENDING_TRACKING );
		$order->update_meta_data( '_surenapost_times', time() );
		$order->update_meta_data( '_surenapost_percelValue', $parcel_value );
		$order->update_meta_data( '_surenapost_weight', $weight );
		$order->update_meta_data( '_surenapost_boxSizeId', $box_size );
		$order->update_meta_data( '_surenapost_postServiceId', $post_service_id );
		$order->update_meta_data( '_surenapost_standard', $standard ? '1' : '0' );
		$order->update_meta_data( '_surenapost_packetType', $packet_type );
		$order->update_meta_data( '_surenapost_payType', $pay_type );

		$pay_type_label = $this->resolve_dependency_name( 'payType', $pay_type );
		if ( '' !== $pay_type_label ) {
			$order->update_meta_data( '_surenapost_payType_label', $pay_type_label );
		}
		$order->update_meta_data( '_surenapost_cityId', $city_surena_id );
		$order->update_meta_data( '_surenapost_postcode', $postcode );

		$issue_output = isset( $decoded['output'] ) && is_array( $decoded['output'] ) ? $decoded['output'] : array();
		if ( isset( $issue_output[0] ) && is_array( $issue_output[0] ) ) {
			$issue_output = $issue_output[0];
		}
		$this->apply_costs_to_order( $order, $issue_output );
		$barcode = $this->extract_barcode( $issue_output );

		if ( strlen( $barcode ) > 3 ) {
			$order->update_meta_data( '_surenapost_tracking', $barcode );
			$order->update_meta_data( '_surenapost_status', self::STATUS_TRACKED );
			$this->mark_order_as_shipped( $order, $barcode );
		}

		$order->add_order_note( __( 'سفارش برای صدور مرسوله به سورناپست ارسال شد.', 'surenapost' ) );
		$order->save();

		return array(
			'order_id' => $order->get_id(),
			'barcode'  => strlen( $barcode ) > 3 ? $barcode : '',
			'message'  => strlen( $barcode ) > 3
				? __( 'بارکد صادر شد و وضعیت سفارش به «ارسال شد» تغییر کرد.', 'surenapost' )
				: __( 'سفارش با موفقیت ارسال شد و در انتظار صدور بارکد است.', 'surenapost' ),
			'response' => $decoded,
		);
	}

	/**
	 * ثبت درخواست لغو بارکد.
	 *
	 * @param int $order_id شناسه سفارش.
	 * @return array|WP_Error
	 */
	public function suspend_barcode( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $order_id ) ) : false;

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'surenapost_order_not_found', __( 'سفارش یافت نشد.', 'surenapost' ) );
		}

		$current_status = (string) $order->get_meta( '_surenapost_status', true );
		$tracking_code  = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );

		if ( self::STATUS_PENDING_CANCEL === $current_status ) {
			return new WP_Error( 'surenapost_cancel_already_requested', __( 'درخواست لغو قبلاً ثبت شده است.', 'surenapost' ) );
		}

		if ( self::STATUS_CANCELLED === $current_status ) {
			return new WP_Error( 'surenapost_already_cancelled', __( 'این مرسوله قبلاً لغو شده است.', 'surenapost' ) );
		}

		if ( strlen( $tracking_code ) <= 3 ) {
			return new WP_Error( 'surenapost_barcode_missing', __( 'لغو فقط برای مرسوله دارای بارکد امکان‌پذیر است.', 'surenapost' ) );
		}

		$token = $this->get_api_key();

		if ( '' === $token ) {
			return new WP_Error( 'surenapost_missing_token', __( 'توکن API تنظیم نشده است.', 'surenapost' ) );
		}

		$response = wp_remote_post(
			'https://post-api.sourena.shop/api/order/suspend',
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => wp_json_encode( array( 'order_id' => (string) $order->get_id() ), JSON_UNESCAPED_UNICODE ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'surenapost_suspend_http_error', sprintf( __( 'خطا در ارتباط با API: %s', 'surenapost' ), $response->get_error_message() ) );
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$body      = (string) wp_remote_retrieve_body( $response );
		$decoded   = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return new WP_Error( 'surenapost_suspend_invalid_json', __( 'پاسخ API لغو قابل خواندن نیست.', 'surenapost' ) );
		}

		$api_success = ( isset( $decoded['status'] ) && true === $decoded['status'] ) || ( isset( $decoded['success'] ) && true === $decoded['success'] );

		if ( $http_code < 200 || $http_code >= 300 || ! $api_success ) {
			return new WP_Error(
				'surenapost_suspend_api_error',
				$this->extract_api_error_message( $decoded, __( 'لغو بارکد انجام نشد.', 'surenapost' ) ),
				array( 'response' => $decoded )
			);
		}

		$order->update_meta_data( '_surenapost_status', self::STATUS_PENDING_CANCEL );
		$order->delete_meta_data( '_surenapost_remote_status_label' );
		$order->delete_meta_data( '_surenapost_remote_status_key' );
		$order->add_order_note( __( 'درخواست لغو بارکد در سورناپست ثبت شد.', 'surenapost' ) );
		$order->save();

		return array(
			'order_id' => $order->get_id(),
			'message'  => __( 'درخواست لغو ثبت شد. نتیجه نهایی به‌صورت خودکار بروزرسانی می‌شود.', 'surenapost' ),
			'response' => $decoded,
		);
	}

	/**
	 * ساخت وضعیت قابل استفاده در رابط مدیریت.
	 *
	 * @param WC_Order $order سفارش.
	 * @return array
	 */
	public function get_ui_state( $order ) {
		$tracking_code = trim( (string) $order->get_meta( '_surenapost_tracking', true ) );
		$status        = (string) $order->get_meta( '_surenapost_status', true );

		if ( strlen( $tracking_code ) > 3 && ( '' === $status || self::STATUS_NONE === $status ) ) {
			$status = self::STATUS_TRACKED;
		}

		return array(
			'status'              => $status,
			'tracking_code'       => $tracking_code,
			'has_barcode'         => strlen( $tracking_code ) > 3,
			'can_issue'           => '' === $status || self::STATUS_NONE === $status,
			'is_pending_tracking' => self::STATUS_PENDING_TRACKING === $status,
			'has_tracking'        => self::STATUS_TRACKED === $status && strlen( $tracking_code ) > 3,
			'is_cancel_requested' => self::STATUS_PENDING_CANCEL === $status,
			'is_cancelled'        => self::STATUS_CANCELLED === $status,
			'remote_status'       => trim( (string) $order->get_meta( '_surenapost_remote_status_label', true ) ),
			'auto_refresh'        => in_array( $status, array( self::STATUS_PENDING_TRACKING, self::STATUS_PENDING_CANCEL ), true ),
		);
	}

	/**
	 * تغییر وضعیت کلی ووکامرس پس از دریافت بارکد.
	 *
	 * @param WC_Order $order   سفارش.
	 * @param string   $barcode بارکد.
	 */
	private function mark_order_as_shipped( $order, $barcode ) {
		if ( self::WC_SHIPPED_STATUS === $order->get_status() ) {
			return;
		}

		$order->update_status(
			self::WC_SHIPPED_STATUS,
			sprintf(
				/* translators: %s: Sourenapost barcode. */
				__( 'بارکد سورناپست صادر شد: %s', 'surenapost' ),
				$barcode
			)
		);
	}

	/**
	 * ذخیره جزئیات مالی و چاپی برگشتی API.
	 *
	 * @param WC_Order $order سفارش.
	 * @param array    $item  خروجی API.
	 */
	private function apply_costs_to_order( $order, $item ) {
		if ( empty( $item['extra'] ) ) {
			return;
		}

		$extra = $item['extra'];
		if ( is_string( $extra ) ) {
			$decoded_extra = json_decode( $extra, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded_extra ) ) {
				$extra = $decoded_extra;
			}
		}

		if ( ! is_array( $extra ) ) {
			return;
		}
		$map   = array(
			'postage'    => '_surenapost_postage',
			'insurance'  => '_surenapost_insurance',
			'tax'        => '_surenapost_tax',
			'totalPrice' => '_surenapost_totalPrice',
			'date'       => '_surenapost_remote_date',
			'time'       => '_surenapost_remote_time',
			'payTypeText' => '_surenapost_payTypeText',
			'postType'   => '_surenapost_postType',
		);

		foreach ( $map as $remote_key => $meta_key ) {
			if ( isset( $extra[ $remote_key ] ) && is_scalar( $extra[ $remote_key ] ) ) {
				$order->update_meta_data( $meta_key, sanitize_text_field( (string) $extra[ $remote_key ] ) );
			}
		}

		// QR برگشتی API باید عیناً برای چاپ استفاده شود؛ در نسخه قبلی QR به‌صورت محلی ساخته می‌شد.
		foreach ( array( 'qr_code', 'qrCode' ) as $qr_key ) {
			if ( isset( $extra[ $qr_key ] ) && is_scalar( $extra[ $qr_key ] ) ) {
				$order->update_meta_data( '_surenapost_qr_code', sanitize_textarea_field( (string) $extra[ $qr_key ] ) );
				break;
			}
		}

		foreach ( array( 'size', 'boxSize', 'boxSizeId' ) as $size_key ) {
			if ( isset( $extra[ $size_key ] ) && is_scalar( $extra[ $size_key ] ) && absint( $extra[ $size_key ] ) > 0 ) {
				$order->update_meta_data( '_surenapost_boxSizeId', absint( $extra[ $size_key ] ) );
				break;
			}
		}

		if ( isset( $extra['payType'] ) && is_scalar( $extra['payType'] ) ) {
			$pay_type = trim( sanitize_text_field( (string) $extra['payType'] ) );

			if ( '' !== $pay_type ) {
				if ( ctype_digit( $pay_type ) ) {
					$order->update_meta_data( '_surenapost_payType', absint( $pay_type ) );
					$pay_type_label = $this->resolve_dependency_name( 'payType', absint( $pay_type ) );
					if ( '' !== $pay_type_label ) {
						$order->update_meta_data( '_surenapost_payType_label', $pay_type_label );
					}
				} else {
					$order->update_meta_data( '_surenapost_payType_label', $pay_type );
				}
			}
		}
	}

	/**
	 * عنوان خوانای وابستگی را از کش افزونه برمی‌گرداند.
	 *
	 * @param string $type    نوع وابستگی.
	 * @param int    $item_id شناسه وابستگی.
	 * @return string
	 */
	private function resolve_dependency_name( $type, $item_id ) {
		if ( ! class_exists( 'Surenapost_Dependencies_Manager' ) ) {
			return '';
		}

		$dependencies_manager = new Surenapost_Dependencies_Manager();
		return $dependencies_manager->get_dependency_name( $type, $item_id );
	}

	/**
	 * استخراج بارکد با پشتیبانی از نام‌های مختلف فیلد API.
	 *
	 * @param array $item خروجی API.
	 * @return string
	 */
	private function extract_barcode( $item ) {
		foreach ( array( 'barcode', 'trackingCode', 'tracking' ) as $key ) {
			if ( isset( $item[ $key ] ) && is_scalar( $item[ $key ] ) ) {
				return trim( (string) $item[ $key ] );
			}
		}

		return '';
	}

	/**
	 * استخراج برچسب وضعیت API.
	 *
	 * @param array $item خروجی API.
	 * @return string
	 */
	private function get_remote_status_label( $item ) {
		foreach ( array( 'status', 'statusTitle', 'state', 'stateTitle', 'message' ) as $key ) {
			if ( isset( $item[ $key ] ) && is_scalar( $item[ $key ] ) ) {
				return trim( wp_strip_all_tags( (string) $item[ $key ] ) );
			}
		}

		return '';
	}

	/**
	 * نرمال‌سازی وضعیت API.
	 *
	 * @param string $status_label برچسب وضعیت.
	 * @return string
	 */
	private function normalize_remote_status( $status_label ) {
		$status_key = strtolower( trim( (string) $status_label ) );

		switch ( $status_key ) {
			case 'لغو شده':
			case 'cancelled':
			case 'canceled':
				return 'cancelled';

			case 'سفارش مورد نظر یافت نشد':
			case 'not_found':
			case 'not found':
				return 'not_found';

			case 'در انتظار':
			case 'pending':
				return 'pending';

			case 'ثبت شده':
			case 'registered':
				return 'registered';
		}

		return 'unknown';
	}


	/**
	 * یکسان‌سازی ارقام فارسی، عربی و لاتین و حذف سایر کاراکترها.
	 *
	 * @param mixed $value مقدار خام.
	 * @return string
	 */
	private function normalize_digits( $value ) {
		$value = strtr(
			(string) $value,
			array(
				'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
				'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
				'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
				'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			)
		);

		return preg_replace( '/[^0-9]/', '', $value );
	}

	/**
	 * دریافت شماره تماس گیرنده از اطلاعات استاندارد یا متاهای رایج سفارش.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	private function get_order_phone( $order ) {
		$candidates = array( $order->get_billing_phone() );

		if ( is_callable( array( $order, 'get_shipping_phone' ) ) ) {
			$candidates[] = $order->get_shipping_phone();
		}

		foreach ( array( '_billing_phone', '_shipping_phone', 'billing_phone', 'shipping_phone', 'mobile', '_mobile' ) as $meta_key ) {
			$candidates[] = $order->get_meta( $meta_key, true );
		}

		foreach ( $candidates as $candidate ) {
			$mobile = $this->normalize_digits( $candidate );
			if ( strlen( $mobile ) >= 10 ) {
				return $mobile;
			}
		}

		return '';
	}

	/**
	 * دریافت کدپستی گیرنده از اطلاعات سفارش.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	private function get_order_postcode( $order ) {
		foreach ( array( $order->get_shipping_postcode(), $order->get_billing_postcode(), $order->get_meta( '_surenapost_postcode', true ) ) as $candidate ) {
			$postcode = $this->normalize_digits( $candidate );
			if ( 10 === strlen( $postcode ) ) {
				return $postcode;
			}
		}

		return '';
	}

	/**
	 * پیام واقعی خطای API را برمی‌گرداند.
	 *
	 * @param array  $decoded  پاسخ API.
	 * @param string $fallback پیام جایگزین.
	 * @return string
	 */
	private function extract_api_error_message( $decoded, $fallback ) {
		foreach ( array( 'error', 'message' ) as $key ) {
			if ( isset( $decoded[ $key ] ) && is_scalar( $decoded[ $key ] ) && '' !== trim( (string) $decoded[ $key ] ) ) {
				return sanitize_text_field( (string) $decoded[ $key ] );
			}
		}

		return $fallback;
	}

	/**
	 * تبدیل خطای پیش‌بینی‌نشده PHP به WP_Error و ثبت جزئیات در لاگ.
	 *
	 * این متد باعث می‌شود AJAX و WP-Cron به‌جای خطای خام HTTP 500،
	 * پیام قابل پیگیری برگردانند.
	 *
	 * @param \Throwable $throwable خطای PHP.
	 * @param string     $context   محل رخ دادن خطا.
	 * @return WP_Error
	 */
	private function create_unexpected_error( $throwable, $context ) {
		$reference = 'SP-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 4, false, false );

		error_log(
			sprintf(
				'[Surenapost][%1$s][%2$s] %3$s in %4$s:%5$d' . PHP_EOL . '%6$s',
				$reference,
				$context,
				$throwable->getMessage(),
				$throwable->getFile(),
				$throwable->getLine(),
				$throwable->getTraceAsString()
			)
		);

		return new WP_Error(
			'surenapost_internal_error',
			sprintf(
				/* translators: 1: tracking reference, 2: PHP error message. */
				__( 'خطای داخلی افزونه هنگام بروزرسانی رخ داد. شناسه پیگیری: %1$s. جزئیات: %2$s', 'surenapost' ),
				$reference,
				sanitize_text_field( $throwable->getMessage() )
			)
		);
	}

	/**
	 * دریافت توکن افزونه.
	 *
	 * @return string
	 */
	private function get_api_key() {
		$api_manager = new Surenapost_Api_Manager();
		return trim( (string) $api_manager->get_api_key() );
	}
}

<?php
/**
 * کلاس API Manager
 *
 * مسئولیت مدیریت API Key و تنظیمات API
 *
 * @package    Surenapost
 * @subpackage Admin
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس API Manager
 */
class Surenapost_Api_Manager {

	/**
	 * نام option برای ذخیره API Key
	 *
	 * @var string
	 */
	private $api_key_option = 'surenapost_api_key';

	/**
	 * نام option برای ذخیره تنظیمات اضافی
	 *
	 * @var string
	 */
	private $api_settings_option = 'surenapost_api_settings';

	/**
	 * سازنده کلاس
	 */
	public function __construct() {
		// متدها از طریق hooks فراخوانی می‌شوند
	}

	/**
	 * ثبت تنظیمات
	 */
	public function register_settings() {
		register_setting(
			'surenapost_api_settings_group',
			$this->api_key_option,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_api_key' ),
				'default'           => '',
			)
		);

		register_setting(
			'surenapost_api_settings_group',
			$this->api_settings_option,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_api_settings' ),
				'default'           => array(),
			)
		);
	}

	/**
	 * پردازش ذخیره API Key
	 */
    public function handle_api_key_save() {
        // بررسی اینکه آیا فرم ارسال شده است
        if ( ! isset( $_POST['surenapost_save_api_key'] ) ) {
            return;
        }

        // بررسی nonce برای امنیت
        if ( ! isset( $_POST['surenapost_api_nonce'] ) || ! wp_verify_nonce( wp_unslash( $_POST['surenapost_api_nonce'] ), 'surenapost_save_api_key' ) ) {
            add_action( 'admin_notices', array( $this, 'error_notice' ) );
            return;
        }

        // بررسی دسترسی کاربر
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_woocommerce' ) ) {
            add_action( 'admin_notices', array( $this, 'permission_error_notice' ) );
            return;
        }

        $api_key = isset( $_POST['surenapost_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_api_key'] ) ) : '';

        // ذخیره API Key
        update_option( $this->api_key_option, $api_key );

        // ذخیره تنظیمات اضافی
        $current_settings = $this->get_api_settings();
        $print_mode       = isset( $_POST['surenapost_print_mode'] )
            ? sanitize_key( wp_unslash( $_POST['surenapost_print_mode'] ) )
            : ( isset( $current_settings['print_mode'] ) ? sanitize_key( $current_settings['print_mode'] ) : 'full' );

        $allowed_print_modes = array(
            'a5_products',
            'a6_products',
            'a5_products_end',
            'a6_products_end',
            'a6_no_products',
            'a5_no_products',
        );

        // سازگاری با تنظیمات نسخه‌های قبلی.
        if ( 'full' === $print_mode ) {
            $print_mode = 'a5_products';
        } elseif ( 'summary' === $print_mode ) {
            $print_mode = 'a6_no_products';
        }

        if ( ! in_array( $print_mode, $allowed_print_modes, true ) ) {
            $print_mode = 'a5_products';
        }

        $settings = array(
            'environment' => isset( $_POST['surenapost_environment'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_environment'] ) ) : 'production',
            'auto_sync'   => isset( $_POST['surenapost_auto_sync'] ) ? 1 : 0,
            'print_mode'  => $print_mode,
        );

        update_option( $this->api_settings_option, $settings );

        // ذخیره اطلاعات فرستنده
        update_option(
            'surenapost_sender_name',
            isset( $_POST['surenapost_sender_name'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_name'] ) ) : ''
        );

        update_option(
            'surenapost_sender_state',
            isset( $_POST['surenapost_sender_state'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_state'] ) ) : ''
        );

        update_option(
            'surenapost_sender_city',
            isset( $_POST['surenapost_sender_city'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_city'] ) ) : ''
        );

        update_option(
            'surenapost_sender_address',
            isset( $_POST['surenapost_sender_address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['surenapost_sender_address'] ) ) : ''
        );

        update_option(
            'surenapost_sender_postcode',
            isset( $_POST['surenapost_sender_postcode'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_postcode'] ) ) : ''
        );

        update_option(
            'surenapost_sender_phone',
            isset( $_POST['surenapost_sender_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['surenapost_sender_phone'] ) ) : ''
        );

        // ذخیره فلگ موفقیت
        set_transient( 'surenapost_api_save_success', true, 5 );

        // Redirect برای جلوگیری از ارسال مجدد فرم
        $return_page = isset( $_POST['surenapost_return_page'] ) ? sanitize_key( wp_unslash( $_POST['surenapost_return_page'] ) ) : 'api';

        if ( 'setup' === $return_page ) {
            $redirect_url = admin_url( 'admin.php?page=surenapost-setup&settings-updated=1' );
        } else {
            $redirect_url = admin_url( 'admin.php?page=surenapost&tab=api&settings-updated=1' );
        }

        wp_safe_redirect( $redirect_url );
        exit;
    }
	/**
	 * نمایش پیام موفقیت
	 */
	public function success_notice() {
		// بررسی اینکه آیا تنظیمات به تازگی ذخیره شده است
		if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] === '1' ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p><strong><?php echo esc_html__( 'موفق:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'تنظیمات با موفقیت ذخیره شد.', 'surenapost' ); ?></p>
			</div>
			<?php
		}
	}

	/**
	 * نمایش پیام خطا
	 */
	public function error_notice() {
		?>
		<div class="notice notice-error is-dismissible">
			<p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'خطای امنیتی: درخواست نامعتبر است.', 'surenapost' ); ?></p>
		</div>
		<?php
	}

	/**
	 * نمایش پیام خطای دسترسی
	 */
	public function permission_error_notice() {
		?>
		<div class="notice notice-error is-dismissible">
			<p><strong><?php echo esc_html__( 'خطا:', 'surenapost' ); ?></strong> <?php echo esc_html__( 'شما دسترسی لازم برای انجام این عملیات را ندارید.', 'surenapost' ); ?></p>
		</div>
		<?php
	}

	/**
	 * دریافت API Key
	 *
	 * @return string
	 */
	public function get_api_key() {
		return get_option( $this->api_key_option, '' );
	}

	/**
	 * دریافت تنظیمات API
	 *
	 * @return array
	 */
	public function get_api_settings() {
		return get_option( $this->api_settings_option, array() );
	}

	/**
	 * بررسی وجود API Key
	 *
	 * @return bool
	 */
	public function has_api_key() {
		$api_key = $this->get_api_key();
		return ! empty( $api_key );
	}

	/**
	 * پاک‌سازی API Key
	 *
	 * @param string $api_key API Key خام
	 * @return string
	 */
	public function sanitize_api_key( $api_key ) {
		return sanitize_text_field( trim( $api_key ) );
	}

	/**
	 * پاک‌سازی تنظیمات API
	 *
	 * @param array $settings تنظیمات خام
	 * @return array
	 */
	public function sanitize_api_settings( $settings ) {
		if ( ! is_array( $settings ) ) {
			return array();
		}

		$sanitized = array();

		if ( isset( $settings['environment'] ) ) {
			$sanitized['environment'] = in_array( $settings['environment'], array( 'production', 'sandbox' ), true ) ? $settings['environment'] : 'production';
		}

		if ( isset( $settings['auto_sync'] ) ) {
			$sanitized['auto_sync'] = absint( $settings['auto_sync'] );
		}

		if ( isset( $settings['print_mode'] ) ) {
			$print_mode = sanitize_key( $settings['print_mode'] );
			if ( 'full' === $print_mode ) {
				$print_mode = 'a5_products';
			} elseif ( 'summary' === $print_mode ) {
				$print_mode = 'a6_no_products';
			}

			$allowed_print_modes = array(
				'a5_products',
				'a6_products',
				'a5_products_end',
				'a6_products_end',
				'a6_no_products',
				'a5_no_products',
			);
			$sanitized['print_mode'] = in_array( $print_mode, $allowed_print_modes, true ) ? $print_mode : 'a5_products';
		}

		return $sanitized;
	}
}


<?php
/**
 * پلاگین سورنا پست
 *
 * پلاگین حرفه‌ای برای مدیریت خدمات پستی سورنا
 *
 * @package    Surenapost
 * @author     Surenapost Team
 * @copyright  2024 Surenapost
 * @license    GPL-2.0+
 * @since      1.2.0
 *
 * @wordpress-plugin
 * Plugin Name:       Surenapost
 * Plugin URI:        https://surena3d.com/q/wp
 * Description:       پلاگین حرفه‌ای برای مدیریت خدمات پستی سورنا
 * Version:           1.3.13
 * Author:            Surenapost Team
 * Author URI:        https://surena3d.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       surenapost
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Requires PHP:      7.4
 */

// اگر این فایل مستقیماً فراخوانی شود، دسترسی را قطع می‌کنیم
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نسخه پلاگین
 */
define( 'SURENAPOST_VERSION', '1.3.13' );

/**
 * مسیر پلاگین
 */
define( 'SURENAPOST_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * URL پلاگین
 */
define( 'SURENAPOST_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * نام پلاگین
 */
define( 'SURENAPOST_PLUGIN_NAME', 'surenapost' );

/**
 * حداقل نسخه ووکامرس مورد نیاز
 */
define( 'SURENAPOST_MIN_WC_VERSION', '5.0.0' );

/**
 * بررسی نصب و نسخه ووکامرس
 *
 * @return bool true اگر ووکامرس نصب، فعال و به‌روز باشد.
 */
function surenapost_check_woocommerce() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return false;
	}
	if ( ! defined( 'WC_VERSION' ) ) {
		return false;
	}
	return version_compare( WC_VERSION, SURENAPOST_MIN_WC_VERSION, '>=' );
}

/**
 * نمایش پیام خطا در ادمین وقتی ووکامرس نصب/فعال/نسخه کافی نیست
 */
function surenapost_woocommerce_required_notice() {
	$message = __( 'افزونه سورنا پست به ووکامرس نیاز دارد. لطفاً ابتدا ووکامرس را نصب و فعال کنید (حداقل نسخه %s).', 'surenapost' );
	$message = sprintf( $message, SURENAPOST_MIN_WC_VERSION );
	echo '<div class="notice notice-error"><p><strong>سورنا پست:</strong> ' . esc_html( $message ) . '</p></div>';
}

/**
 * تابع فعال‌سازی پلاگین
 */
function activate_surenapost() {
	if ( ! surenapost_check_woocommerce() ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
		add_action( 'admin_notices', 'surenapost_woocommerce_required_notice' );
		wp_die(
			esc_html__( 'افزونه سورنا پست به ووکامرس نیاز دارد. لطفاً ابتدا ووکامرس را نصب و فعال کنید (حداقل نسخه ', 'surenapost' ) . SURENAPOST_MIN_WC_VERSION . esc_html__( '). پس از نصب ووکامرس می‌توانید دوباره این افزونه را فعال کنید.', 'surenapost' ),
			esc_html__( 'وابستگی برآورده نشد', 'surenapost' ),
			array( 'back_link' => true )
		);
	}
	require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost-activator.php';
	Surenapost_Activator::activate();
}

/**
 * تابع غیرفعال‌سازی پلاگین
 */
function deactivate_surenapost() {
	require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost-deactivator.php';
	Surenapost_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_surenapost' );
register_deactivation_hook( __FILE__, 'deactivate_surenapost' );


/**
 * اعلام سازگاری با High-Performance Order Storage ووکامرس.
 */
function surenapost_declare_hpos_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
}
add_action( 'before_woocommerce_init', 'surenapost_declare_hpos_compatibility' );

/**
 * بارگذاری پلاگین فقط در صورت وجود ووکامرس (بعد از لود ووکامرس)
 */
function surenapost_bootstrap() {
	if ( ! surenapost_check_woocommerce() ) {
		add_action( 'admin_notices', 'surenapost_woocommerce_required_notice' );
		return;
	}
	require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost.php';
	$plugin = new Surenapost();
	$plugin->run();
}

add_action( 'plugins_loaded', 'surenapost_bootstrap', 20 );

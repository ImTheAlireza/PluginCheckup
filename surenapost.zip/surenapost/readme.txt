=== Surenapost ===
Contributors: Surenapost
Tags: post, postal, barcode, shipping
Requires at least: 5.5
Tested up to: 6.9
Stable tag: 1.3.10
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

# پلاگین سورنا پست

پلاگین حرفه‌ای وردپرس برای مدیریت خدمات پستی سورنا

**صفحهٔ افزونه (خرید و اطلاعات بیشتر):** [surena3d.com/q/wp](https://surena3d.com/q/wp)

## Description

Surena Post provides a fully professional, fast, and seamless shipping management experience through direct integration with trusted postal carriers. Fully compatible with WooCommerce, this plugin transforms the way your store handles shipping and order fulfillment.

### Key Features & Benefits of Surena Post Professional Shipping Plugin

* **Real-Time Shipping Cost Calculation** — Accurate shipping costs are calculated instantly based on the customer's location, ensuring transparent and precise pricing at checkout.

* **Parcel Pickup from Your Store Location** — No more trips to the post office. Once the shipping cost is confirmed, Surena Post can arrange pickup directly from your warehouse. Parcels are professionally packaged and handed over to the selected postal carrier.

* **Instant Invoice & Tracking Barcode Generation** — After order confirmation, tracking codes and barcodes are automatically generated, and a printable invoice becomes immediately available.

* **Automated Wallet-Based Payment & Settlement** — Simplify your financial management with Surena Post's wallet system. All shipping fees are deducted from your wallet balance, eliminating the need for individual payments per shipment.

* **Support for Multiple Shipping Methods** — Including Express, Standard, Prepaid, Cash on Delivery (COD), Pay on Delivery, and Fast Shipping options.

* **SMS Notifications at Every Shipping Stage** — Both store owners and customers receive SMS updates throughout the shipping process. Real-time tracking is also available via a tracking link sent by SMS.

* **Shipment Insurance for Added Security** — Enable insurance coverage to protect against loss or damage. In case of issues, compensation is provided to the seller.

* **Full WooCommerce Compatibility with User-Friendly Interface** — Surena Post integrates seamlessly with WooCommerce and offers a clean, intuitive interface. No technical expertise is required to manage shipments efficiently.

* **Compatible with Multiple Payment Gateways** — Works smoothly with most payment gateways, ensuring a unified checkout experience without complex configurations.

## ویژگی‌ها

- ✅ مدیریت API Key در دیتابیس
- ✅ رابط کاربری زیبا و واکنش‌گرا
- ✅ پشتیبانی از RTL
- ✅ کدهای استاندارد وردپرس

## ساختار پلاگین

```
surenapost/
├── admin/
│   ├── css/
│   │   └── surenapost-admin.css
│   ├── js/
│   │   └── surenapost-admin.js
│   ├── partials/
│   │   └── surenapost-admin-display.php
│   ├── class-surenapost-admin.php
│   ├── class-surenapost-api-manager.php
│   └── index.php
├── includes/
│   ├── class-surenapost.php
│   ├── class-surenapost-loader.php
│   ├── class-surenapost-activator.php
│   ├── class-surenapost-deactivator.php
│   └── index.php
├── languages/
├── surenapost.php
└── readme.txt
```

## کلاس‌های اصلی

### Surenapost
کلاس اصلی پلاگین که مسئولیت بارگذاری و مدیریت تمام بخش‌ها را بر عهده دارد.

### Surenapost_Admin
کلاس مدیریت بخش ادمین که منوها و صفحات ادمین را ایجاد می‌کند.

### Surenapost_Api_Manager
کلاس مدیریت API Key که مسئولیت ذخیره و بازیابی API Key از دیتابیس را دارد.

### Surenapost_Loader
کلاس مدیریت hooks که تمام action ها و filter های پلاگین را ثبت می‌کند.

## استفاده

1. پلاگین را در پوشه `wp-content/plugins/` قرار دهید
2. از پنل ادمین وردپرس پلاگین را فعال کنید
3. به منوی "سورنا پست" در پنل ادمین بروید
4. در تب "تنظیمات API" API Key خود را وارد کنید

## تب‌های موجود

- **داشبورد**: نمایش وضعیت کلی پلاگین
- **تنظیمات API**: مدیریت API Key و تنظیمات API
- **گزارش‌ها**: نمایش گزارش‌های مربوط به خدمات پستی

## نسخه

1.0.0

## نویسنده

Surenapost Team

## مجوز

GPL-2.0+








== Changelog ==

= 1.3.3 =
* انتقال کامل بروزرسانی وابستگی‌ها به endpoint جدید dependency/extra.
* پشتیبانی از ساختار جدید type، name و value برای postType، packetType، boxSize و payType.
* جایگزینی اتمی داده‌های قبلی پس از دریافت موفق پاسخ API و جلوگیری از حذف اطلاعات در خطای ارتباطی.
* ذخیره پاسخ پاک‌سازی‌شده وابستگی‌ها برای سازگاری با نوع‌های بعدی API.

= 1.3.2 =
* ذخیره اطلاعات جدید پاسخ API شامل مبلغ پرداخت در محل، نوع سرویس و QR واقعی.
* بازطراحی کامل چاپ مطابق برچسب جدید سورناپست.
* یکپارچه‌سازی مسیرهای قدیمی و جدید چاپ.

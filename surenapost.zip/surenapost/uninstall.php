<?php
/**
 * فایل Uninstall
 *
 * این فایل هنگام حذف پلاگین اجرا می‌شود
 *
 * @package    Surenapost
 * @author     Surenapost Team
 * @since      1.0.0
 */

// اگر این فایل مستقیماً فراخوانی شود، دسترسی را قطع می‌کنیم
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// حذف options از دیتابیس
delete_option( 'surenapost_api_key' );
delete_option( 'surenapost_api_settings' );

// حذف کش استان‌ها و شهرها
delete_option( 'surenapost_provinces_data' );
delete_transient( 'surenapost_provinces_cache' );

// حذف وابستگی‌های سورنا پست
delete_option( 'surenapost_post_services' );
delete_option( 'surenapost_packet_types' );
delete_option( 'surenapost_box_sizes' );
delete_option( 'surenapost_pay_types' );
delete_option( 'surenapost_dependencies_raw' );
delete_option( 'surenapost_dependencies_last_refresh' );
delete_transient( 'surenapost_deps_cache_post-services' );
delete_transient( 'surenapost_deps_cache_packet-types' );
delete_transient( 'surenapost_deps_cache_box-sizes' );
delete_transient( 'surenapost_deps_cache_payType' );

// حذف کش شهرها (برای تمام استان‌ها)
global $wpdb;
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
        $wpdb->esc_like( 'surenapost_cities_data_' ) . '%',
        $wpdb->esc_like( '_transient_surenapost_cities_cache_' ) . '%',
        $wpdb->esc_like( '_transient_timeout_surenapost_cities_cache_' ) . '%',
        $wpdb->esc_like( '_transient_surenapost_provinces_cache' ) . '%'
    )
);

// حذف site options در صورت استفاده از multisite
if ( is_multisite() ) {
    delete_site_option( 'surenapost_api_key' );
    delete_site_option( 'surenapost_api_settings' );
    delete_site_option( 'surenapost_provinces_data' );
}



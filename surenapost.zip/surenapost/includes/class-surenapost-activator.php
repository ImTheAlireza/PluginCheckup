<?php
/**
 * کلاس Activator
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Surenapost_Activator {

	/**
	 * اجرای عملیات فعال‌سازی.
	 */
	public static function activate() {
		require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-order-service.php';

		add_filter( 'cron_schedules', array( 'Surenapost_Order_Service', 'add_cron_schedule' ) );
		Surenapost_Order_Service::ensure_cron_scheduled();

		flush_rewrite_rules();
	}
}

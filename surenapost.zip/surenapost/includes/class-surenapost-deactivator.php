<?php
/**
 * کلاس Deactivator
 *
 * @package Surenapost
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Surenapost_Deactivator {

	/**
	 * اجرای عملیات غیرفعال‌سازی.
	 */
	public static function deactivate() {
		require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-order-service.php';
		Surenapost_Order_Service::clear_cron_schedule();

		flush_rewrite_rules();
	}
}

<?php
/**
 * کلاس اصلی پلاگین
 *
 * این کلاس مسئولیت بارگذاری و مدیریت تمام بخش‌های پلاگین را بر عهده دارد
 *
 * @package    Surenapost
 * @subpackage Includes
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * کلاس اصلی پلاگین
 */
class Surenapost {

    /**
     * Loader برای مدیریت hooks
     *
     * @var Surenapost_Loader
     */
    protected $loader;

    /**
     * نام پلاگین
     *
     * @var string
     */
    protected $plugin_name;

    /**
     * نسخه پلاگین
     *
     * @var string
     */
    protected $version;

    /**
     * سازنده کلاس
     */
    public function __construct() {
        $this->version     = SURENAPOST_VERSION;
        $this->plugin_name = SURENAPOST_PLUGIN_NAME;

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
    }

    /**
     * بارگذاری وابستگی‌ها
     */
    private function load_dependencies() {
        require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost-loader.php';
        require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost-activator.php';
        require_once SURENAPOST_PLUGIN_DIR . 'includes/class-surenapost-deactivator.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-order-service.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-admin.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-api-manager.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-locations-cache.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-locations-db.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-dependencies-manager.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-wallet-client.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-payments-client.php';
        require_once SURENAPOST_PLUGIN_DIR . 'admin/class-surenapost-transactions-client.php';

        require_once SURENAPOST_PLUGIN_DIR . 'admin/surenapost-wallet.php';


        $this->loader = new Surenapost_Loader();
    }

    /**
     * تنظیمات زبان
     * ترجمه‌های پلاگین در WordPress.org به‌صورت خودکار لود می‌شوند.
     */
    private function set_locale() {
        // Translations for WordPress.org-hosted plugins are loaded automatically.
    }

    /**
     * تعریف hooks مربوط به ادمین
     */
    private function define_admin_hooks() {
        $order_service = new Surenapost_Order_Service();
        $plugin_admin  = new Surenapost_Admin( $this->get_plugin_name(), $this->get_version(), $order_service );
        $api_manager   = new Surenapost_Api_Manager();

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        $this->loader->add_action( 'admin_menu', $plugin_admin, 'add_admin_menu' );
        $this->loader->add_action( 'admin_init', $api_manager, 'register_settings' );
        $this->loader->add_action( 'admin_init', $api_manager, 'handle_api_key_save' );
        $this->loader->add_action( 'admin_notices', $api_manager, 'success_notice' );
        $this->loader->add_action( 'admin_init', $plugin_admin, 'handle_refresh_locations_submit' );
        $this->loader->add_action( 'admin_init', $plugin_admin, 'handle_setup_actions' );

        // زمان‌بندی بروزرسانی خودکار وضعیت سفارش‌ها و وضعیت کلی «ارسال شد».
        $this->loader->add_filter( 'cron_schedules', $order_service, 'add_cron_schedule' );
        $this->loader->add_action( 'init', $order_service, 'ensure_cron_scheduled' );
        $this->loader->add_action( Surenapost_Order_Service::CRON_HOOK, $order_service, 'cron_refresh_pending_orders' );
        $this->loader->add_action( 'init', $plugin_admin, 'register_surenapost_shipped_status' );
        $this->loader->add_filter( 'wc_order_statuses', $plugin_admin, 'add_surenapost_shipped_status' );

        $this->loader->add_action( 'admin_post_surenapost_print_label', $plugin_admin, 'surenapost_render_print_label' );

        // ستون و اکشن‌های مربوط به سفارش‌های ووکامرس (لیست قدیمی بر پایه پست‌تایپ)
        $this->loader->add_filter( 'manage_edit-shop_order_columns', $plugin_admin, 'add_surenapost_order_column' );
        $this->loader->add_action( 'manage_shop_order_posts_custom_column', $plugin_admin, 'render_surenapost_order_column', 10, 2 );

        // ستون و اکشن‌های مربوط به سفارش‌های ووکامرس در صفحه wc-orders (سیستم جدید HPOS)
        $this->loader->add_filter( 'woocommerce_shop_order_list_table_columns', $plugin_admin, 'add_surenapost_hpos_order_column' );
        $this->loader->add_action( 'woocommerce_shop_order_list_table_custom_column', $plugin_admin, 'render_surenapost_hpos_order_column', 10, 2 );

        // فیلتر وضعیت سورناپست در فهرست سفارش‌ها؛ سازگار با جدول قدیمی و HPOS.
        $this->loader->add_action( 'restrict_manage_posts', $plugin_admin, 'render_surenapost_status_filter', 10, 2 );
        $this->loader->add_action( 'woocommerce_order_list_table_restrict_manage_orders', $plugin_admin, 'render_surenapost_status_filter', 10, 2 );
        $this->loader->add_action( 'pre_get_posts', $plugin_admin, 'filter_legacy_orders_by_surenapost_status' );
        $this->loader->add_filter( 'woocommerce_order_list_table_prepare_items_query_args', $plugin_admin, 'filter_hpos_orders_by_surenapost_status' );

        // اکشن‌های AJAX برای دریافت استان‌ها و شهرها
        $this->loader->add_action( 'wp_ajax_surenapost_get_provinces', $plugin_admin, 'ajax_get_provinces' );
        $this->loader->add_action( 'wp_ajax_surenapost_get_cities', $plugin_admin, 'ajax_get_cities' );
        $this->loader->add_action( 'wp_ajax_surenapost_check_locations', $plugin_admin, 'ajax_check_locations' );
        // ذخیره استان و شهر انتخابی برای هر سفارش
        $this->loader->add_action( 'wp_ajax_surenapost_save_order_destination', $plugin_admin, 'ajax_save_order_destination' );
        // بروزرسانی و پاک کردن کش استان‌ها و شهرها
        $this->loader->add_action( 'wp_ajax_surenapost_refresh_locations_cache', $plugin_admin, 'ajax_refresh_locations_cache' );
        $this->loader->add_action( 'wp_ajax_surenapost_clear_locations_cache', $plugin_admin, 'ajax_clear_locations_cache' );
        // بروزرسانی وابستگی‌های سورنا پست
        $this->loader->add_action( 'wp_ajax_surenapost_update_dependencies', $plugin_admin, 'ajax_update_dependencies' );
        // دریافت وابستگی‌ها و اطلاعات سفارش
        $this->loader->add_action( 'wp_ajax_surenapost_get_dependencies', $plugin_admin, 'ajax_get_dependencies' );
        $this->loader->add_action( 'wp_ajax_surenapost_get_order_info', $plugin_admin, 'ajax_get_order_info' );
        // ارسال سفارش به API سورناپست و دریافت کد رهگیری
        $this->loader->add_action( 'wp_ajax_surenapost_send_order', $plugin_admin, 'ajax_send_order' );
        $this->loader->add_action( 'wp_ajax_surenapost_get_tracking', $plugin_admin, 'ajax_get_tracking' );
        $this->loader->add_action( 'wp_ajax_surenapost_suspend_barcode', $plugin_admin, 'ajax_suspend_barcode' );
        $this->loader->add_action( 'wp_ajax_surenapost_refresh_cancel_status', $plugin_admin, 'ajax_refresh_cancel_status' );
        $this->loader->add_action( 'wp_ajax_surenapost_refresh_order_ui', $plugin_admin, 'ajax_refresh_order_ui' );
        $this->loader->add_action( 'wp_ajax_surenapost_refresh_visible_orders', $plugin_admin, 'ajax_refresh_visible_orders' );
        $this->loader->add_action( 'wp_ajax_surenapost_increment_print_count', $plugin_admin, 'ajax_increment_print_count' );

        // نمایش اطلاعات رهگیری در صفحه ویرایش سفارش
        $this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'add_tracking_metabox', 10 );

    }

    /**
     * اجرای loader برای ثبت تمام hooks
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * دریافت نام پلاگین
     *
     * @return string
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * دریافت loader
     *
     * @return Surenapost_Loader
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * دریافت نسخه پلاگین
     *
     * @return string
     */
    public function get_version() {
        return $this->version;
    }
}


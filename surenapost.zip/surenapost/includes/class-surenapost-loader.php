<?php
/**
 * کلاس Loader
 *
 * مسئولیت ثبت و اجرای تمام hooks پلاگین
 *
 * @package    Surenapost
 * @subpackage Includes
 * @author     Surenapost Team
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس Loader
 */
class Surenapost_Loader {

	/**
	 * آرایه actions
	 *
	 * @var array
	 */
	protected $actions;

	/**
	 * آرایه filters
	 *
	 * @var array
	 */
	protected $filters;

	/**
	 * سازنده کلاس
	 */
	public function __construct() {
		$this->actions = array();
		$this->filters = array();
	}

	/**
	 * افزودن action
	 *
	 * @param string   $hook          نام hook
	 * @param object   $component     کامپوننت
	 * @param string   $callback      نام متد callback
	 * @param int      $priority      اولویت
	 * @param int      $accepted_args تعداد آرگومان‌ها
	 */
	public function add_action( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * افزودن filter
	 *
	 * @param string   $hook          نام hook
	 * @param object   $component     کامپوننت
	 * @param string   $callback      نام متد callback
	 * @param int      $priority      اولویت
	 * @param int      $accepted_args تعداد آرگومان‌ها
	 */
	public function add_filter( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * افزودن hook به آرایه
	 *
	 * @param array    $hooks         آرایه hooks
	 * @param string   $hook          نام hook
	 * @param object   $component     کامپوننت
	 * @param string   $callback      نام متد callback
	 * @param int      $priority      اولویت
	 * @param int      $accepted_args تعداد آرگومان‌ها
	 * @return array
	 */
	private function add( $hooks, $hook, $component, $callback, $priority, $accepted_args ) {
		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args,
		);

		return $hooks;
	}

	/**
	 * اجرای تمام hooks
	 */
	public function run() {
		foreach ( $this->filters as $hook ) {
			add_filter(
				$hook['hook'],
				array( $hook['component'], $hook['callback'] ),
				$hook['priority'],
				$hook['accepted_args']
			);
		}

		foreach ( $this->actions as $hook ) {
			add_action(
				$hook['hook'],
				array( $hook['component'], $hook['callback'] ),
				$hook['priority'],
				$hook['accepted_args']
			);
		}
	}
}


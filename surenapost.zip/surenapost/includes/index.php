<?php
/**
 * فایل امنیتی
 *
 * @package    Surenapost
 * @subpackage Includes
 * @author     Surenapost Team
 * @since      1.0.0
 */

// Silence is golden.


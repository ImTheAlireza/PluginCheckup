<?php

if (!defined('ABSPATH')) die('No direct access allowed');

if (!class_exists('WPO_WebP_Convert')) :

class WPO_WebP_Convert {

	public $converters = null;

	public function __construct() {
		$this->converters = WP_Optimize()->get_options()->get_option('webp_converters');
	}

	/**
	 * Converts uploaded image to webp format
	 *
	 * @param string $source - path of the source file
	 * @return bool
	 */
	public function convert($source) {
		if (count($this->converters) < 1) return false;

		$destination = $this->get_destination_path($source);
		return $this->check_converters_and_do_conversion($source, $destination);
	}

	/**
	 * Returns the destination full path
	 *
	 * @param string $source - path of the source file
	 *
	 * @return string $destination - path of destination file
	 */
	public function get_destination_path($source) {
		$path_parts = pathinfo($source);
		return $path_parts['dirname'] . '/'. basename($source) . '.webp';
	}

	/**
	 * Loop through available converters and do the conversion
	 *
	 * @param string $source      - path of source file
	 * @param string $destination - path of destination file
	 *
	 * @return bool
	 */
	protected function check_converters_and_do_conversion($source, $destination) {
		foreach ($this->converters as $converter) {
			WPO_WebP_Utils::perform_webp_conversion($converter, $source, $destination);
			if (is_file($destination)) return true;
		}

		return false;
	}
}
endif;

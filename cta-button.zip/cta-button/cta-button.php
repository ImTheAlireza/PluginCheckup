<?php
/*
Plugin Name: دکمه تماس شناور
Description: یک افزونه برای نمایش دکمه تماس در گوشه سایت.
Version: 1.0
Author: ماهدیس وب
Author URI: https://mahdisweb.net  
*/


if ( ! defined( 'WPINC' ) ) {
	die;
}

if( ! defined( 'CTA_VERSION' ) ) define( 'CTA_VERSION', '1.0' );
if( ! defined( 'CTA_PATH' ) ) define( 'CTA_PATH', plugin_dir_path( __FILE__ ) );
if( ! defined( 'CTA_URL' ) ) define( 'CTA_URL', plugin_dir_url( __FILE__ ) );


require_once( CTA_PATH. '/includes.php' );



new MW_ContactButton();

?>

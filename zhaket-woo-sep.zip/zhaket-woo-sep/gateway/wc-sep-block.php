<?php
defined('ABSPATH') || die('Access Denied!');

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class WC_SEP_BLOCK extends AbstractPaymentMethodType
{
    public $name = 'WC_Sep_Payment_Gateway';

    public function initialize()
    {
        $this->settings = get_option('woocommerce_WC_Sep_Payment_Gateway_settings', array());
    }

    public function is_active()
    {
        return ! empty($this->settings['enabled']) && 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_data()
    {
        return array(
            'id'               => $this->name,
            'title'            => ! empty($this->settings['title']) ? $this->settings['title'] : 'بانک سامان',
            'description'      => ! empty($this->settings['description']) ? $this->settings['description'] : '',
            'icon'             => defined('SEP_WOO_IMAGE') ? SEP_WOO_IMAGE . '/gateway-saman.png' : '',
            'OrderButtonLabel' => __('Continue for payment.', 'sb24wc'),
            'supports'         => array('products'),
            'enable_blupay'    => ! empty($this->settings['enable_blupay']) && 'yes' === $this->settings['enable_blupay'],
            'enable_blu_direct' => ! empty($this->settings['enable_blu_direct']) && 'yes' === $this->settings['enable_blu_direct'],
            'enable_gam'       => ! empty($this->settings['enable_gam']) && 'yes' === $this->settings['enable_gam'],
            'enable_gov'       => ! empty($this->settings['enable_gov']) && 'yes' === $this->settings['enable_gov'],
        );
    }

    public function get_payment_method_script_handles()
    {
        wp_register_script(
            'SEP_BLOCK_SETTINGS',
            SEP_WOO_ZHK_URL . 'assets/js/block-settings.js',
            array('wc-blocks-registry', 'wc-settings', 'wp-element'),
            '5',
            true
        );
        return array('SEP_BLOCK_SETTINGS');
    }
}
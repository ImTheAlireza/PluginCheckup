<?php
class WC_Sep_Payment_Gateway extends WC_Payment_Gateway
{
    private $merchantcode;
    private $multiIban;
    private $success_massage;
    private $failed_massage;
    public $goverment_details;

    public function __construct()
    {
        $this->id = 'WC_Sep_Payment_Gateway';
        $this->method_title = __('Saman Bank Payment Gateway', 'sb24wc');
        $this->method_description = __('Bank Saman payment gateway settings for WooCommerce', 'sb24wc');
        $this->icon = SEP_WOO_IMAGE . '/gateway-saman.png';
        $this->title = __('Saman Bank gateway', 'sb24wc');

        $this->init_gateway_form_fields();
        $this->init_settings();

        $this->description = $this->get_option('description');
        $this->title = $this->get_option('title');
        $this->merchantcode = $this->get_option('merchantcode');
        $this->multiIban = $this->get_option('multi');
        $this->success_massage = $this->get_option('success_massage');
        $this->failed_massage = $this->get_option('failed_massage');
        $this->has_fields = false;

        $this->goverment_details = get_option('woocommerce_sep_accounts', array());

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'save_goverment_details'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'RequestPayment'));
        add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'VerifyPayment'));
    }

    public function init_gateway_form_fields()
    {
        $this->form_fields = [
            'base_config' => array(
                'title' => __('Basic Settings', 'sb24wc'),
                'type' => 'title',
                'description' => '',
            ),
            'enabled' => array(
                'title' => __('Activation/Deactivation', 'sb24wc'),
                'type' => 'checkbox',
                'label' => __('Saman Gateway Activation', 'sb24wc'),
                'description' => __('To activate the Saman payment gateway, you need to check the box.', 'sb24wc'),
                'default' => 'no',
                'desc_tip' => true,
            ),
            'title' => array(
                'title' => __('Gateway Title', 'sb24wc'),
                'type' => 'text',
                'description' => __('The title of the gateway displayed to the customer during the purchase.', 'sb24wc'),
                'default' => __('Saman Bank', 'sb24wc'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Gateway Description', 'sb24wc'),
                'type' => 'text',
                'desc_tip' => true,
                'description' => __('Details will be displayed during the payment process for the gateway.', 'sb24wc'),
                'default' => __('Secure payment through all Shetab member cards via Saman Bank gateway.', 'sb24wc'),
            ),
            'account_config' => array(
                'title' => __('Saman account settings', 'sb24wc'),
                'type' => 'title',
                'description' => '',
            ),
            'merchantcode' => array(
                'title' => __('Merchant ID', 'sb24wc'),
                'type' => 'text',
                'description' => __('Merchant ID received from Saman Bank.', 'sb24wc'),
                'default' => '',
                'desc_tip' => true,
            ),
            'enable_blupay' => array(
                'title'       => __('فعالسازی درگاه نئو (Neo)', 'sb24wc'),
                'type'        => 'checkbox',
                'label'       => __('کاربر پس از ثبت سفارش به درگاه نئو هدایت شود', 'sb24wc'),
                'description' => __('با فعال بودن این گزینه، مشتری به صفحه‌ی نئو هدایت می‌شود و آنجا می‌تواند روش پرداخت را انتخاب کند: کارت‌های شتاب، بلو، سپ‌کارت سازمانی یا خرید اقساطی بالن. این سرویس باید از سمت بانک سامان روی «پذیرنده/ترمینال» شما فعال شده باشد. برای فعالسازی، درخواست خود را همراه با شماره ترمینال به ایمیل epay@sep.ir ارسال نمایید.', 'sb24wc'),
                'default'     => 'no',
                'desc_tip'    => true,
            ),
            'enable_blu_direct' => array(
                'title'       => __('پرداخت سریع بلو (مستقیم)', 'sb24wc'),
                'type'        => 'checkbox',
                'label'       => __('گزینه‌ی «پرداخت سریع با بلو» در صفحه‌ی تسویه‌حساب نمایش داده شود', 'sb24wc'),
                'description' => __('با فعال بودن این گزینه، مشتری می‌تواند مستقیماً در صفحه‌ی تسویه‌حساب سایت شما بلو را انتخاب کند و بدون عبور از صفحه‌ی واسط نئو، مستقیم به صفحه‌ی پرداخت بلو منتقل شود. توجه: این روش بدون شماره موبایل معتبر مشتری کار نمی‌کند و نیاز به فعالسازی از سمت بانک سامان روی ترمینال شما دارد؛ درخواست خود را همراه با شماره ترمینال به ایمیل epay@sep.ir ارسال نمایید.', 'sb24wc'),
                'default'     => 'no',
                'desc_tip'    => true,
            ),
            'blupay_mobile_meta_key' => array(
                'title'       => __('کلید سفارشی شماره موبایل (اختیاری)', 'sb24wc'),
                'type'        => 'text',
                                'description' => __('فقط برای موارد خاص: اگر شماره موبایل مشتری در سایت شما با کلید متای غیرمتعارفی ذخیره می‌شود (نه فیلد استاندارد ووکامرس)، نام دقیق آن کلید را اینجا وارد کنید تا افزونه هنگام پرداخت با نئو یا بلو از آن هم شماره را بخواند. در بیشتر سایت‌ها نیازی به این فیلد نیست و می‌توانید خالی بگذارید.', 'sb24wc'),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'enable_gam' => array(
                'title'   => __('فعالسازی اوراق گام', 'sb24wc'),
                'type'    => 'checkbox',
                'label'   => __('امکان پرداخت با اوراق گام فعال شود', 'sb24wc'),
                'default' => 'no',
            ),
            'enable_gov' => array(
                'title'   => __('فعالسازی درگاه دولتی با شناسه', 'sb24wc'),
                'type'    => 'checkbox',
                'label'   => __('امکان پرداخت دولتی فعال شود', 'sb24wc'),
                'default' => 'no',
            ),
            'gov_iban' => array(
                'title'       => __('شماره شبای سازمان دولتی مقصد', 'sb24wc'),
                'type'        => 'text',
                'description' => __('شماره شبای مقصد برای واریز وجوه دولتی (با حروف IR شروع شود)', 'sb24wc'),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'payment_config' => array(
                'title' => __('Payment Operations Settings', 'sb24wc'),
                'type' => 'title',
                'description' => '',
            ),
            'success_massage' => array(
                'title' => __('Payment Successful', 'sb24wc'),
                'type' => 'textarea',
                'description' => __('Message after a successful payment. Shortcode {transaction_id} is available.', 'sb24wc'),
                'default' => __('Thank you. Your order has been successfully paid.', 'sb24wc'),
            ),
            'failed_massage' => array(
                'title' => __('Payment Failed Message', 'sb24wc'),
                'type' => 'textarea',
                'description' => __('Message after an unsuccessful payment. Shortcode {fault} is available.', 'sb24wc'),
                'default' => __('Your payment was unsuccessful. Please try again or contact support.', 'sb24wc'),
            ),
            'multi' => array(
                'title' => __('Government funds (Public funds)', 'sb24wc'),
                'type' => 'checkbox',
                'label' => __('Multiple account payment and government funds activation', 'sb24wc'),
                'description' => __('If you activate this, you can define several accounts (government and ordinary)', 'sb24wc'),
                'default' => 'no',
                'desc_tip' => true,
            ),
            'goverment' => array(
                'type' => 'goverment_details',
            ),
        ];
    }

    public function generate_goverment_details_html()
    {
        ob_start();
        ?>
        <tr valign="top" class="hideable_field">
            <th scope="row" class="titledesc">
                <label>
                    <?php esc_html_e('Account information', 'sb24wc'); ?>
                    <?php echo wp_kses_post(wc_help_tip(__('For sharing and government payments, enter the account information', 'sb24wc'))); ?>
                </label>
            </th>
            <td class="forminp" id="sep_accounts">
                <div class="wc_input_table_wrapper">
                    <table class="widefat wc_input_table" cellspacing="0">
                        <thead>
                        <tr>
                            <th><?php esc_html_e('IBAN', 'sb24wc'); ?></th>
                            <th><?php esc_html_e('Share percentage', 'sb24wc'); ?></th>
                            <th><?php esc_html_e('Government ID', 'sb24wc'); ?></th>
                        </tr>
                        </thead>
                        <tbody class="accounts">
                        <?php
                        $i = -1;
                        if ($this->goverment_details) {
                            foreach ($this->goverment_details as $account) {
                                $i++;
                                echo '<tr class="account">
                                    <td><input type="text" class="first_iban" value="' . esc_attr($account['iban']) . '" name="group_iban[' . esc_attr($i) . ']" /></td>
                                    <td><input type="number" class="first_percent" value="' . esc_attr($account['percent']) . '" name="group_percent[' . esc_attr($i) . ']" /></td>
                                    <td><input type="text" value="' . esc_attr($account['goverment']) . '" name="group_goverment[' . esc_attr($i) . ']" /></td>
                                </tr>';
                            }
                        }
                        ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th colspan="7">
                                <a href="#" class="add button"><?php esc_html_e('+ Add account', 'woocommerce'); ?></a>
                                <a href="#" class="remove_rows button"><?php esc_html_e('Remove selected account(s)', 'woocommerce'); ?></a>
                            </th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
                <script type="text/javascript">
                    jQuery(document).ready(function ($) {
                        function toggleRepeaterFields() {
                            if ($('#woocommerce_WC_Sep_Payment_Gateway_multi').is(':checked')) {
                                $('.hideable_field').closest('tr').show();
                                $(".first_iban").attr("required", true);
                                $(".first_percent").attr("required", true);
                            } else {
                                $('.hideable_field').closest('tr').hide();
                                $(".first_iban").removeAttr('required');
                                $(".first_percent").removeAttr('required');
                            }
                        }
                        toggleRepeaterFields();
                        $('#woocommerce_WC_Sep_Payment_Gateway_multi').change(toggleRepeaterFields);
                    });
                    jQuery(function () {
                        jQuery('#sep_accounts').on('click', 'a.add', function () {
                            var size = jQuery('#sep_accounts').find('tbody .account').length;
                            if (size > 7) return false;
                            jQuery('<tr class="account">\
                                <td><input type="text" required name="group_iban[' + size + ']" /></td>\
                                <td><input type="text" required name="group_percent[' + size + ']" /></td>\
                                <td><input type="text" name="group_goverment[' + size + ']" /></td>\
                            </tr>').appendTo('#sep_accounts table tbody');
                            return false;
                        });
                    });
                </script>
            </td>
        </tr>
        <?php
        return ob_get_clean();
    }

    public function save_goverment_details()
    {
        if (!isset($_POST['woocommerce_WC_Sep_Payment_Gateway_multi'])) {
            return;
        }

        $accounts = array();

        if (isset($_POST['group_iban']) && isset($_POST['group_percent'])) {
            $ibans = wc_clean(wp_unslash($_POST['group_iban']));
            $percent = wc_clean(wp_unslash($_POST['group_percent']));
            $goverment = isset($_POST['group_goverment']) ? wc_clean(wp_unslash($_POST['group_goverment'])) : array();

            if (intval(array_sum($percent)) !== 100) {
                WC_Admin_Settings::add_error(__('The total share percentage should always be 100%', 'sb24wc'));
                return;
            }

            foreach ($ibans as $i => $iban) {
                $accounts[] = array(
                    'iban' => $iban,
                    'percent' => isset($percent[$i]) ? $percent[$i] : 0,
                    'goverment' => isset($goverment[$i]) ? $goverment[$i] : '',
                );
            }
        }

        update_option('woocommerce_sep_accounts', $accounts);
    }

    public function payment_fields()
    {
        if ($this->description) {
            echo wpautop(wptexturize($this->description));
        }

        $enable_neo        = $this->get_option('enable_blupay') === 'yes';
        $enable_blu_direct = $this->get_option('enable_blu_direct') === 'yes';
        $enable_gam        = $this->get_option('enable_gam') === 'yes';
        $enable_gov        = $this->get_option('enable_gov') === 'yes';

        // اگر هیچ کانال اضافه‌ای فعال نباشد، مثل قبل هیچ رادیویی نمایش داده نمی‌شود
        if (!$enable_blu_direct && !$enable_gam && !$enable_gov) {
            return;
        }

        // متن گزینه‌ی پیش‌فرض بسته به اینکه نئو روشن است یا نه
        $normal_label = $enable_neo
            ? esc_html__('درگاه بانک سامان (کارت، بلو، سپ‌کارت، بالن)', 'sb24wc')
            : esc_html__('کارت‌های عضو شتاب (عادی)', 'sb24wc');

        echo '<fieldset id="sep-payment-channels" style="margin-top:15px;border:1px solid #ddd;padding:15px;border-radius:5px;">';
        echo '<legend style="padding:0 10px;font-size:14px;">' . esc_html__('روش پرداخت مورد نظر خود را انتخاب کنید:', 'sb24wc') . '</legend>';

        echo '<p style="margin-bottom:10px;"><label><input type="radio" name="sep_payment_channel" value="normal" checked style="margin-left:8px;" /> ' . $normal_label . '</label></p>';

        if ($enable_blu_direct) {
            echo '<p style="margin-bottom:10px;"><label><input type="radio" name="sep_payment_channel" value="blu_direct" style="margin-left:8px;" /> ' . esc_html__('پرداخت سریع با بلو', 'sb24wc') . '</label></p>';
        }
        if ($enable_gam) {
            echo '<p style="margin-bottom:10px;"><label><input type="radio" name="sep_payment_channel" value="gam" style="margin-left:8px;" /> ' . esc_html__('پرداخت با اوراق گام', 'sb24wc') . '</label></p>';
        }
        if ($enable_gov) {
            echo '<p style="margin-bottom:10px;"><label><input type="radio" name="sep_payment_channel" id="sep_channel_gov" value="gov" style="margin-left:8px;" /> ' . esc_html__('درگاه پرداخت دولتی (سازمان‌ها)', 'sb24wc') . '</label></p>';
            echo '<p id="sep_gov_id_wrapper" style="display:none;margin:10px 0 0 0;padding:10px;background:#f9f9f9;border:1px dashed #ccc;">';
            echo '<label style="display:block;margin-bottom:5px;">' . esc_html__('شناسه پرداخت دولتی (۳۰ رقمی):', 'sb24wc') . ' <span style="color:red;">*</span></label>';
            echo '<input type="text" name="sep_gov_id" id="sep_gov_id" class="input-text" maxlength="30" style="width:100%;padding:8px;" />';
            echo '</p>';
        }
        echo '</fieldset>';

        if ($enable_gov) {
            ?>
            <script type="text/javascript">
                jQuery(function ($) {
                    $('input[name="sep_payment_channel"]').change(function () {
                        if ($(this).val() === 'gov') { $('#sep_gov_id_wrapper').slideDown(); }
                        else { $('#sep_gov_id_wrapper').slideUp(); }
                    });
                });
            </script>
            <?php
        }
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);

        $channel = isset($_POST['sep_payment_channel']) ? sanitize_text_field(wp_unslash($_POST['sep_payment_channel'])) : 'normal';
        $gov_id  = isset($_POST['sep_gov_id']) ? sanitize_text_field(wp_unslash($_POST['sep_gov_id'])) : '';
        $gov_id  = $this->normalize_purchase_id($gov_id);

        $allowed = array('normal');
        if ($this->get_option('enable_blu_direct') === 'yes') $allowed[] = 'blu_direct';
        if ($this->get_option('enable_gam') === 'yes')        $allowed[] = 'gam';
        if ($this->get_option('enable_gov') === 'yes')        $allowed[] = 'gov';
        if (!in_array($channel, $allowed, true)) {
            $channel = 'normal';
        }

        if ($channel === 'gov') {
            if (empty($gov_id) || !preg_match('/^\d{30}$/', $gov_id)) {
                wc_add_notice(__('برای پرداخت دولتی، شناسه پرداخت باید یک عدد ۳۰ رقمی باشد.', 'sb24wc'), 'error');
                return array('result' => 'failure');
            }
            if (empty($this->get_option('gov_iban'))) {
                wc_add_notice(__('شماره شبای سازمان دولتی در تنظیمات افزونه ثبت نشده است.', 'sb24wc'), 'error');
                return array('result' => 'failure');
            }
        }

        // شماره موبایل فقط برای «پرداخت سریع بلو» الزامی است.
        // برای درگاه نئو، نبودِ شماره باعث رد شدن سفارش نمی‌شود؛
        // در آن حالت کاربر به‌صورت خودکار به درگاه کلاسیک هدایت می‌شود.
        if ($channel === 'blu_direct' && $this->resolve_cell_number($order) === '') {
            wc_add_notice(__('برای پرداخت سریع با بلو، وارد کردن شماره موبایل معتبر (۰۹...) الزامی است. لطفاً شماره موبایل خود را در اطلاعات صورتحساب وارد کنید یا روش پرداخت دیگری انتخاب نمایید.', 'sb24wc'), 'error');
            return array('result' => 'failure');
        }

        $order->update_meta_data('_sep_payment_channel', $channel);
        if (!empty($gov_id)) {
            $order->update_meta_data('_sep_gov_id', $gov_id);
        }
        $order->save();

        return array(
            'result'   => 'success',
            'redirect' => $order->get_checkout_payment_url(true),
        );
    }

    public function RequestPayment($order_id)
    {
        global $woocommerce;
        $woocommerce->session->sep_order_id = $order_id;

        $order = wc_get_order($order_id);
        $total = $this->to_rial($order->get_total(), $order->get_currency());

        $Token = json_decode($this->get_token($this->merchantcode, $total, $order_id));

        if (empty($Token) || !isset($Token->status)) {
            wc_add_notice(__('An error has occurred, please contact support.', 'sb24wc'), 'error');
            wp_safe_redirect(wc_get_checkout_url());
            exit;
        }

        if ((int)$Token->status === 1 && !empty($Token->token)) {
            echo esc_html__('Transferring to the banking portal, please wait...', 'sb24wc');

            $channel  = $order->get_meta('_sep_payment_channel');
            $has_cell = $this->get_neo_cellnumber($order) !== '';

            if ($channel === 'blu_direct') {
                // پرداخت سریع بلو: مستقیم به صفحه‌ی اختصاصی بلو
                $Payment_URL = $this->get_ocp_blu_url();
            } elseif ($this->get_option('enable_blupay') === 'yes' && $has_cell && !empty($Token->redirect_url)) {
                // درگاه نئو: آدرس از هدر X-IPG-Url خوانده می‌شود
                $Payment_URL = $Token->redirect_url;
            } else {
                // درگاه کلاسیک شاپرک
                $Payment_URL = self::get_env('PAYMENT_URL');
            }
            ?>
            <form id="pay_form" action="<?php echo esc_url($Payment_URL); ?>" method="post" style="display:none;">
                <input type="hidden" name="Token" value="<?php echo esc_attr($Token->token); ?>"/>
                <input type="hidden" name="GetMethod" value=""/>
            </form>
            <script type="text/javascript">document.getElementById("pay_form").submit();</script>
            <?php
            exit;
        }

        $error = isset($Token->errorDesc) ? $Token->errorDesc : '';
        wc_add_notice(__('Error connecting to the bank port', 'sb24wc') . ' ' . $error, 'error');
        if (!empty($Token->errorCode)) {
            $order->add_order_note(print_r($Token->errorCode, true));
        }
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }

    public function VerifyPayment()
    {
        global $woocommerce;

        $State  = isset($_POST['State'])  ? sanitize_text_field(wp_unslash($_POST['State']))  : '';
        $ResNum = isset($_POST['ResNum']) ? sanitize_text_field(wp_unslash($_POST['ResNum'])) : '';
        $RefNum = isset($_POST['RefNum']) ? sanitize_text_field(wp_unslash($_POST['RefNum'])) : '';
        $TermId = $this->merchantcode;
        $NeoFeature = isset($_POST['NeoFeature']) ? sanitize_text_field(wp_unslash($_POST['NeoFeature'])) : '';

        if (isset($_GET['wc_order'])) {
            $order_id = sanitize_text_field(wp_unslash($_GET['wc_order']));
        } elseif ($ResNum) {
            $order_id = $ResNum;
        } else {
            $order_id = $woocommerce->session->sep_order_id ?? '';
            unset($woocommerce->session->sep_order_id);
        }

        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order) {
            $this->fail_with_note(false, __('There is no order number.', 'sb24wc'));
        }

        if (in_array($order->get_status(), array('completed', 'processing'), true)) {
            $tid = $order->get_meta('_transaction_id');
            $Notice = str_replace('{transaction_id}', $tid, wpautop(wptexturize($this->success_massage)));
            if ($Notice) wc_add_notice($Notice, 'success');
            wp_safe_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));
            exit;
        }

        if ($State === '' || $ResNum === '' || $RefNum === '') {
            $this->fail_with_note($order, __('One or more parameters were not sent.', 'sb24wc'), $RefNum);
        }

        $verify = $this->get_verify_trans($TermId, $RefNum);
        $result = isset($verify['result']) ? $verify['result'] : null;

        // جزئیات بسته به نسخه در TransactionDetail یا VerifyInfo قرار می‌گیرد
        $detail = null;
        if (is_object($result)) {
            if (!empty($result->TransactionDetail)) {
                $detail = $result->TransactionDetail;
            } elseif (!empty($result->VerifyInfo)) {
                $detail = $result->VerifyInfo;
            }
        }
        if (!$detail) {
            $this->fail_with_note($order, __('There is a problem with the payment, please contact support.', 'sb24wc'), $RefNum);
        }

        if ((int)$result->ResultCode !== 0) {
            $order->add_order_note(sprintf('Bank verify failed. ResultCode: %s', $result->ResultCode), 1);
            $msg = sprintf(__('The transaction with bank ID %s has failed and will be refunded.', 'sb24wc'), $RefNum);
            $this->fail_with_note($order, $msg, $RefNum, false);
        }

        $expected = $this->to_rial($order->get_total(), $order->get_currency());
        $paid = isset($detail->OrginalAmount) ? intval($detail->OrginalAmount) : -1;

        if ($paid !== $expected) {
            $order->add_order_note(sprintf('Amount mismatch! Expected: %d, Paid: %d, RefNum: %s', $expected, $paid, $RefNum), 1);
            $this->fail_with_note($order, __('مبلغ پرداخت‌شده با مبلغ سفارش مغایرت دارد.', 'sb24wc'), $RefNum, false);
        }
        
        if ($NeoFeature !== '') {
            $order->update_meta_data('_sep_neo_feature', $NeoFeature);
            $order->add_order_note(sprintf(
                __('روش پرداخت انتخابی مشتری: %s', 'sb24wc'),
                $this->translate_neo_feature($NeoFeature)
            ), 1);
        }

        $order->update_meta_data('_transaction_id', $RefNum);
        $order->save();
        $order->payment_complete($RefNum);
        $woocommerce->cart->empty_cart();
        $order->add_order_note(sprintf('Payment was successful. Tracking code: %s', $RefNum), 1);

        $Notice = str_replace('{transaction_id}', $RefNum, wpautop(wptexturize($this->success_massage)));
        if ($Notice) wc_add_notice($Notice, 'success');

        wp_safe_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));
        exit;
    }
    
    
/**
 * شماره‌ی نهاییِ CellNumber برای ارسال به بانک.
 * اگر نه درگاه نئو و نه پرداخت سریع بلو فعال نباشند، خالی برمی‌گرداند؛
 * در غیر این صورت شماره را طبق نمونه‌ی مستندات سامان
 * بدون صفرِ ابتدا (۹xxxxxxxxx) برمی‌گرداند.
 */
private function get_neo_cellnumber($order)
{
    $neo_enabled = $this->get_option('enable_blupay') === 'yes';
    $blu_enabled = $this->get_option('enable_blu_direct') === 'yes';

    if (!$neo_enabled && !$blu_enabled) {
        return '';
    }

    $mobile = $this->resolve_cell_number($order); // 09xxxxxxxxx یا خالی
    return $mobile !== '' ? substr($mobile, 1) : '';
}

/**
 * آدرس صفحه‌ی اختصاصی پرداخت سریع بلو.
 * ابتدا از فایل .env خوانده می‌شود و در صورت نبود، مقدار پیش‌فرض استفاده می‌شود.
 */
private function get_ocp_blu_url()
{
    $url = self::get_env('NEO_OCP_BLU_URL');
    return !empty($url) ? $url : 'https://neo-pg.sep.ir/ocp-blu/transaction/init';
}

/**
 * یافتن شماره موبایل معتبر از منابع مختلف،
 * حتی وقتی قالب/افزونه از فیلد پیش‌فرض ووکامرس استفاده نکند.
 * خروجی: 09xxxxxxxxx یا رشته‌ی خالی.
 */
private function resolve_cell_number($order)
{
    $candidates = array();

    if ($order) {
        $candidates[] = $order->get_billing_phone();

        $meta_keys = array(
            // استاندارد و رایج ووکامرس (بدون کلیدهای داخلیِ زیرخط‌دار)
            'billing_mobile', '_billing_mobile',
            'billing_mobile_phone', '_billing_mobile_phone',
            'billing_cellphone', '_billing_cellphone',
            // عمومی
            'mobile', '_mobile',
            // دیجیتس (تأییدشده)
            'digits_phone', '_digits_phone',
            // فیلدهای اضافیِ چک‌اوت بلوکی
            '_wc_other/mobile',
        );
        foreach ($meta_keys as $key) {
            $val = $order->get_meta($key);
            if (!empty($val)) {
                $candidates[] = $val;
            }
        }
        
        // کلید سفارشیِ تعیین‌شده توسط ادمین (اگر پر شده باشد)
        $custom_key = trim((string) $this->get_option('blupay_mobile_meta_key'));
        if ($custom_key !== '') {
            $val = $order->get_meta($custom_key);
            if (!empty($val)) {
                $candidates[] = $val;
            }
            $uid_custom = $order->get_customer_id();
            if ($uid_custom) {
                $user_val = get_user_meta($uid_custom, $custom_key, true);
                if (!empty($user_val)) {
                    $candidates[] = $user_val;
                }
            }
        }

        $uid = $order->get_customer_id();
        if ($uid) {
            foreach (array('billing_mobile', 'billing_phone', 'mobile', 'digits_phone') as $key) {
                $val = get_user_meta($uid, $key, true);
                if (!empty($val)) {
                    $candidates[] = $val;
                }
            }
        }
    }

    $candidates = apply_filters('sep_blupay_cell_number_candidates', $candidates, $order);

    foreach ($candidates as $raw) {
        $normalized = $this->normalize_iran_mobile($raw);
        if ($normalized !== '') {
            return $normalized;
        }
    }

    return apply_filters('sep_blupay_cell_number', '', $order);
}

/**
 * نرمال‌سازی و اعتبارسنجی شماره موبایل ایران به فرمت 09xxxxxxxxx.
 */
private function normalize_iran_mobile($raw)
{
    if (empty($raw)) {
        return '';
    }

    $fa = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
    $ar = array('٠','١','٢','٣','٤','٥','٦','٧','٨','٩');
    $en = array('0','1','2','3','4','5','6','7','8','9');
    $raw = str_replace($fa, $en, $raw);
    $raw = str_replace($ar, $en, $raw);

    $digits = preg_replace('/\D+/', '', $raw);
    if ($digits === '') {
        return '';
    }

    if (strpos($digits, '0098') === 0) {
        $digits = '0' . substr($digits, 4);
    } elseif (strpos($digits, '98') === 0 && strlen($digits) === 12) {
        $digits = '0' . substr($digits, 2);
    } elseif (strpos($digits, '9') === 0 && strlen($digits) === 10) {
        $digits = '0' . $digits;
    }

    if (preg_match('/^09\d{9}$/', $digits)) {
        return $digits;
    }

    return '';
}


/**
 * نرمال‌سازی شماره شبا به فرمت موردنیاز بانک: IR + ۲۴ رقم (با حروف بزرگ)
 */
private function normalize_iban($iban)
{
    $fa = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
    $ar = array('٠','١','٢','٣','٤','٥','٦','٧','٨','٩');
    $en = array('0','1','2','3','4','5','6','7','8','9');
    $iban = str_replace($fa, $en, (string)$iban);
    $iban = str_replace($ar, $en, $iban);

    // حذف فاصله، خط تیره و هر کاراکتر غیرمجاز
    $iban = preg_replace('/[^A-Za-z0-9]/', '', $iban);
    $iban = strtoupper($iban);

    // اگر کاربر فقط ۲۴ رقم وارد کرده باشد، IR را خودمان اضافه می‌کنیم
    if (preg_match('/^\d{24}$/', $iban)) {
        $iban = 'IR' . $iban;
    }

    return preg_match('/^IR\d{24}$/', $iban) ? $iban : '';
}

/**
 * نرمال‌سازی شناسه واریز دولتی: دقیقاً ۳۰ رقم
 */
private function normalize_purchase_id($id)
{
    $fa = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
    $ar = array('٠','١','٢','٣','٤','٥','٦','٧','٨','٩');
    $en = array('0','1','2','3','4','5','6','7','8','9');
    $id = str_replace($fa, $en, (string)$id);
    $id = str_replace($ar, $en, $id);
    $id = preg_replace('/\D+/', '', $id);

    return (strlen($id) === 30) ? $id : '';
}

/**
 * ترجمه‌ی مقدار NeoFeature بازگشتی از درگاه نئو به متن فارسی.
 */
private function translate_neo_feature($feature)
{
    $map = array(
        'NeoIpg'         => __('درگاه اینترنتی (پرداخت کارتی)', 'sb24wc'),
        'NeoOneClickBlu' => __('پرداخت از طریق بلو', 'sb24wc'),
        'NeoSepSegment'  => __('کارت سازمانی (سپ‌کارت چندمنظوره)', 'sb24wc'),
        'NeoBnplBalon'   => __('خرید اقساطی بالن (BNPL)', 'sb24wc'),
    );

    return isset($map[$feature]) ? $map[$feature] : $feature;
}

    public function get_token($TerminalId, $Amount, $ResNum)
    {
        $order = wc_get_order($ResNum);
        $CallbackUrl = add_query_arg('wc_order', $ResNum, WC()->api_request_url('WC_Sep_Payment_Gateway'));
        $Token_url = self::get_env('TOKEN_URL');

        $data = array(
            'action'      => 'token',
            'TerminalId'  => $TerminalId,
            'Amount'      => $Amount,
            'ResNum'      => $ResNum,
            'RedirectUrl' => $CallbackUrl,
            'CellNumber'  => $this->get_neo_cellnumber($order),
        );

        $payment_channel = $order ? $order->get_meta('_sep_payment_channel') : 'normal';
        $gov_id          = $order ? $order->get_meta('_sep_gov_id') : '';

        if ($payment_channel === 'gam') {
            $data['TranType'] = 'GamPapers';

        } elseif ($payment_channel === 'gov' && !empty($gov_id)) {
            $iban        = $this->normalize_iban($this->get_option('gov_iban'));
            $purchase_id = $this->normalize_purchase_id($gov_id);

            if ($iban !== '' && $purchase_id !== '') {
                $data['TranType'] = 'Government';
                $settlement = new stdClass();
                $settlement->IBAN       = $iban;
                $settlement->Amount     = $Amount;
                $settlement->PurchaseID = $purchase_id;
                $data['SettlementIBANInfo'] = array($settlement);
            }

        } elseif ($this->multiIban === 'yes' && is_array($this->goverment_details)) {
            foreach ($this->goverment_details as $account) {
                $iban = $this->normalize_iban(isset($account['iban']) ? $account['iban'] : '');
                if ($iban === '') continue;

                $settlement = new stdClass();
                $settlement->IBAN   = $iban;
                $settlement->Amount = (int) round(($Amount * (float)$account['percent']) / 100);

                if (!empty($account['goverment'])) {
                    $purchase_id = $this->normalize_purchase_id($account['goverment']);
                    if ($purchase_id !== '') {
                        $data['TranType'] = 'Government';
                        $settlement->PurchaseID = $purchase_id;
                    }
                }

                $data['SettlementIBANInfo'][] = $settlement;
            }
        }

        $response_headers = array();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $Token_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_CAINFO, ABSPATH . WPINC . '/certificates/ca-bundle.crt');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($curl, $header) use (&$response_headers) {
            $len = strlen($header);
            $parts = explode(':', $header, 2);
            if (count($parts) === 2) {
                $response_headers[strtolower(trim($parts[0]))] = trim($parts[1]);
            }
            return $len;
        });

        $resp = curl_exec($ch);
        if (curl_errno($ch)) {
            $err = curl_error($ch);
            curl_close($ch);
            return json_encode(array('status' => 0, 'errorDesc' => $err));
        }
        curl_close($ch);
        


        $response_data = json_decode($resp, true);
        if (is_array($response_data)) {
            $response_data['redirect_url'] = isset($response_headers['x-ipg-url']) ? $response_headers['x-ipg-url'] : '';
            return json_encode($response_data);
        }
        return $resp;
    }

    public function get_verify_trans($TermId, $RefNum)
    {
        $postFields = array(
            "TerminalNumber" => $TermId,
            "RefNum" => $RefNum,
            "CellNumber" => "",
            "NationalCode" => "",
            "IgnoreNationalcode" => true,
        );

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => self::get_env('PAYMENT_VERIFY'),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($postFields),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_CAINFO => ABSPATH . WPINC . '/certificates/ca-bundle.crt',
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        $trans['result'] = json_decode($response);
        if ($err) {
            $trans['err'] = $err;
        }
        return $trans;
    }

    private function to_rial($amount, $currency)
    {
        $amount = intval($amount);
        $currency = strtolower($currency);
        $toman = array('irt','toman','iran toman','iranian toman','iran-toman','iranian-toman','iran_toman','iranian_toman','تومان','تومان ایران');
        if (in_array($currency, $toman, true)) return $amount * 10;
        if ($currency === 'irht') return $amount * 10000;
        if ($currency === 'irhr') return $amount * 1000;
        return $amount;
    }

    private function fail_with_note($order, $message, $RefNum = '', $add_note = true)
    {
        if ($add_note && $order) {
            $order->add_order_note(sprintf('Error while returning from bank: %s', $message), 1);
        }
        $Notice = wpautop(wptexturize($this->failed_massage));
        $Notice = str_replace('{transaction_id}', $RefNum, $Notice);
        $Notice = str_replace('{fault}', $message, $Notice);
        if ($Notice) wc_add_notice($Notice, 'error');
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }

    private function get_env($name)
    {
        $envFile = SEP_WOO_ZHK_PATH . '.env';
        if (file_exists($envFile)) {
            $envLines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($envLines as $line) {
                if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
                    list($key, $value) = explode('=', $line, 2);
                    if ($key === $name) return $value;
                }
            }
        }
        return false;
    }

    public function admin_options()
    {
        ?>
        <style>
            #woocommerce_WC_Sep_Payment_Gateway_enabled,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blupay,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gam,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gov,
            #woocommerce_WC_Sep_Payment_Gateway_multi {
                -webkit-appearance: none !important;
                appearance: none !important;
                position: relative !important;
                display: inline-block !important;
                box-sizing: border-box !important;
                width: 46px !important;
                height: 24px !important;
                min-width: 46px !important;
                min-height: 24px !important;
                max-width: 46px !important;
                max-height: 24px !important;
                margin: 0 !important;
                padding: 0 !important;
                background: #ccc !important;
                border: none !important;
                border-radius: 24px !important;
                cursor: pointer !important;
                transition: background .2s !important;
                vertical-align: middle !important;
                outline: none !important;
                box-shadow: none !important;
            }
            #woocommerce_WC_Sep_Payment_Gateway_enabled:checked,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blupay:checked,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct:checked,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gam:checked,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gov:checked,
            #woocommerce_WC_Sep_Payment_Gateway_multi:checked {
                background: #34c759 !important;
            }
            #woocommerce_WC_Sep_Payment_Gateway_enabled::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blupay::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gam::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gov::before,
            #woocommerce_WC_Sep_Payment_Gateway_multi::before {
                content: "" !important;
                position: absolute !important;
                top: 2px !important;
                left: 2px !important;
                width: 20px !important;
                height: 20px !important;
                background: #fff !important;
                border-radius: 50% !important;
                box-shadow: 0 1px 3px rgba(0,0,0,.3) !important;
                transition: left .2s !important;
                margin: 0 !important;
            }
            #woocommerce_WC_Sep_Payment_Gateway_enabled:checked::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blupay:checked::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct:checked::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gam:checked::before,
            #woocommerce_WC_Sep_Payment_Gateway_enable_gov:checked::before,
            #woocommerce_WC_Sep_Payment_Gateway_multi:checked::before {
                left: 24px !important;
            }
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enabled::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_blupay::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_gam::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_gov::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_multi::before {
                left: auto !important;
                right: 2px !important;
            }
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enabled:checked::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_blupay:checked::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct:checked::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_gam:checked::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_enable_gov:checked::before,
            html[dir="rtl"] #woocommerce_WC_Sep_Payment_Gateway_multi:checked::before {
                left: auto !important;
                right: 24px !important;
            }
        </style>
        <?php
        parent::admin_options();
        ?>
        <script type="text/javascript">
        jQuery(function ($) {
            var $neo = $('#woocommerce_WC_Sep_Payment_Gateway_enable_blupay');
            var $blu = $('#woocommerce_WC_Sep_Payment_Gateway_enable_blu_direct');
            if (!$neo.length && !$blu.length) return;

            var $customKeyRow = $('#woocommerce_WC_Sep_Payment_Gateway_blupay_mobile_meta_key').closest('tr');
            function toggleMobileKeyRow() {
                if ($neo.is(':checked') || $blu.is(':checked')) { $customKeyRow.show(); }
                else { $customKeyRow.hide(); }
            }
            $neo.on('change', toggleMobileKeyRow);
            $blu.on('change', toggleMobileKeyRow);
            toggleMobileKeyRow();
        });
        </script>
        <?php
    }
}

/**
 * نمایش روش پرداخت انتخابی مشتری در صفحه‌ی جزئیات سفارش در پیشخوان.
 */
add_action('woocommerce_admin_order_data_after_billing_address', function ($order) {
    $feature = $order->get_meta('_sep_neo_feature');
    if (empty($feature)) {
        return;
    }

    $map = array(
        'NeoIpg'         => 'درگاه اینترنتی (پرداخت کارتی)',
        'NeoOneClickBlu' => 'پرداخت از طریق بلو',
        'NeoSepSegment'  => 'کارت سازمانی (سپ‌کارت چندمنظوره)',
        'NeoBnplBalon'   => 'خرید اقساطی بالن (BNPL)',
    );
    $label = isset($map[$feature]) ? $map[$feature] : $feature;

    echo '<p><strong>' . esc_html__('روش پرداخت در درگاه سامان:', 'sb24wc') . '</strong> ' . esc_html($label) . '</p>';
}, 10, 1);
( function () {
    "use strict";
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { getPaymentMethodData } = window.wc.wcSettings;
    const { createElement, useState, useEffect, RawHTML } = window.wp.element;

    const data = getPaymentMethodData( "WC_Sep_Payment_Gateway", {} );

    const Label = () =>
        createElement(
            "span",
            { style: { display: "inline-flex", alignItems: "center", gap: "8px" } },
            data.title || "بانک سامان",
            data.icon
                ? createElement( "img", { src: data.icon, alt: data.title || "بانک سامان", style: { maxHeight: "24px", width: "auto" } } )
                : null
        );

    const Content = ( props ) => {
        const { eventRegistration, emitResponse } = props;
        const { onPaymentSetup } = eventRegistration;
        const [ channel, setChannel ] = useState( "normal" );
        const [ govId, setGovId ] = useState( "" );

        const normalizeMobile = ( raw ) => {
            if ( ! raw ) return "";
            const fa = "۰۱۲۳۴۵۶۷۸۹";
            const ar = "٠١٢٣٤٥٦٧٨٩";
            let s = String( raw ).replace( /[۰-۹]/g, ( d ) => String( fa.indexOf( d ) ) );
            s = s.replace( /[٠-٩]/g, ( d ) => String( ar.indexOf( d ) ) );
            let digits = s.replace( /\D+/g, "" );
            if ( digits.indexOf( "0098" ) === 0 ) digits = "0" + digits.slice( 4 );
            else if ( digits.indexOf( "98" ) === 0 && digits.length === 12 ) digits = "0" + digits.slice( 2 );
            else if ( digits.indexOf( "9" ) === 0 && digits.length === 10 ) digits = "0" + digits;
            return /^09\d{9}$/.test( digits ) ? digits : "";
        };

        const getBillingPhone = () => {
            try {
                const store = window.wp && window.wp.data && window.wp.data.select( "wc/store/cart" );
                const cart = store && store.getCustomerData ? store.getCustomerData() : null;
                if ( cart && cart.billingAddress && cart.billingAddress.phone ) {
                    return cart.billingAddress.phone;
                }
            } catch ( e ) {}
            const field = document.querySelector( '#billing-phone, #phone, input[name="billing_phone"]' );
            return field ? field.value : "";
        };

        useEffect( () => {
            const unsubscribe = onPaymentSetup( () => {
                if ( channel === "gov" && ! /^\d{30}$/.test( govId ) ) {
                    return { type: emitResponse.responseTypes.ERROR, message: "شناسه پرداخت دولتی باید یک عدد ۳۰ رقمی باشد." };
                }
                if ( channel === "blu_direct" && normalizeMobile( getBillingPhone() ) === "" ) {
                    return {
                        type: emitResponse.responseTypes.ERROR,
                        message: "برای پرداخت سریع با بلو، وارد کردن شماره موبایل معتبر (۰۹...) در بخش اطلاعات صورتحساب الزامی است.",
                    };
                }
                return {
                    type: emitResponse.responseTypes.SUCCESS,
                    meta: { paymentMethodData: { sep_payment_channel: channel, sep_gov_id: govId } },
                };
            } );
            return () => unsubscribe();
        }, [ channel, govId, onPaymentSetup, emitResponse ] );

        const rows = [];
        if ( data.description ) rows.push( createElement( RawHTML, { key: "desc" }, data.description ) );

        const radio = ( value, text ) =>
            createElement( "p", { key: value, style: { marginBottom: "10px" } },
                createElement( "label", null,
                    createElement( "input", {
                        type: "radio", name: "sep_payment_channel", value: value,
                        checked: channel === value, onChange: () => setChannel( value ),
                        style: { marginLeft: "8px" },
                    } ),
                    " " + text
                )
            );

        const hasExtraChannels = !! ( data.enable_blu_direct || data.enable_gam || data.enable_gov );
        if ( hasExtraChannels ) {
            rows.push( radio( "normal", data.enable_blupay ? "درگاه بانک سامان (کارت، بلو، سپ‌کارت، بالن)" : "کارت‌های عضو شتاب (عادی)" ) );
            if ( data.enable_blu_direct ) rows.push( radio( "blu_direct", "پرداخت سریع با بلو" ) );
            if ( data.enable_gam )        rows.push( radio( "gam", "پرداخت با اوراق گام" ) );
            if ( data.enable_gov )        rows.push( radio( "gov", "درگاه پرداخت دولتی (سازمان‌ها)" ) );
        }

        if ( data.enable_gov && channel === "gov" ) {
            rows.push(
                createElement( "p", { key: "govid", style: { margin: "10px 0", padding: "10px", background: "#f9f9f9", border: "1px dashed #ccc" } },
                    createElement( "label", { style: { display: "block", marginBottom: "5px" } }, "شناسه پرداخت دولتی (۳۰ رقمی):" ),
                    createElement( "input", {
                        type: "text", value: govId, maxLength: 30,
                        onChange: ( e ) => setGovId( e.target.value.replace( /\D/g, "" ) ),
                        style: { width: "100%", padding: "8px" },
                    } )
                )
            );
        }
        return createElement( "div", null, rows );
    };

    registerPaymentMethod( {
        name: "WC_Sep_Payment_Gateway",
        label: createElement( Label, null ),
        placeOrderButtonLabel: data.OrderButtonLabel,
        content: createElement( Content, null ),
        edit: createElement( Content, null ),
        canMakePayment: () => true,
        ariaLabel: data.title || "پرداخت با بانک سامان",
        supports: { features: data.supports || [] },
    } );
} )();
<?php

if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;
final class Sadad_WC_Payments_Block extends AbstractPaymentMethodType {

    private $gateway;
    public $name = SADAD_WOO_ID;

    public function initialize() {
        $trns = [__("Proceed to Sadad", "sadad_woo"), __("Sadad", "sadad_woo"), __("Payment via Sadad", "sadad_woo")];
        $this->gateway = new WC_BankMelli_New();
        $this->settings = get_option('woocommerce_' . SADAD_WOO_ID . '_settings');
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
                'SADAD_WC_BLOCKS_INTEGRATION',
                plugins_url('assets/block.js', SADAD_WOO_FILE),
                array('wc-blocks-registry', 'wc-settings', 'wp-element'),
                SADAD_VER,
                true
        );

        return ['SADAD_WC_BLOCKS_INTEGRATION'];
    }

    public function get_payment_method_data() {
        return array(
            'id' => $this->gateway->id,
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icon'=>  $this->gateway->icon,
            'OrderButtonLabel'=> $this->gateway->pay_btn_text,
            'enabled' => $this->gateway->is_available(),
            'pluginUrl' => SADAD_WOO_URL,
            'supports' => $this->get_supported_features(),
        );
    }
}

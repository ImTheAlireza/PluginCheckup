<?php

if (!defined('ABSPATH')) {
    die('Access denied!');
}

function sadad_woo_admin_init()
{
    wp_enqueue_script("sadad_woo_js", SADAD_WOO_URL . "assets/tagify/tagify.js");
    wp_enqueue_script("sadad_woo_js2", SADAD_WOO_URL . "assets/tagify/jQuery.tagify.min.js", array('jquery'));
    wp_enqueue_script("sadad_woo_admin_js", SADAD_WOO_URL . "assets/admin_jscode.js", array('jquery'));
    wp_enqueue_style('sadad_woo', SADAD_WOO_URL . "assets/tagify/tagify.css");
    wp_enqueue_style('sadad_woo_admin2', SADAD_WOO_URL . "assets/admin_style.css");
}

function sadad_woo_site_init()
{
    if (wp_script_is('selectWoo', 'enqueued')) {
        wp_enqueue_script("sadad_woo_user_js", SADAD_WOO_URL . "assets/user_jscode.js", array('jquery'));
    }
    wp_enqueue_style('sadad_woo_user', SADAD_WOO_URL . "assets/user_style.css");
}

function woo_bmi2_ir_currency($currencies)
{
    if (!isset($currencies['IRR'])) {
        $currencies['IRR'] = __('ریال');
    }
    if (!isset($currencies['IRT'])) {
        $currencies['IRT'] = __('تومان');
    }
    if (!isset($currencies['IRHR'])) {
        $currencies['IRHR'] = __('هزار ریال');
    }
    if (!isset($currencies['IRHT'])) {
        $currencies['IRHT'] = __('هزار تومان');
    }

    return $currencies;
}

function woo_bmi2_ir_currency_symbol($currency_symbol, $currency)
{
    switch ($currency) {
        case 'IRR':
            $currency_symbol = 'ریال';
            break;
        case 'IRT':
            $currency_symbol = 'تومان';
            break;
        case 'IRHR':
            $currency_symbol = 'هزار ریال';
            break;
        case 'IRHT':
            $currency_symbol = 'هزار تومان';
            break;
    }
    return $currency_symbol;
}

add_action('admin_enqueue_scripts', 'sadad_woo_admin_init');
add_action('wp_enqueue_scripts', 'sadad_woo_site_init', 11);
add_filter('woocommerce_currencies', 'woo_bmi2_ir_currency');
add_filter('woocommerce_currency_symbol', 'woo_bmi2_ir_currency_symbol', 10, 2);

if (!function_exists('bmi_new_post_data')) {

    /**
     * 
     * @param string $url URL to post data
     * @param string $data_string  encoded data as JSON
     * @param string $ssl_version  SSL version
     * @return array ['err' => as string , 'res' => Result as JSON]
     */
    function bmi_new_post_data($url, $data_string, $ssl_version = 'default', $referer = '')
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=utf-8'));

        if (!empty($referer)) {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        if ($ssl_version != 'default') {
            curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, $ssl_version);
            curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_MAX_DEFAULT);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        }

        $Result = curl_exec($ch);
        $post_err = curl_error($ch);
        $curl_errno = curl_errno($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($curl_errno) {
            $Result_JSON = esc_html($Result);
            $post_err = "cURL Error #{$curl_errno}: {$post_err}";
        } else {
            $Result_JSON = json_decode($Result);
               if (json_last_error() !== JSON_ERROR_NONE) {
                $Result_JSON = null;
            }
        }

        curl_close($ch);
        $res = array('err' => $post_err, 'res' => $Result_JSON, 'http_code'=> $http_code );
        return $res;
    }
}

if (!function_exists('sadad_admin_notice')) {

    /**
     * Return Notice Message
     * @param string $msg message
     * @param string $type error, success, warning
     * @return string
     */
    function sadad_admin_notice($msg = '', $type = 'success')
    {
        return '<div class="notice notice-' . $type . ' is-dismissible">
            <p>' . $msg . '</p>
        </div>';
    }
}

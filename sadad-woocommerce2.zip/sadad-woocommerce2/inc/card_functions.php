<?php

if (!function_exists('sadad_woo_get_bank_card_num'))
{

    /**
     * Get Card Number posted from bank
     * @param number $number
     * @param int $start substring from 0 to this number
     * @param int $end substring from end ex:-4
     * @return string
     */
    function sadad_woo_get_bank_card_num($number, $start, $end)
    {
        $res = "";
        if (!empty($number))
        {
            $res = substr($number, 0, $start) . substr($number, $end);
        }
        return $res;
    }

}


if (!function_exists('sadad_woo_check_user_card_number'))
{

    /**
     * Check User Payment Bank Card for Verify
     * @param int $user_id user id
     * @param string $card_num card number
     * @param int $start substring from 0 to this number
     * @param int $end substring from end ex:-4
     * @return boolean return true if Card is  Verified and else return false 
     */
    function sadad_woo_check_user_card_number($user_id, $card_num, $start = 6, $end = -4)
    {
        $res = false;
        $cart_no = preg_replace('/\D/', '', $card_num);

        $send_cardnum1 = get_post_meta($user_id, '_send_cardnum', true);
        $send_cardnumo = get_post_meta($user_id, '_send_cardnumo', true);
        $send_cardnumt = get_post_meta($user_id, '_send_cardnumt', true);

        $send_cardnum = array();
        if (!empty($send_cardnum1))
        {
            $send_cardnum[] = $send_cardnum1;
        }

        if (!empty($send_cardnumo))
        {
            $send_cardnum[] = $send_cardnumo;
        }

        if (!empty($send_cardnumt))
        {
            $send_cardnum[] = $send_cardnumt;
        }

        if (!empty($send_cardnum))
        {
            $user_cards_number1 = $send_cardnum;
            foreach ($user_cards_number1 as $card)
            {
                $number = preg_replace('/\D/', '', $card);
                $saved_card_num = sadad_woo_get_bank_card_num($number, $start, $end);
                if (intval($cart_no) == intval($saved_card_num))
                {
                    $res = true;
                    break;
                }
            }
        }
        if ($res != true)
        {
            $user_cards = get_user_meta($user_id, 'billing_cards_number', true);
            if (!empty($user_cards))
            {
                $user_cards_number1 = json_decode($user_cards);
                foreach ($user_cards_number1 as $card)
                {
                    $number = preg_replace('/\D/', '', $card->value);
                    $saved_card_num = sadad_woo_get_bank_card_num($number, $start, $end);
                    if (intval($cart_no) == intval($saved_card_num))
                    {
                        $res = true;
                        break;
                    }
                }
            }
        }
        return $res;
    }

}
if (!function_exists('sadadWooFormatCreditCard'))
{

    function sadadWooFormatCreditCard($cc)
    {
        $cc_length = strlen($cc);
        $newCreditCard = substr($cc, -4);
        for ($i = $cc_length - 5; $i >= 0; $i--)
        {
            if ((($i + 1) - $cc_length) % 4 == 0)
            {
                $newCreditCard = '-' . $newCreditCard;
            }
            $newCreditCard = $cc[$i] . $newCreditCard;
        }

        return $newCreditCard;
    }

}
if (!function_exists('sadadWooFormatCreditCard2'))
{

    function sadadWooFormatCreditCard2($cc)
    {
        $cc = preg_replace('/\D/', '', $cc);
        $cc_length = strlen($cc);

        $newCreditCard = substr($cc, -4);

        for ($i = $cc_length - 5; $i >= 0; $i--)
        {
            if ((($i + 1) - $cc_length) % 4 == 0)
            {
                $newCreditCard = '-' . $newCreditCard;
            }
            $newCreditCard = $cc[$i] . $newCreditCard;
        }
        for ($i = 10; $i < $cc_length - 2; $i++)
        {
            if ($newCreditCard[$i] == '-')
            {
                continue;
            }
            $newCreditCard[$i] = 'X';
        }


        return $newCreditCard;
    }

}

if (has_action('woocommerce_admin_order_data_after_billing_address', 'ham3da_wc_admin_od_detailes_def') === false)
{
    add_action('woocommerce_admin_order_data_after_billing_address', 'ham3da_wc_admin_od_detailes_def', 10, 1);
}

if (!function_exists('ham3da_wc_admin_od_detailes_def'))
{

    function ham3da_wc_admin_od_detailes_def($order)
    {
        $order = wc_get_order($order->get_id());
        $billing_card_number = $order->get_meta('_billing_card_number');
        if (!empty($billing_card_number))
        {
            echo
            '<div class="card-detailes">'
            . '<p><strong>' . __('شماره کارت بانکی انتخاب شده') . ':</strong> ' . sadadWooFormatCreditCard($billing_card_number) . '</p>'
            . '</div>';
        }

        
        $PrimaryAccNo = $order->get_meta('PrimaryAccNo', true);  
        if (!empty($PrimaryAccNo))
        {
            echo
            '<div class="card-detailes">'
            . '<p><strong>' . __('شماره کارت پرداختی') . ':</strong> <span dir="ltr">' . sadadWooFormatCreditCard($PrimaryAccNo) . '</span></p>'
            . '</div>';
        }

        $status_card = $order->get_meta('PrimaryAccNoStatus', true);  
                
        if (!is_null($status_card) && $status_card != "")
        {
            $status_text = (intval($status_card) == 1 ) ? 'پرداخت با کارت مجاز' : 'پرداخت با کارت غیرمجاز';
            echo
            '<div class="card-detailes">'
            . '<p><strong>' . __('وضعیت پرداخت') . ':</strong>' . $status_text . '</p>'
            . '</div>';
        }
    }

}

if (has_filter('manage_users_columns', 'ham3da_card_number_user_table') === false)
{
    add_filter('manage_users_columns', 'ham3da_card_number_user_table');
}
if (!function_exists('ham3da_card_number_user_table'))
{

    function ham3da_card_number_user_table($column)
    {
        $column['card_status'] = 'شماره کارت';
        return $column;
    }

}

if (!function_exists('ham3da_card_number_user_table_row'))
{

    function ham3da_card_number_user_table_row($val, $column_name, $user_id)
    {
        if ($column_name == 'card_status')
        {
            $user_cards_number = array();
            $send_cardnum1 = get_post_meta($user_id, '_send_cardnum', true);
            $send_cardnumo = get_post_meta($user_id, '_send_cardnumo', true);
            $send_cardnumt = get_post_meta($user_id, '_send_cardnumt', true);

            $send_cardnum = array();
            if (!empty($send_cardnum1))
            {
                $send_cardnum[] = $send_cardnum1;
            }

            if (!empty($send_cardnumo))
            {
                $send_cardnum[] = $send_cardnumo;
            }

            if (!empty($send_cardnumt))
            {
                $send_cardnum[] = $send_cardnumt;
            }


            if (!empty($send_cardnum))
            {
                $user_cards_number1 = $send_cardnum;
                foreach ($user_cards_number1 as $card)
                {
                    $number = preg_replace('/\D/', '', $card->value);
                    $user_cards_number[$number] = sadadWooFormatCreditCard($number);
                }
            }

            $user_cards = get_user_meta($user_id, 'billing_cards_number', true);
            if (!empty($user_cards))
            {
                $user_cards_number1 = json_decode($user_cards);
                foreach ($user_cards_number1 as $card)
                {
                    $number = preg_replace('/\D/', '', $card->value);
                    $user_cards_number[$number] = sadadWooFormatCreditCard($number);
                }
            }

            $value = implode('<br>', $user_cards_number);
            return $value;
        }
        return $val;
    }

}

if (has_filter('manage_users_custom_column', 'ham3da_card_number_user_table_row') === false)
{
    add_filter('manage_users_custom_column', 'ham3da_card_number_user_table_row', 10, 3);
}
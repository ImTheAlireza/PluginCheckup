<nav class="nav-tab-wrapper">
    <div class="wrap wcpl_export_users">

        <?php
        $active_state = Sadad_License::check_activation();
        if ($active_state) {
            ?>

            <form>
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label><?php _e('Status', 'sadad_woo') ?>:</label>
                            </th>
                            <td style="color: green">
                                <?php _e('Congratulations! This plugin is active.', 'sadad_woo') ?>

                            </td>
                        </tr>
                </table>

                <div class="btn_div">
                    <button type="button" class="button-primary"><a style="color: white; text-decoration: unset;" href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout&section=WC_BankMelli_New'); ?>"><?= __('Gateway settings', 'sadad_woo'); ?></a></button>
                </div>
                <hr>
                <p class="version">
                    <?php printf(__('Version: %s', 'sadad_woo'), SADAD_VER) ?>
                </p>

            </form>
            <?php
        } else {
            ?>
            <script type="text/javascript">
                var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                function dis_submitForm()
                {
                    return false;
                }
                function submit_any_form(form_id)
                {
                    var form_pay = jQuery('#' + form_id);


                    var user_licence = form_pay.find('#user_licence').val();

                    var my_action = form_pay.find('#action').val();

                    var send_data = {action: my_action, user_licence: user_licence};
                    try
                    {
                        var postData = send_data;
                        var form_pay = jQuery('#' + form_id);

                        form_pay.find('#loading_pb').show();
                        jQuery('#red_dialog').hide(200);

                        var request = jQuery.ajax({method: "POST", data: postData, dataType: "json", url: ajax_url});
                        request.done(function (response)
                        {
                            form_pay.find('#loading_pb').hide(200);
                            if (response)
                            {
                                var res = response.res;
                                if (res === true)
                                {
                                    jQuery("#red_dialog").html('فعالسازی افزونه با موفقیت انجام شد. <br/> با تشکر از خرید شما');
                                    jQuery('#red_dialog').css('color', 'green');
                                    jQuery('#red_dialog').show(200);
                                    window.location.reload();

                                } else
                                {
                                    console.log("jqXHR = %o", response);
                                    jQuery('#red_dialog').html('خطا: ' + response.msg);
                                    jQuery('#red_dialog').css('color', 'red');
                                    jQuery('#red_dialog').show(300);
                                }

                            } else
                            {

                                jQuery("#red_dialog").html('خطا: درخواست با شکست مواجه شد!');
                                jQuery('#red_dialog').css('color', 'red');
                                jQuery('#red_dialog').show(300);
                                console.log("jqXHR = %o", response);
                            }
                        });
                        request.fail(function (jqXHR, textStatus, errorThrown)
                        {
                            form_pay.find('#loading_pb').hide(200);
                            console.log("jqXHR = %o", jqXHR);
                            console.log("textStatus = %o", textStatus);
                            console.log("errorThrown = %o", errorThrown);
                            jQuery('#red_dialog').html('خطا: درخواست با شکست مواجه شد!<br/>' + errorThrown);
                            jQuery('#red_dialog').css('color', 'red');
                            jQuery('#red_dialog').show(300);

                            return;
                        });
                    } catch (err)
                    {
                        alert(err.message);
                    }
                }
                jQuery(document).ready(function ($)
                {
                    $('#sadad_submit').click(function ()
                    {

                        if ($('#user_licence').val().length >= 1)
                        {
                            submit_any_form('reg_sadad_form');
                        } else
                        {
                            $('#red_dialog').html('لطفاً کد فعالسازی را وارد نمایید!');
                            $('#red_dialog').css('color', 'red');
                            $('#red_dialog').show(300);
                        }
                    });
                });

            </script>


            <form id="reg_sadad_form" method="post" onsubmit="return dis_submitForm()">
                <input type="hidden" name="action" id="action" value="sadad_woo_check_register" />
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label><?php _e('Status', 'sadad_woo') ?>:</label>
                        </th>
                        <td>
                            <span style="color:red;">
                                <?php _e('This plugin requires a license to use it.', 'sadad_woo'); ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="user_licence">کد لایسنس:</label></th>
                        <td>
                            <input class="regular-text code" type="text" id="user_licence" name="user_licence" />
                            <p>
                                این کد هنگام خرید محصول از فروشگاه <a href="https://www.zhaket.com/web/sadad-woocommerce">ژاکت</a> به سفارش شما اختصاص داده شده است.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <p style="display: none;" id="red_dialog"></p>  
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>
                            <button type="submit" name="sadad_submit" id="sadad_submit" class="button button-primary"> <?php _e('Register', 'sadad_woo'); ?></button>&nbsp;
                            <img id="loading_pb" style="width: 28px; display: none;" src="<?php echo admin_url('images/spinner-2x.gif') ?>" />
                        </td>
                    </tr>
                </table>
                <hr>
                <p class="version">
                    <?php printf(__('Version: %s', 'sadad_woo'), SADAD_VER) ?>
                </p>
            </form>


            <?php
        }
        ?>
    </div>
</nav>
<?php
class WC_BankMelli_New extends WC_Payment_Gateway
{

    private $cancelled_massage, $failed_massage, $success_massage,
        $merchant, $terminal, $TerminalKey, $PaymentIdentity;
    public $ssl_version, $check_card, $send_phone, $author, $pay_btn_text;

    public static function add_gateway()
    {
        add_filter('woocommerce_payment_gateways', function ($methods) {
            if (!isset($methods['WC_BankMelli_New'])) {
                $methods[] = 'WC_BankMelli_New';
            }
            return $methods;
        });
    }

    public static function loadLibrary()
    {
        $settings = get_option('woocommerce_' . SADAD_WOO_ID . '_settings');

        $check_card = isset($settings['check_card']) ? $settings['check_card'] : 'no';
        $ham3daWooPaymentUtility = new ham3daWooPaymentUtility(SADAD_WOO_ID, $check_card);
        $ham3daWooPaymentUtility->init();
    }

    public function __construct()
    {

        $this->supports = array('products');
        $this->author = 'ham3da.ir';
        $this->id = SADAD_WOO_ID;
        $this->method_title = __('Sadad', 'sadad_woo');
        $this->method_description = __('Sadad redirects customers to Shaparak for payment.', 'sadad_woo');

        $this->has_fields = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->icon = apply_filters('WC_BankMelli_New_logo', SADAD_WOO_URL . 'assets/images/logo.png');

        $this->title = $this->get_option('title', '');
        $this->description = $this->get_option('description', '');
        $this->merchant = $this->get_option('merchant', '');
        $this->terminal = $this->get_option('terminal', '');
        $this->TerminalKey = $this->get_option('TerminalKey', '');
        $this->PaymentIdentity = $this->get_option('PaymentIdentity', '');
        $this->send_phone = $this->get_option('send_phone', 'no');
        $this->check_card = $this->get_option('check_card', 'no');
        $this->success_massage = $this->get_option('success_massage', '');
        $this->failed_massage = $this->get_option('failed_massage', '');
        $this->cancelled_massage = $this->get_option('cancelled_massage', '');
        $this->ssl_version = $this->get_option('ssl_version', 'default');

        $this->pay_btn_text = $this->get_option('pay_btn_text', __("Proceed to Sadad", "sadad_woo"));

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

        //add_action('woocommerce_receipt_' . $this->id . '', array($this, 'rquest_payment'));
        add_action('woocommerce_api_' . strtolower(get_class($this)) . '', array($this, 'verify_payment'));
    }



    function get_ico_url()
    {

        $icon = $this->get_option('sadad_logo', null);
        $url = SADAD_WOO_URL . 'assets/images/logo.png';
        if (!empty($icon)) {
            $url = $icon;
        }
        return $url;
    }

    public function admin_options()
    {
        parent::admin_options();
    }

    public function init_form_fields()
    {
        $active_state = Sadad_License::check_activation();
        $icon = $this->get_ico_url();
        $callback_url = '';
        if ( function_exists('WC') ) {
            $callback_url = esc_url( WC()->api_request_url('WC_BankMelli_New') );
        }

        if ($active_state) {

            $this->form_fields = apply_filters(
                'WC_BankMelli_New_Config',
                array(
                    'base_confing' => array(
                        'title' => __('Sadad settings', 'sadad_woo'),
                        'type' => 'title',
                        'description' => '',
                    ),
                    'enabled' => array(
                        'title' => __('Enable/Disable', 'sadad_woo'),
                        'type' => 'checkbox',
                        'label' => __('Enable Sadad payment method', 'sadad_woo'),
                        'default' => 'yes',
                    ),
                    'title' => array(
                        'title' => __('Title', 'sadad_woo'),
                        'type' => 'text',
                        'description' => __('This controls the title which the user sees during checkout.', 'sadad_woo'),
                        'default' => __('Sadad', 'sadad_woo'),
                        'desc_tip' => true,
                    ),
                    'description' => array(
                        'title' => __('Description', 'sadad_woo'),
                        'type' => 'text',
                        'desc_tip' => true,
                        'description' => __('This controls the description which the user sees during checkout.', 'sadad_woo'),
                        'default' => __('Secure payment with Sadad payment gateway', 'sadad_woo'),
                    ),
                    'merchant' => array(
                        'title' => __('Merchant code', 'sadad_woo'),
                        'type' => 'text',
                        'description' => 'این شماره توسط شرکت داده‌ورزی سداد برای شما ایمیل شده است',
                        'default' => '',
                        'desc_tip' => true
                    ),
                    'terminal' => array(
                        'title' => __('Terminal code', 'sadad_woo'),
                        'type' => 'text',
                        'description' => 'این شماره توسط شرکت داده‌ورزی سداد برای شما ایمیل شده است',
                        'default' => '',
                        'desc_tip' => true
                    ),
                    'TerminalKey' => array(
                        'title' => __('Transaction Key', 'sadad_woo'),
                        'type' => 'password',
                        'description' => 'کلید تراکنش توسط شرکت داده‌ورزی سداد برای شما ایمیل شده است(باید به صورت base64 کدنگاری شده باشد)',
                        'default' => '',
                        'desc_tip' => true
                    ),
                    'PaymentIdentity' => array(
                        'title' => __('Nasim Payment ID', 'sadad_woo'),
                        'type' => 'text',
                        'description' => 'این مورد مختص شرکتها و سازمانهایی می‌باشد که دارای شناسه پرداخت 30 رقمی هستند.',
                        'default' => '',
                        'desc_tip' => false
                    ),
                    'payment_confing' => array(
                        'title' => 'تنظیمات عملیات پرداخت',
                        'type' => 'title',
                        'description' => '',
                    ),
                    'return_url' => array(
                        'title' => __('Return / Callback URL', 'sadad_woo'),
                        'type' => 'title',
                        'description' => '<code>' .$callback_url.'</code>',
                        'desc_tip' => false,
                    ),
                    'send_phone' => array(
                        'title' => __('Sync with mobile', 'sadad_woo'),
                        'type' => 'checkbox',
                        'label' => __('Sync with mobile', 'sadad_woo'),
                        'description' => __('Send mobile number to gateway to save card number', 'sadad_woo'),
                        'default' => 'no',
                        'desc_tip' => false,
                    ),
                    'ssl_version' => array(
                        'type' => 'select',
                        'title' => __('Ciphers to use for SSL', 'sadad_woo'),
                        'description' => __('Choose the encryption method compatible with your host.', 'sadad_woo'),
                        'options' => array(
                            'default' => __('Default', 'sadad_woo'),
                            'TLSv1' => 'TLSv1-3',
                            'RC4-SHA' => 'RC4-SHA',
                            'SHA1+DES' => 'SHA1+DES'
                        ),
                        'default' => 'default',
                    ),
                    'check_card' => array(
                        'title' => __('Check card number', 'sadad_woo'),
                        'type' => 'checkbox',
                        'label' => __('Enable', 'sadad_woo'),
                        'description' => __('‌If this option is enabled, the user can only buy with the cards defined by the site administrator in user profile, and if user pays with other cards, user order will be checked.', 'sadad_woo'),
                        'default' => 'no',
                        'desc_tip' => false,
                    ),
                    'pay_btn_text' => array(
                        'title' => __('Order button text', 'sadad_woo'),
                        'type' => 'text',
                        'default' => __('Proceed to Sadad', 'sadad_woo'),
                        'desc_tip' => true,
                    ),
                    'sadad_logo' => array(
                        'title' => __('Gateway logo', 'sadad_woo'),
                        'type' => 'text',
                        'desc_tip' => false,
                        'description' => __('Logo URL', 'sadad_woo'),
                        'class' => 'code',
                        'default' => $icon,
                    ),
                    'success_massage' => array(
                        'title' => __('Successful payment message', 'sadad_woo'),
                        'type' => 'textarea',
                        'description' => 'متن پیامی که میخواهید بعد از پرداخت موفق به کاربر نمایش دهید را وارد نمایید.
                                            همچنین می توانید از شورت کدهای زیر استفاده کنید:<br/>
                                            <strong>%Transaction_id%</strong> : شماره پیگیری<br/>
                                            <strong>%Order_Number%</strong> : شماره سفارش<br/>
                                            <strong>%RefNum%</strong> : شماره مرجع تراکنش',
                        'default' => 'با تشکر از شما. سفارش شما با موفقیت پرداخت شد.',
                    ),
                    'failed_massage' => array(
                        'title' => __('Unsuccessful payment message', 'sadad_woo'),
                        'type' => 'textarea',
                        'description' => 'متن پیامی که میخواهید بعد از پرداخت ناموفق به کاربر نمایش دهید را وارد نمایید . همچنین می توانید از شورت کد %fault% برای نمایش دلیل خطای رخ داده استفاده نمایید . این دلیل خطا از سایت سداد ارسال میگردد .',
                        'default' => 'پرداخت با شکست مواجه شد. %fault%',
                    ),
                    'cancelled_massage' => array(
                        'title' => __('Canceled payment message', 'sadad_woo'),
                        'type' => 'textarea',
                        'description' => 'متن پیامی که میخواهید بعد از انصراف کاربر از پرداخت نمایش دهید را وارد نمایید . این پیام بعد از بازگشت از بانک نمایش داده خواهد شد.',
                        'default' => 'پرداخت به دلیل انصراف شما ناتمام باقی ماند.',
                    ),
                )
            );
        }
    }

    public function process_payment($order_id)
    {

        $order = wc_get_order($order_id);
        $BMI_Fault = new BMI_Fault();
        $currency = $order->get_currency();
        $Amount = $this->calc_amount($order->get_total(), $currency);
        $merchantId = $this->merchant;
        $terminal = $this->terminal;
        $userkey = $this->TerminalKey;

        $orderId = time() + intval($order_id);
        $callBackUrl = WC()->api_request_url('WC_BankMelli_New');
        $is_error = 'no';
        $date_time = date("Y-m-d\TH:i:s");
        $SignData = sprintf('%s;%s;%s', $terminal, $orderId, $Amount);

        $payment_page = "https://sadad.shaparak.ir/VPG/Purchase";

        $AdditionalData = json_encode(array('oid' => $orderId, 'Amount' => $Amount));

        $phone = $order->get_billing_phone();

        $SourcePanList = array();
        if ($this->check_card == 'yes') {
            $card = $order->get_meta('_billing_card_number');
            if (!$card) {
                $billing_card_number = preg_replace('/[^0-9]/', '', $card);
                if ($billing_card_number) {
                    $SourcePanList[] = array('SourcePan' =>  $this->encrypt_tripledes($billing_card_number, base64_decode($userkey)), 'IsDefault' => true);
                }
            }

        }


        if (!empty($this->PaymentIdentity)) {
            $url = 'https://sadad.shaparak.ir/api/v0/PaymentByIdentity/PaymentRequest';
            $post = array(
                'MerchantId' => $merchantId,
                'TerminalId' => $terminal,
                'Amount' => $Amount,
                'OrderId' => $orderId,
                'LocalDateTime' => $date_time,
                'ReturnUrl' => $callBackUrl,
                'SignData' => $this->encrypt_tripledes($SignData, base64_decode($userkey)),
                'PaymentIdentity' => $this->PaymentIdentity,
            );
        } else {
            $url = 'https://sadad.shaparak.ir/VPG/api/v0/Request/PaymentRequest';
            $post = array(
                'MerchantId' => $merchantId,
                'TerminalId' => $terminal,
                'Amount' => $Amount,
                'OrderId' => $orderId,
                'LocalDateTime' => $date_time,
                'ReturnUrl' => $callBackUrl,
                'SignData' => $this->encrypt_tripledes($SignData, base64_decode($userkey)),
                'AdditionalData' => $AdditionalData,
            );
        }

        if (!empty($SourcePanList)) {
            $post['SourcePanList'] = $SourcePanList;
        }

        if ($this->send_phone == 'yes' && WC_Validation::is_phone($phone)) {
            $post["UserId"] = $phone;
        }

        $referer = get_site_url();
        $data_string = json_encode($post);
        $Result = bmi_new_post_data($url, $data_string, $this->ssl_version, $referer);

        $PayResult_JSON = $Result['res'];
        $post_err = $Result['err'];
        $http_code = $Result['http_code'] ?? null;

        if (isset($PayResult_JSON->ResCode) && $PayResult_JSON->ResCode == 0) {

            $order->update_meta_data('WC_BankMelli_req', $PayResult_JSON->Token);
            $order->update_meta_data('WC_BankMelli_OID', $orderId);

            set_transient('wc_bmih_oid_' . $orderId, $order_id, DAY_IN_SECONDS);

            $order->add_order_note('کاربر به درگاه هدایت شد. <br> Token: ' . $PayResult_JSON->Token . ' | order_id: ' . $orderId);

            $order->save();

            $payment_page_url = add_query_arg('Token', $PayResult_JSON->Token, $payment_page);
            return array(
                'result' => 'success',
                'redirect' =>  $payment_page_url
            );
        } else {

            //$order->add_order_note(print_r( $Result , true));
            //$order->save();
            
            $err = "";
            $fault = "-";

            if (isset($PayResult_JSON->ResCode)) {
                $fault = $PayResult_JSON->ResCode;
                //$err = $BMI_Fault->Fault_BankMelli_request($fault);

                if (isset($PayResult_JSON->Description)) {
                    $err = $PayResult_JSON->Description;
                    $order->add_order_note('خطای درگاه: ' . $err . '<br>ResCode: ' . $fault);
                    $order->save();
                }
            } else {
                $err = $post_err;
                $order->add_order_note('خطا در اتصال به درگاه پرداخت: ' . $err . '<br>http_code : ' . $http_code);
                $order->save();
            }


            $Notice = sprintf('در هنگام اتصال به درگاه بانکی خطای زیر رخ داده است: %s', '<br>' . $err);
            if ($Notice) {
                wc_add_notice($Notice, 'error');
            }

            return array(
                'result' => 'fail',
                'redirect' => '',
                'errorMessage' => $Notice,
            );
        }
    }

    //خطاهای بانکی
    //Go TO URL 
    private static function go_to_url($url)
    {

        die('<script type="text/javascript">
                    location = "' . $url . '";
                    </script>');
    }

    private static function encrypt_tripledes($data, $secret)
    {
        $method = 'DES-EDE3';
        $encrypted = openssl_encrypt($data, $method, $secret, 0);
        return $encrypted;
    }

    public function calc_amount($Amount, $currency)
    {
        $currency2 = strtoupper($currency);
        if ($currency2 == 'IRT') {
            $Amount = $Amount * 10;
        } elseif ($currency2 == 'IRHT') {
            $Amount = $Amount * 1000 * 10;
        } elseif ($currency2 == 'IRHR') {
            $Amount = $Amount * 1000;
        } elseif ($currency2 == 'IRR') {
            $Amount = $Amount * 1;
        }
        return $Amount;
    }

    //بازگشت از بانک و بررسی تراکنش
    public function verify_payment()
    {

        $BMI_Fault = new BMI_Fault();
        $order_id = null;
        $order = null;
        $check_card_res = true;
        $postedOrderId = null;

        // Prefer OrderId from POST (gateway verify), find related WC order by meta WC_BankMelli_OID
        if (isset($_POST['OrderId']) && !empty($_POST['OrderId'])) {
            $postedOrderId = sanitize_text_field($_POST['OrderId']);
            $order_id = get_transient('wc_bmih_oid_' . $postedOrderId);
            $order = $order_id ? wc_get_order($order_id) : null;
        }

        if ($order) {
            $currency = $order->get_currency();
            if (!$order->is_paid()) {

                $Amount = $this->calc_amount($order->get_total(), $currency);

                $userkey = $this->TerminalKey;
                //------
                $do_publish = false;
                $TraceNo = 0;
                //check for cancels
                $token_key = $order->get_meta('WC_BankMelli_req', true);
                $SaleOrderId = !empty($postedOrderId) ? $postedOrderId : '0';
                if (isset($_POST['ResCode']) && $_POST['ResCode'] == 0) {
                    $post = array(
                        'Token' => $token_key,
                        'SignData' => $this->encrypt_tripledes($token_key, base64_decode($userkey))
                    );

                    $data_string = json_encode($post);
                    $url = 'https://sadad.shaparak.ir/VPG/api/v0/Advice/Verify';

                    $Result = bmi_new_post_data($url, $data_string, $this->ssl_version);
                    //file_put_contents(ABSPATH."bmi-v-res.txt", print_r($Result, true));

                    $VerifyResult_J = $Result['res'];
                    $post_err = $Result['err'];
                    $PrimaryAccNo = "";

                    if (isset($VerifyResult_J->ResCode) && $VerifyResult_J->ResCode == 0) {

                            $RefNo = $VerifyResult_J->RetrivalRefNo;
                            $TraceNo = $VerifyResult_J->SystemTraceNo;

                            $PrimaryAccNo = $_POST['PrimaryAccNo'] ?? '';

                            $order->update_meta_data($order_id, 'PrimaryAccNo', $PrimaryAccNo);
                            $order->update_meta_data($order_id, 'WC_BankMelli_TRACENO', $TraceNo);
                            $order->update_meta_data($order_id, 'WC_BankMelli_RefNum', $RefNo);
                            $order->update_meta_data($order_id, 'info_sadad', print_r($VerifyResult_J, true));
                        $do_publish = true;
                        //واریز شد
                    } else {
                        $do_publish = false;
                    }

                    $transaction_id = isset($VerifyResult_J->SystemTraceNo) ? $VerifyResult_J->SystemTraceNo : "0";
                    $fault = isset($VerifyResult_J->ResCode) ? $VerifyResult_J->ResCode : -2;

                    if ($do_publish == true) {
                        $fault = $VerifyResult_J->ResCode;
                        $err_msg = $BMI_Fault->Fault_BankMelli_verify($fault);
                        $RefNo = $VerifyResult_J->RetrivalRefNo;
                        $AppStatusDescription = $VerifyResult_J->Description;

                        $TraceNo = $VerifyResult_J->SystemTraceNo;
                        $verify_amount = $VerifyResult_J->Amount;

                        if ($check_card_res) {
                            if ($verify_amount == $Amount) {
                                $order->payment_complete($TraceNo);
                                $Note = sprintf('پرداخت موفقیت آمیز بود. %s کد رهگیری (کد مرجع تراکنش): %s شماره درخواست تراکنش: %s', '<br/>', $transaction_id . '<br/>', $SaleOrderId . '<br/>');
                            } else {
                                $order->update_status('on-hold', 'در انتظار بررسی به دلیل مغایرت در مبلغ پرداختی.');
                                $order->set_transaction_id($TraceNo);
                                $Note = sprintf('پرداخت با موفقیت انجام شده است اما به دلیل مغایرت در مبلغ پرداختی، نیازمند بررسی و تایید می‌باشد. %s کد رهگیری (کد مرجع تراکنش): %s شماره درخواست تراکنش: %s', '<br/>', $transaction_id . '<br/>', $SaleOrderId . '<br/>');
                            }

                            update_post_meta($order_id, 'PrimaryAccNoStatus', '1');
                        } else {

                            $order->update_status('on-hold', 'در انتظار بررسی به دلیل پرداخت با کارت غیر مجاز.');
                            update_post_meta($order_id, 'PrimaryAccNoStatus', '0');
                            $Note = sprintf('پرداخت با موفقیت انجام شده است اما به دلیل مغایرت شماره کارت پرداختی، نیازمند بررسی و تایید می‌باشد. %s کد رهگیری (کد مرجع تراکنش): %s شماره درخواست تراکنش: %s', '<br/>', $transaction_id . '<br/>', $SaleOrderId . '<br/>');
                            if ($TraceNo && $TraceNo != 0) {
                                $order->set_transaction_id($TraceNo);
                            }
                        }




                        $Note = apply_filters('WC_BankMelli_New_Return_from_Gateway_Success_Note', $Note, $order_id, $transaction_id, $SaleOrderId);
                        if ($Note) {
                            $order->add_order_note($Note, 1);
                        }

                        $order->save();

                        $Notice = wpautop(wptexturize($this->success_massage));

                        $Notice = str_replace("%Transaction_id%", $transaction_id, $Notice);
                        $Notice = str_replace("%Order_Number%", $SaleOrderId, $Notice);
                        $Notice = str_replace("%RefNum%", $RefNo, $Notice);

                        $Notice = apply_filters('WC_BankMelli_New_Return_from_Gateway_Success_Notice', $Notice, $order_id, $transaction_id, $SaleOrderId);
                        if ($Notice) {
                            if ($check_card_res) {
                                wc_add_notice($Notice, 'success');
                            } else {
                                $Notice = sprintf('پرداخت شما با موفقیت انجام شده است اما به دلیل مغایرت شماره کارت پرداختی سفارش شما نیازمند بررسی و تایید می‌باشد. %s کد رهگیری (کد مرجع تراکنش): %s شماره درخواست تراکنش: %s شماره کارت پرداختی: %s ', '<br/>', $transaction_id . '<br/>', $SaleOrderId . '<br/>', $PrimaryAccNo);
                                wc_add_notice($Notice, 'notice');
                            }
                        }

                        //wc_empty_cart();
                        // do_action('WC_BankMelli_New_Return_from_Gateway_Success', $order_id, $transaction_id, $SaleOrderId);

                        if ($check_card_res) {
                            wp_redirect(add_query_arg('WC_status', 'success', $this->get_return_url($order)));
                        } else {
                            wp_redirect(add_query_arg('WC_status', 'on-hold', $this->get_return_url($order)));
                        }
                        exit();
                    } else {
                        $err = "";
                        if (empty($VerifyResult_J)) {
                            $err = '<pre>' . $post_err . '</pre>';
                            $order->add_order_note('gateway verify error: ' . print_r($err, true));
                        } else {
                            if (is_object($VerifyResult_J)) {
                                $fault = $VerifyResult_J->ResCode;
                            } else {
                                $fault = -2;
                                $order->add_order_note('Result verify: ' . print_r($VerifyResult_J, true));
                            }
                            $err = $BMI_Fault->Fault_BankMelli_verify($fault);
                        }

                        $tr_id = ($transaction_id && $transaction_id != "0") ? ('<br/>کد رهگیری (کد مرجع تراکنش): ' . $transaction_id) : '';
                        $sale_order_id = ($SaleOrderId && $SaleOrderId != "0") ? ('<br/>شماره درخواست تراکنش: ' . $SaleOrderId) : '';

                        $Note = sprintf('خطا هنگام بازگشت از درگاه بانکی : %s %s %s', $err, $tr_id, $sale_order_id);
                        $Note = apply_filters('WC_BankMelli_New_Return_from_Gateway_Failed_Note', $Note, $order_id, $transaction_id, $SaleOrderId, $fault);
                        if ($Note) {
                            $order->add_order_note($Note, 1);
                        }

                        $Notice = wpautop(wptexturize($this->failed_massage));
                        $Notice = str_replace("%Transaction_id%", $transaction_id, $Notice);
                        $Notice = str_replace("%Order_Number%", $SaleOrderId, $Notice);
                        $Notice = str_replace("%RefNo%", $RefNo, $Notice);

                        $Notice = str_replace("%fault%", $err, $Notice);
                        $Notice = apply_filters('WC_BankMelli_New_Return_from_Gateway_Failed_Notice', $Notice, $order_id, $transaction_id, $SaleOrderId, $fault);
                        if ($Notice) {
                            wc_add_notice($Notice, 'error');
                            $Rev_Note = sprintf('تراکنش ناموفق بود.%s اگر وجهی از حساب شما کسر شده باشد، تا پایان روز جاری به حساب شما باز خواهد گشت.', '<br />');
                            $order->add_order_note($Rev_Note, 1);
                        }


                        $order->save();
                        do_action('WC_BankMelli_New_Return_from_Gateway_Failed', $order_id, $transaction_id, $SaleOrderId, $fault);
                        wp_redirect(wc_get_checkout_url());
                        exit();
                    }
                } else {
                    $sale_order_id = '<br/>شماره درخواست تراکنش: ' . $SaleOrderId;
                    $transaction_id = "";
                    $Note = sprintf('تراکنش ناموفق بود. %s', $sale_order_id);
                    $Note = apply_filters('WC_BankMelli_New_Return_from_Gateway_Cancelled_Note', $Note, $order_id, $transaction_id, $SaleOrderId);
                    if ($Note) {
                        $order->add_order_note($Note, 1);
                        $order->save();
                    }

                    $Notice = wpautop(wptexturize($this->cancelled_massage));
                    $Notice = str_replace("%Order_Number%", $SaleOrderId, $Notice);

                    $Notice = apply_filters('WC_BankMelli_New_Return_from_Gateway_Cancelled_Notice', $Notice, $order_id, $transaction_id, $SaleOrderId);
                    if ($Notice) {
                        wc_add_notice($Notice, 'error');
                    }
                    do_action('WC_BankMelli_New_Return_from_Gateway_Cancelled', $order_id, $transaction_id, $SaleOrderId);

                    wp_redirect(wc_get_checkout_url());
                    exit();
                }
            } else {

                $transaction_id = $order->get_transaction_id();
                $RefNo = $order->get_meta('WC_BankMelli_RefNum', true);
                $SaleOrderId = $order->get_meta('WC_BankMelli_OID', true);

                if (isset($Notice)) {
                    unset($Notice);
                }
                $Notice = wpautop(wptexturize($this->success_massage));

                $Notice = str_replace("%Transaction_id%", $transaction_id, $Notice);
                $Notice = str_replace("%Order_Number%", $SaleOrderId, $Notice);
                $Notice = str_replace("%RefNo%", $RefNo, $Notice);

                $Notice = apply_filters('WC_BankMelli_New_Return_from_Gateway_ReSuccess_Notice', $Notice, $order_id, $transaction_id, $SaleOrderId);
                if ($Notice) {
                    wc_add_notice($Notice, 'success');
                    $order->add_order_note($Notice, 0);
                    $order->save();
                }
                do_action('WC_BankMelli_New_Return_from_Gateway_ReSuccess', $order_id, $transaction_id, $SaleOrderId);

                wp_redirect(add_query_arg('WC_status', 'success', $this->get_return_url($order)));
                exit();
            }
        } else {
            $transaction_id = "";
            $fault = 'شماره سفارش وجود ندارد .';

            $Notice = wpautop(wptexturize($this->failed_massage));
            $Notice = str_replace("%fault%", $fault, $Notice);

            $Notice = apply_filters('WC_BankMelli_New_Return_from_Gateway_No_Order_ID_Notice', $Notice, $order_id, $fault);
            if ($Notice) {
                wc_add_notice($Notice, 'error');
            }

            do_action('WC_BankMelli_New_Return_from_Gateway_No_Order_ID', $order_id, $transaction_id, $fault);

            wp_redirect(wc_get_checkout_url());
            exit();
        }
    }
}
<?php

class Sadad_License
{

    // Constructor of Zhaket License class
    public function __construct() {}

    public static function init($file)
    {
        add_action('sadad_woo_chk_validate', [__CLASS__, 'do_validate_daily']);
        add_action('admin_init', [__CLASS__, 'do_check_validate']);
        add_action('wp_ajax_sadad_woo_check_register', [__CLASS__, 'ajax_register_plugin']);

        register_activation_hook($file, [__CLASS__, 'on_activation']);
        register_deactivation_hook($file, [__CLASS__, 'on_deactivation']);
    }

    public static function check_activation()
    {
        $active_state = get_option('ham3da_sadad_woo_active', '0');
        if (intval($active_state) === 1 || SDD_HAM3DA === 1) {
            return true;
        } else {
            return false;
        }
    }

    public static function on_deactivation()
    {
        wp_clear_scheduled_hook('sadad_woo_chk_validate');
    }

    public static function on_activation()
    {
        if (!wp_next_scheduled('sadad_woo_chk_validate')) {
            wp_schedule_event(time(), 'daily', 'sadad_woo_chk_validate');
        }
    }

    public static function ajax_register_plugin()
    {
        $user_licence = isset($_POST['user_licence']) ? sanitize_text_field($_POST['user_licence']) : null;
        if ($user_licence != null) {
            $res = self::install_validate($user_licence);
            die(json_encode($res));
        }
    }

    /**
     *  Check licence from db
     */
    public static function do_check_validate()
    {
        $active_state = self::check_activation();
        if (!$active_state) {
            //note to user: Active your sadad plugin
            add_action('admin_notices', [__CLASS__, 'show_active_note']);
        }
    }

    public static function show_active_note()
    {
        $user = wp_get_current_user();

        $msg = sprintf(__('Hi %s, to Register sadad for Woocommerce payment gateway click %s.', 'sadad_woo'), $user->display_name, '<a href="' . admin_url('admin.php?page=sadad-wc-gate') . '">' . __('Here', 'sadad_woo') . '</a>');
        if (isset($_GET['page']) && $_GET['page'] == 'sadad-wc-gate') {
            //
        } else {
            echo sadad_admin_notice($msg, 'warning');
        }
    }

    /**
     * Register license and return result as array
     * @param string $license_token User License
     * @return array 'res' => boolean, 'msg'=> string
     */
    public static function install_validate($license_token)
    {
        $produc_token = base64_decode('Mjc4MTc5MzEtMzFlZi00NDMwLTg4ODgtYzdmNGFhYzI2MDE4'); // Your product token
        /*
          @param1 : license_token
          @param2 : product_token
          replace it with your own license token and product token :)
         */
        $result = self::install($license_token, $produc_token);

        if (!isset($result->status)) {
            return array('res' => false, 'msg' => 'خطا در دریافت وضعیت لایسنس!');
        }

        if ($result->status == 'successful') {
            //echo $result->message; // License installed successful
            update_option('ham3da_sadad_woo_license_token', base64_encode($license_token));
            update_option('ham3da_sadad_woo_active', '1');

            return array('res' => true, 'msg' => $result->message);
        } else {
            update_option('ham3da_sadad_woo_active', '0');

            // License not installed / show message
            if (!is_object($result->message)) {
                // License is Invalid
                //echo $result->message;
                return array('res' => false, 'msg' => $result->message);
            } else {
                $message_res = "";
                foreach ($result->message as $message) {
                    foreach ($message as $msg) {
                        $message_res .= $msg . '<br/>';
                    }
                }
                return array('res' => false, 'msg' => $message_res);
            }
        }
    }

    /**
     *  Check licence from Zhaket.com every day
     */
    public static function do_validate_daily()
    {
        $active_state = self::check_activation();
        if ($active_state && SDD_HAM3DA != 1) {
            //check licence online
            $LicenseisValid = self::LicenseisValid();
            if ($LicenseisValid === false) {
                update_option('ham3da_sadad_woo_active', '0');

                $admin_email = get_option('admin_email');
                $subject = "غیرفعال شدن درگاه سداد";

                $message = '<p dir="rtl">' . 'کاربر گرامی درگاه پرداخت سداد برای ووکامرس برروی سایت شما غیرفعال شده است.' . '</p>';
                $message .= '<p dir="rtl">' . 'این درگاه‌ به یکی از این دلایل زیر به صورت  خودکار غیرفعال می گردد:<br>1- انقضای لایسنس<br>2- بروز مشکل در اعتبار سنجی لایسنس. که در این صورت باید با ژاکت تماس حاصل فرمایید.' . '</p>';
                $site_url = get_site_url();
                $message .= '<p><a href="' . $site_url . '">' . $site_url . '</a></p>';
                $headers = array('Content-Type: text/html; charset=UTF-8');
                wp_mail($admin_email, $subject, $message, $headers);
            }
        }
    }

    /**
     * Check License is Valid or No
     * @return boolean|int if License is Valid return true else false and if error return 0
     */
    public static function LicenseisValid()
    {
        $license_token = get_option('ham3da_sadad_woo_license_token', '0'); // Your license token
        $result = self::isValid(base64_decode($license_token));
        if (isset($result->status)) {
            if ($result->status == 'successful') {
                return true;
            } else {
                // License not valid / show message
                if (!is_object($result->message)) {
                    // License is Invalid
                    return false;
                    //echo $result->message;
                } else {
                    return -1;
                }
            }
        } else {
            return -2;
        }
    }

    static $check_url = 'https://guard.zhaket.com/api/';

    //-------------------------------------------------
    // This method sends GET request to specific url and returns the result
    public static function sendRequest($method, $params = array())
    {
        $param_string = http_build_query($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt(
            $ch,
            CURLOPT_URL,
            self::$check_url . $method . '?' . $param_string
        );
        $content = curl_exec($ch);
        return json_decode($content);
    }

    //-------------------------------------------------
    public static function isValid($license_token)
    {
        $result = self::sendRequest('validation-license', array('token' => $license_token, 'domain' => self::getHost()));
        return $result;
    }

    //-------------------------------------------------
    public static function install($license_token, $product_token)
    {

        $result = self::sendRequest('install-license', array('product_token' => $product_token, 'token' => $license_token, 'domain' => self::getHost()));
        return $result;
    }

    //-------------------------------------------------
    public static function getHost()
    {
        $host = parse_url(get_site_url(), PHP_URL_HOST);
        $host = preg_replace('/:\d+$/', '', $host);
        $host = str_ireplace('www.', '', $host);
        return trim($host);
    }
}

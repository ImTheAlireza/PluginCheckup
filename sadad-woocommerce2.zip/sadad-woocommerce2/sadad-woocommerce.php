<?php
/*
  Plugin Name: WC Sadad Payment gateway
  Version: 5.1.0
  Description:  This plugin adds Sadad Payment gateway to WooCommerce.
  Plugin URI: https://www.zhaket.com/web/sadad-woocommerce
  Author: Javad Ehteshami
  Author URI: https://www.zhaket.com/store/web/ham3da
  WC requires at least: 6.9
  WC tested up to: 11.1.1
  Text Domain: sadad_woo
  Domain Path: lang
 */

if (!defined('ABSPATH')) {
    die('Access denied!');
}

define("SADAD_WOO_FILE", __FILE__);
define("SADAD_WOO_DIR", plugin_dir_path(__FILE__));
define("SADAD_WOO_URL", plugin_dir_url(__FILE__));
define("SADAD_WOO_ID", 'WC_BankMelli_New');
define("SADAD_VER", "5.0.0");

define("SDD_HAM3DA", 1);


add_action('init', function () {
    load_plugin_textdomain('sadad_woo', false, basename(dirname(__FILE__)) . '/lang');
}, 0);

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

if (!class_exists('Sadad_License')) {
    require_once( SADAD_WOO_DIR . 'inc/license.php' );
}

require_once( SADAD_WOO_DIR . 'inc/functions.php' );
require_once( SADAD_WOO_DIR . 'inc/card_functions.php' );
require_once( SADAD_WOO_DIR . 'inc/card_custom_feild.php' );

Sadad_License::init(__FILE__);

function load_bmi_new_gateway() {

    if (class_exists('WC_Payment_Gateway')) {
        require_once( SADAD_WOO_DIR . 'inc/gateway-class.php' );
    }

    if (!class_exists("BMI_Fault")) {
        require_once( plugin_dir_path(__FILE__) . 'inc/errors.php' );
    }

    if (class_exists('WC_BankMelli_New')) {
        WC_BankMelli_New::add_gateway();
        WC_BankMelli_New::loadLibrary();
    }
}

add_action('plugins_loaded', 'load_bmi_new_gateway');
add_action('admin_menu', 'sadad_woo_menu');

function sadad_woo_menu() {
    add_submenu_page('woocommerce', __('Sadad gateway', 'sadad_woo'), __('Sadad gateway', 'sadad_woo'),
            'activate_plugins', 'sadad-wc-gate', 'ham_sadad_activation_page');
}


add_action('plugins_loaded', 'sadad_woo_blocks_support');

function sadad_woo_blocks_support() {
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        add_action(
                'woocommerce_blocks_payment_method_type_registration',
                function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
                    require_once SADAD_WOO_DIR . 'inc/woo-block.php';
                    $payment_method_registry->register(new Sadad_WC_Payments_Block());
                }
        );
    }
}

function ham_sadad_activation_page() {
    $plugin_data = get_plugin_data(SADAD_WOO_FILE);

    $curr_tab = $_GET['tab'] ?? 'main';

    $main_params = array('page' => 'sadad-wc-gate', 'tab' => 'main');
    $products_params = array('page' => 'sadad-wc-gate', 'tab' => 'products');
    $tabs = array(
        'main' => ['url' => add_query_arg($main_params, admin_url('admin.php')), 'title' => __('License', 'sadad_woo')],
        'products' => ['url' => add_query_arg($products_params, admin_url('admin.php')), 'title' => __('More products', 'sadad_woo')],
    );
    ?>
    <div class="wrap">
        <h1><?php echo $plugin_data['Name'] ?></h1>
        <nav class="nav-tab-wrapper">
            <?php
            foreach ($tabs as $key => $tab_item) {
                ?>
                <a href="<?php echo esc_url($tab_item['url']) ?>" class="nav-tab <?php  echo(($curr_tab == $key) ? 'nav-tab-active' : '') ?>"><?php echo  $tab_item['title'] ?></a>
                <?php
            }
            ?>
        </nav>
        <?php
        if (file_exists(SADAD_WOO_DIR . "inc/tabs/$curr_tab.php")) {
            include SADAD_WOO_DIR . "inc/tabs/$curr_tab.php";
        }
        ?>
    </div>
    <?php
}
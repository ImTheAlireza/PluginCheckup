<?php
add_action('myscreen_bpm_refunds', 'myscreen_bpm_refunds_def');

function myscreen_bpm_refunds_def()
{
    global $bpm_Refund_List;

    $args = array(
        'label' => __('number of items', ''),
        'default' => 20,
        'option' => 'bpm_refund_per_page'
    );
    add_screen_option('per_page', $args);
    $bpm_Refund_List = new bpm_Refund_List();
}

add_action('admin_menu', 'bpm_refunds_admin_menu');

function bpm_refunds_admin_menu()
{

    $hook = add_submenu_page(
            'woocommerce',
            __('Beh-pardakht Mellat refunded orders', 'wc_beh'),
            __('BPM refunded orders', 'wc_beh'),
            'beh_refund',
            'bpm_refunds',
            'bpm_refund_page',
            2
    );

    add_action("load-$hook", 'myscreen_bpm_refunds_def');
}

function bpm_refund_page()
{
    global $bpm_Refund_List;
    ?>
    <div class="wrap">
        <h2><?php 
         _e('Beh-pardakht Mellat refunded orders', 'wc_beh');
        ?></h2>

        <div id="bpm_refund">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="post-body-content">
                    <div class="meta-box-sortables ui-sortable">
                        <?php
                        $bpm_Refund_List->subsubsub();
                        ?>
                        <form method="post">
                            <?php
                            global $bpm_Refund_List;
                            $bpm_Refund_List->prepare_items();
                            $bpm_Refund_List->search_box(__('Search order number', 'wc_beh'), 'search');
                            $bpm_Refund_List->display();
                            ?>
                        </form>
                    </div>
                </div>
            </div>
            <br class="clear">
        </div>
    </div>
    <?php
}
<?php
if (!defined('ABSPATH'))
{
    die("access denied!");
}

class WC_BEH_Admin
{

    public function __construct()
    {
        add_action('admin_init', [$this, 'do_check_validate']);
        add_action('admin_menu', [$this, 'admin_menu_func']);
        add_action('admin_enqueue_scripts', [$this, 'admin_style']);
    }

    /**
     * Return Notice Message
     * @param string $msg message
     * @param string $type error, success, warning
     * @return string
     */
    function admin_notice($msg = '', $type = 'success')
    {
        return '<div class="notice notice-' . $type . ' is-dismissible">
            <p>' . $msg . '</p>
        </div>';
    }

    function show_active_note()
    {
        $user = wp_get_current_user();
        $plugin_data = get_plugin_data(BEH_PLUGIN_FILE);
        $plName = $plugin_data['Name'];
        $msg = sprintf(__('Hi %s, to Register %s Plugin click %s.', 'wc_beh'), $user->display_name, "<b>" . $plName . "</b>", '<a href="' . admin_url('admin.php?page=wc-beh-active') . '">' . __('Here', 'wc_beh') . '</a>');
        $page = filter_input(INPUT_GET, 'page');
        if ($page == 'wc-beh-active')
        {
//
        } else
        {
            echo $this->admin_notice($msg, 'error');
        }
    }

    /**
     *  Check licence from db
     */
    function do_check_validate()
    {

        $active_state = WC_Beh_Activation::check_activation();
        if (!$active_state)
        {
            add_action('admin_notices', [$this, 'show_active_note']);
        }
    }

    /**
     * Register a custom menu page.
     */
    function admin_menu_func()
    {
        add_submenu_page(
                'woocommerce',
                __('BPM license', 'wc_beh'),
                __('BehPardakht license', 'wc_beh'),
                'manage_options',
                'wc-beh-active',
                [$this, 'activation_page'],
                2
        );
    }

    function admin_style()
    {
        wp_enqueue_style('wcj_style', BEH_WOO_URL . "assets/admin.css", array());
    }

    function activation_page()
    {
        $plugin_data = get_plugin_data(BEH_PLUGIN_FILE);

        $active_state = WC_Beh_Activation::check_activation();
        $license_token = WC_Beh_Activation::getUserLicence();
        if (!empty($license_token))
        {
            $license_token = $license_token;
        }

        $curr_tab = $_GET['tab'] ?? 'main';

        $main_params = array('page' => 'wc-beh-active', 'tab' => 'main');
        $products_params = array('page' => 'wc-beh-active', 'tab' => 'products');
        $tabs = array(
            'main' => ['url' => add_query_arg($main_params, admin_url('admin.php')), 'title' => __('Activation', 'wc_beh')],
            'products' => ['url' => add_query_arg($products_params, admin_url('admin.php')), 'title' => __('More products', 'wc_beh')],
        );
        ?>
        <div class="wrap">
            <h1><?= $plugin_data['Name'] ?></h1>
            <nav class="nav-tab-wrapper">
                <?php
                foreach ($tabs as $key => $tab_item)
                {
                    ?>
                    <a href="<?= esc_url($tab_item['url']) ?>" class="nav-tab <?= ($curr_tab == $key) ? 'nav-tab-active' : '' ?>"><?= $tab_item['title'] ?></a>
                    <?php
                }
                ?>
            </nav>
            <?php
            if (file_exists(BEH_WOO_DIR . "inc/tabs/$curr_tab.php"))
            {
                include BEH_WOO_DIR . "inc/tabs/$curr_tab.php";
            }
            ?>
        </div>

        <?php
    }

}

new WC_BEH_Admin();

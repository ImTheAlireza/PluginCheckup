<script type="text/javascript">
    var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
    var registrationSuccess = "<?php _e('Plugin license registration successful.', 'wc_beh'); ?>";
    var failed_error = "<?php _e('Error: The request failed!', 'wc_beh'); ?>";
    var errorString = "<?php _e('Error: ', 'wc_beh'); ?>";


    function dis_submitForm()
    {
        return false;
    }
    function submit_any_form(form_id)
    {
        var form_pay = jQuery('#' + form_id);


        var user_licence = form_pay.find('#user_licence').val();

        var my_action = form_pay.find('#action').val();

        var send_data = {action: my_action, user_licence: user_licence};
        try
        {
            var postData = send_data;
            var form_pay = jQuery('#' + form_id);

            form_pay.find('#loading_pb').show();
            jQuery('#red_dialog').hide(200);

            var request = jQuery.ajax({method: "POST", data: postData, dataType: "json", url: ajax_url});
            request.done(function (response)
            {
                form_pay.find('#loading_pb').hide(200);
                if (response)
                {
                    var res = response.res;
                    if (res === true)
                    {
                        jQuery("#red_dialog").html(registrationSuccess);
                        jQuery('#red_dialog').css('color', 'green');
                        jQuery('#red_dialog').show(200);
                        window.location.reload();

                    } else
                    {
                        console.log("response1 = %o", response);
                        jQuery('#red_dialog').html(errorString + response.msg);
                        jQuery('#red_dialog').css('color', 'red');
                        jQuery('#red_dialog').show(300);
                    }

                } else
                {

                    jQuery("#red_dialog").html(failed_error);
                    jQuery('#red_dialog').css('color', 'red');
                    jQuery('#red_dialog').show(300);
                    console.log("response2 = %o", response);
                }
            });
            request.fail(function (jqXHR, textStatus, errorThrown)
            {
                form_pay.find('#loading_pb').hide(200);
                console.log("jqXHR = %o", jqXHR);
                console.log("textStatus = %o", textStatus);
                console.log("errorThrown = %o", errorThrown);
                jQuery('#red_dialog').html(failed_error + '<br/>' + errorThrown);
                jQuery('#red_dialog').css('color', 'red');
                jQuery('#red_dialog').show(300);

                return;
            });
        } catch (err)
        {
            alert(err.message);
        }
    }
    jQuery(document).ready(function ($)
    {
        $('#wcpl_submit').click(function ()
        {

            if ($('#user_licence').val().length >= 1)
            {
                submit_any_form('reg_wcpl_form');
            } else
            {
                $('#red_dialog').html("<?php _e('Please enter the activation code!', 'wc_beh'); ?>");
                $('#red_dialog').css('color', 'red');
                $('#red_dialog').show(300);
            }
        });
    });

</script>

<div class="wrap wcpl_export_users">
    <form id="reg_wcpl_form" method="post" onsubmit="return dis_submitForm()">
        <input type="hidden" name="action" id="action" value="wcbeh_check_register" />
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label><?= __('Status', 'wc_beh') ?></label>
                    </th>
                    <td>
                        <p>
                            <?php
                            $input_status = "";
                            if ($active_state)
                            {
                                $input_status = 'readonly="readonly"';
                                echo '<span style="color:green;">';
                                _e('Congratulations! This plugin is active.', 'wc_beh');
                                echo '</span>';
                            } else
                            {
                                $input_status = "";
                                echo '<span style="color:red;">';
                                _e('Not registered!', 'wc_beh');
                                echo '</span>';
                            }
                            ?>  
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="user_licence"><?= __('License Key', 'wc_beh') ?></label>
                    </th>
                    <td>
                        <input <?= $input_status ?> name="user_licence" id="user_licence" type="text" class="regular-text code" value="<?= $license_token ?>" />
                        <p class="description"><span class="dashicons dashicons-warning"></span> 
                            <?php
                            printf(__('When you purchase this product from %s, a license key is assigned to your order and you can see it in your User Panel.', 'wc_beh'), '<a href="https://www.zhaket.com/web/wc-protect-external-link/">zhaket.com</a>');
                            ?>
                        </p>
                    </td>
                </tr>
            </tbody>
        </table>

        <?php
        if (!$active_state)
        {
            ?>   
            <div class="btn_div">
                <?php
                submit_button(__('Submit', 'wc_beh'), 'large', 'wcpl_submit', false);
                ?>
                &nbsp;<img id="loading_pb" style="width: 28px; display: none;" src="<?php echo admin_url('images/spinner-2x.gif') ?>" />
            </div>
            <?php
        }
         else
        {
            ?>   
            <div class="btn_div">
                <button type="button" class="button-primary"><a style="color: white; text-decoration: unset;" href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wc_behpardakht' ); ?>"><?= __('Gateway settings', 'wc_beh');?></a></button>
            </div>
            <?php
        }
        ?>

        <p style="display: none;" id="red_dialog"></p> 
        <p class="version">
            <?php printf(__('Version: %s', 'wc_beh'), $plugin_data['Version']) ?>
        </p>

    </form>
</div>
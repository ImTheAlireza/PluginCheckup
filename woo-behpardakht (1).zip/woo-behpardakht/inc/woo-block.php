<?php

if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;
use Automattic\WooCommerce\Blocks\Payments\PaymentMethodTypeInterface;

final class Beh_WC_Payments_Block extends AbstractPaymentMethodType {

    private $gateway;
    public $name = BEH_WOO_ID;

    public function initialize() {
        $trns = [__("Proceed to BehPardakht", "wc_beh"), __("BehPardakht", "wc_beh"), __("Payment via BehPardakht", "wc_beh")];
        $this->gateway = new WC_BehPardakht();
        $this->settings = get_option('woocommerce_' . BEH_WOO_ID . '_settings');
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
                'BEH_WC_BLOCKS_INTEGRATION',
                plugins_url('assets/block.js', BEH_PLUGIN_FILE),
                array('wc-blocks-registry', 'wc-settings', 'wp-element'),
                BEH_WOO_VER,
                true
        );

        return ['BEH_WC_BLOCKS_INTEGRATION'];
    }

    public function get_payment_method_data() {
        return array(
            'id' => $this->gateway->id,
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icon'=>  $this->gateway->icon,
            'OrderButtonLabel'=> $this->gateway->pay_btn_text,
            'enabled' => $this->gateway->is_available(),
            'pluginUrl' => BEH_WOO_URL,
            'supports' => $this->get_supported_features(),
        );
    }
}

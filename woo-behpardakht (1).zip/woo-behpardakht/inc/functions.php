<?php

function woo_behpardakht_IR_currency($currencies)
{
    if (!isset($currencies['IRR']))
    {
        $currencies['IRR'] = 'ریال';
    }
    if (!isset($currencies['IRT']))
    {
        $currencies['IRT'] = 'تومان';
    }
    if (!isset($currencies['IRR']))
    {
        $currencies['IRHR'] = 'هزار ریال';
    }
    if (!isset($currencies['IRR']))
    {
        $currencies['IRHT'] = 'هزار تومان';
    }
    return $currencies;
}

function woo_behpardakht_IR_currency_symbol($currency_symbol, $currency)
{
    switch ($currency)
    {
        case 'IRR':
            $currency_symbol = 'ریال';
            break;
        case 'IRT':
            $currency_symbol = 'تومان';
            break;
        case 'IRHR':
            $currency_symbol = 'هزار ریال';
            break;
        case 'IRHT':
            $currency_symbol = 'هزار تومان';
            break;
    }
    return $currency_symbol;
}

function woo_behpardakht_calc_price($Amount, $currency)
{

    if (strtolower($currency) == strtolower('IRT'))
    {
        $Amount = $Amount * 10;
    } else if (strtolower($currency) == strtolower('IRHT'))
    {
        $Amount = $Amount * 1000 * 10;
    } else if (strtolower($currency) == strtolower('IRHR'))
    {
        $Amount = $Amount * 1000;
    } else if (strtolower($currency) == strtolower('IRR'))
    {
        $Amount = $Amount * 1;
    }

    return $Amount;
}

function woo_beh_role_caps()
{
    $role = wp_roles()->get_role('administrator');
    if (!$role->has_cap('beh_refund'))
    {
        $role->add_cap('beh_refund', true);
    }
}

add_action('init', 'woo_beh_role_caps', 11);

function beh_woo_activation()
{
    global $wpdb;
    $table_name = $wpdb->prefix . "beh_refunds";
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `order_id` bigint(20) NOT NULL, 
            `seconder_id` bigint(20) NOT NULL default '0', 
            `amount` varchar(25) NOT NULL default '0', 
            `add_date` datetime NOT NULL,
            `date_refund` datetime NOT NULL,
            `adder_user`  bigint(20) NOT NULL,
            `status` tinyint(1) NOT NULL default '0',
            `extra_data` text NOT NULL,
     PRIMARY KEY (`id`)
    ) AUTO_INCREMENT=1 COLLATE utf8mb4_general_ci;";
    $wpdb->query($sql);
}

function get_beh_error_msg($ErrorCode) {
        $ErrorDesc = "";
        switch ($ErrorCode) {
            case -2:
                $ErrorDesc .= "شکست در ارتباط با بانک";
                break;
            case -1:
                $ErrorDesc .= "شکست در ارتباط با بانک";
                break;
            case 0:
                $ErrorDesc .= "تراکنش با موفقیت انجام شد";
                break;
            case 11:
                $ErrorDesc .= "شماره کارت معتبر نیست";
                break;
            case 12:
                $ErrorDesc .= "موجودی کافی نیست";
                break;
            case 13:
                $ErrorDesc .= "رمز دوم شما صحیح نیست";
                break;
            case 14:
                $ErrorDesc .= "دفعات مجاز ورود رمز بیش از حد است";
                break;
            case 15:
                $ErrorDesc .= "کارت معتبر نیست";
                break;
            case 16:
                $ErrorDesc .= "دفعات برداشت وجه بیش از حد مجاز است";
                break;
            case 17:
                $ErrorDesc .= "شما از انجام تراکنش منصرف شده اید";
                break;
            case 18:
                $ErrorDesc .= "تاریخ انقضای کارت گذشته است";
                break;
            case 19:
                $ErrorDesc .= "مبلغ برداشت وجه بیش از حد مجاز است";
                break;
            case 111:
                $ErrorDesc .= "صادر کننده کارت نامعتبر است";
                break;
            case 112:
                $ErrorDesc .= "خطای سوییچ صادر کننده کارت";
                break;
            case 113:
                $ErrorDesc .= "پاسخی از صادر کننده کارت دریافت نشد";
                break;
            case 114:
                $ErrorDesc .= "دارنده کارت مجاز به انجام این تراکنش نمی باشد";
                break;
            case 21:
                $ErrorDesc .= "پذیرنده معتبر نیست";
                break;
            case 23:
                $ErrorDesc .= "خطای امنیتی رخ داده است";
                break;
            case 24:
                $ErrorDesc .= "اطلاعات کاربری پذیرنده معتبر نیست";
                break;
            case 25:
                $ErrorDesc .= "مبلغ نامعتبر است";
                break;
            case 31:
                $ErrorDesc .= "پاسخ نامعتبر است";
                break;
            case 32:
                $ErrorDesc .= "فرمت اطلاعات وارد شده صحیح نیست";
                break;
            case 33:
                $ErrorDesc .= "حساب نامعتبر است";
                break;
            case 34:
                $ErrorDesc .= "خطای سیستمی";
                break;
            case 35:
                $ErrorDesc .= "تاریخ نامعتبر است";
                break;
            case 41:
                $ErrorDesc .= "شماره درخواست تکراری است";
                break;
            case 42:
                $ErrorDesc .= "تراکنش Sale یافت نشد";
                break;
            case 43:
                $ErrorDesc .= "قبلا درخواست Verify داده شده است";
                break;
            case 44:
                $ErrorDesc .= "درخواست Verify یافت نشد";
                break;
            case 45:
                $ErrorDesc .= "عملیات تسویه برای این تراکنش با موفقیت انجام شده است";
                break;
            case 46:
                $ErrorDesc .= "تراکنش Settle نشده است";
                break;
            case 47:
                $ErrorDesc .= "تراکنش Settle یافت نشد";
                break;
            case 48:
                $ErrorDesc .= "تراکنش Reverse شده است";
                break;
            case 49:
                $ErrorDesc .= "تراکنش Refund یافت نشد";
                break;
            case 412:
                $ErrorDesc .= "شناسه قبض نادرست است";
                break;
            case 413:
                $ErrorDesc .= "شناسه پرداخت نادرست است";
                break;
            case 414:
                $ErrorDesc .= "سازمان صادر کننده قبض معتبر نیست";
                break;
            case 415:
                $ErrorDesc .= "زمان جلسه کاری به پایان رسیده است";
                break;
            case 416:
                $ErrorDesc .= "خطا در ثبت اطلاعات";
                break;
            case 417:
                $ErrorDesc .= "شناسه پرداخت کننده نامعتبر است";
                break;
            case 418:
                $ErrorDesc .= "اشکال در تعریف اطلاعات مشتری";
                break;
            case 419:
                $ErrorDesc .= "تعداد دفعات ورود اطلاعات بیش از حد مجاز است";
                break;
            case 421:
                $ErrorDesc .= "IP معتبر نیست";
                break;
            case 51:
                $ErrorDesc .= "تراکنش تکراری است";
                break;
            case 54:
                $ErrorDesc .= "تراکنش مرجع موجود نیست";
                break;
            case 55:
                $ErrorDesc .= "تراکنش نامعتبر است";
                break;
            case 61:
                $ErrorDesc .= "خطا در واریز";
                break;
            case 62:
                $ErrorDesc .= "مسير بازگشت به سايت در دامنه ثبت شده برای پذيرنده قرار ندارد.";
                break;
            default:
                $ErrorDesc .= "خطای تعریف نشده";
        }
        return $ErrorCode . ': ' . $ErrorDesc;
    }
<?php
if (!class_exists('WP_List_Table'))
{
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class bpm_Refund_List extends WP_List_Table
{

    public function __construct()
    {
        global $status, $page;
        parent::__construct(array(
            'singular' => 'id',
            'ajax' => false,
        ));
    }

    public function subsubsub()
    {
        $admin_url = add_query_arg(array('page' => 'bpm_refunds'), admin_url('admin.php'));
        $cur_status = filter_input(INPUT_GET, 'cur_status');
        ?>
        <ul class="subsubsub">
            <li class="all">
                <a href="<?= $admin_url ?>" class="<?= empty($cur_status) ? 'current' : '' ?>">
                    <?php _e('All', 'wc_beh'); ?> 
                    <span class="count">(<?= $this->record_count('-1') ?>)</span>
                </a> |
            </li>
            <li class="pending">
                <a href="<?= $admin_url . "&cur_status=2" ?>" class="<?= $cur_status == '2' ? 'current' : '' ?>">
                    <?php _e('Pending', 'wc_beh'); ?> 
                    <span class="count">(<?= $this->record_count('2') ?>)</span>
                </a> |
            </li>
            <li class="confirmed">
                <a href="<?= $admin_url . "&cur_status=1" ?>" class="<?= $cur_status == '1' ? 'current' : '' ?>">
                    <?php _e('Confirmed', 'wc_beh'); ?> 
                    <span class="count">(<?= $this->record_count('1') ?>)</span>
                </a> |
            </li>
            <li class="rejected">
                <a href="<?= $admin_url . "&cur_status=3" ?>" class="<?= $cur_status == '3' ? 'current' : '' ?>">
                    <?php _e('Rejected', 'wc_beh'); ?> 
                    <span class="count">(<?= $this->record_count('3') ?>)</span>
                </a>
            </li>
        </ul>
        <?php
    }

    public function prepare_items()
    {

        $this->_column_headers = $this->get_column_info();

        /** Process bulk action */
        $this->process_bulk_action();

        $per_page = $this->get_items_per_page('bpm_refund_per_page', 20);
        $current_page = $this->get_pagenum();

        $cur_status = filter_input(INPUT_GET, 'cur_status');
        if (empty($cur_status))
        {
            $cur_status = -1;
        }
        $total_items = $this->record_count($cur_status);
        $this->items = $this->get_refunds($per_page, $current_page, $cur_status);

        $this->set_pagination_args(array(
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ));
    }

    function refundAmount($item_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'beh_refunds';
        $item = $wpdb->get_row("SELECT * FROM $table WHERE id='$item_id'");
        $order_id = $item->order_id;
        $amount = $item->amount;
        
        

        $order = wc_get_order($order_id);


        $RefId = $order->get_transaction_id();
        $foktor_id = $order->get_meta('foktor_id');

        $currency = $order->get_currency();

        if (intval($amount) > 0 && $item->status != 1)
        {
            $result = WC_BehPardakht::refundAmount($foktor_id, $order_id, $RefId, $amount);
            if (isset($result->return) || !empty($result->return))
            {
                $res2 = explode(',', $result->return);
                if ($res2[0] == "0")
                {

                    $am_str = number_format($amount) . " " . get_woocommerce_currency_symbol($currency);
                    $note = sprintf(__('%s was added for refund.', 'wc_beh'), $am_str);
                    $array2 = array(
                        'date_refund' => current_time('mysql'),
                        'seconder_id' => get_current_user_id(),
                        'status' => 1
                    );

                    $wpdb->update(
                            $table,
                            $array2,
                            array('id' => $item_id),
                            array('%s', '%d', '%d'),
                            array('%d')
                    );

                    $order->add_order_note($note, 1);

                    return true;
                } else
                {
                    $note = sprintf(__("Refund failed! Recursive error code: %s", 'wc_beh'), $res2[0]);
                    $order->add_order_note($note);
                    return false;
                }
            } else
            {
                file_put_contents(BEH_WOO_DIR . 'log_beh', print_r($result, true) . PHP_EOL);
                return new WP_Error('error', print_r($result, true));
            }
        }
    }

    public function process_bulk_action()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'beh_refunds';

        // var_dump($this->current_action());exit;

        if (current_user_can('administrator') || current_user_can('beh_refund'))
        {
            $admin_url = add_query_arg(array('page' => 'bpm_refunds'), admin_url('admin.php'));


            $action = $_REQUEST['action'] ?? false;
            if (!$action)
            {
                $action = $_REQUEST['action2'] ?? false;
            }

            if ($action == 'confirm' || $action == 'bulk-confirm')
            {
                if ($_POST)
                {
                    $ids = esc_sql($_POST['id']);
                    foreach ($ids as $id)
                    {
                        $result = $this->refundAmount($id);
                    }
                    $admin_url = filter_input(INPUT_POST, '_wp_http_referer') . '&reply=true';
                } else
                {
                    $item_id = filter_input(INPUT_GET, 'item_id');
                    $result = $this->refundAmount($item_id);
                    if ($result)
                    {
                        $admin_url .= $reply = '&reply=true';
                    }
                }

                wp_redirect($admin_url);
                exit;
            } elseif ($action == 'reject' || $action == 'bulk-reject')
            {
                if ($_POST)
                {
                    $ids = esc_sql($_POST['id']);
                    foreach ($ids as $id)
                    {
                        $item = $wpdb->get_row("SELECT * FROM $table WHERE id='$id'");
                        if ($item && $item->status != 3)
                        {
                            $wpdb->update(
                                    $table,
                                    array('seconder_id' => get_current_user_id(), 'status' => 3),
                                    array('id' => $id),
                                    array('%d', '%d'),
                                    array('%d')
                            );

                            $order = wc_get_order($item->order_id);
                            $note = __("Refund request rejected!", 'wc_beh');
                            if ($order)
                            {
                                $order->add_order_note($note, 1);
                            }
                        }
                    }
                    $admin_url = filter_input(INPUT_POST, '_wp_http_referer') . '&reply=true';
                } else
                {
                    $item_id = filter_input(INPUT_GET, 'item_id');
                    $item = $wpdb->get_row("SELECT * FROM $table WHERE id='$item_id'");
                    if ($item && $item->status != 3)
                    {
                        $wpdb->update(
                                $table,
                                array('seconder_id' => get_current_user_id(), 'status' => 3),
                                array('id' => $item_id),
                                array('%d', '%d'),
                                array('%d')
                        );

                        $order = wc_get_order($item->order_id);
                        $note = __("Refund request rejected!", 'wc_beh');
                        if ($order)
                        {
                            $order->add_order_note($note, 1);
                        }
                    }
                }
                wp_redirect($admin_url);
                exit;
            } elseif ($action == 'pending' || $action == 'bulk-pending')
            {
                $ids = esc_sql($_POST['id']);
                foreach ($ids as $id)
                {
                    $item = $wpdb->get_row("SELECT * FROM $table WHERE id='$id'");
                    if ($item->status != 2)
                    {
                        $wpdb->update(
                                $table,
                                array('seconder_id' => get_current_user_id(), 'status' => 2),
                                array('id' => $id),
                                array('%d', '%d'),
                                array('%d')
                        );
                    }
                }
                $admin_url = filter_input(INPUT_POST, '_wp_http_referer') . '&reply=true';
                wp_redirect($admin_url);
                exit;
            }
        }
    }

    public function get_bulk_actions()
    {
        $actions = [
            'bulk-confirm' => __('Confirm', 'wc_beh'),
            'bulk-reject' => __('Reject', 'wc_beh'),
            'bulk-pending' => __('Pending', 'wc_beh'),
        ];

        return $actions;
    }

    function get_primary_column_name()
    {
        return 'amount';
    }

    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'amount' => __('Amount', 'wc_beh'),
            'user_info' => __('Customer', 'wc_beh'),
            'adder_user' => __('Applicant', 'wc_beh'),
            'date_add' => __('Request Date', 'wc_beh'),
            'date_refund' => __('Refund Date:', 'wc_beh'),
            'order_details' => __('Order details', 'wc_beh'),
            'status' => __('Status', 'wc_beh')
        );

        return $columns;
    }

    function get_sortable_columns()
    {
        $sortable_columns = array(
            'date_add' => array('add_date', true),
            'amount' => array('amount', false),
            'status' => array('status', false),
        );
        return $sortable_columns;
    }

    function column_default($item, $column_name)
    {
        $order = wc_get_order($item->order_id);

        $status = $item->status; //2 pendding , 1 refunded
        $refund_date = $item->date_refund;
        $bpm_refund_user_id = $item->adder_user;
        $bpm_date_add = $item->add_date;


        $return_str = "";

        switch ($column_name)
        {
            case 'user_info':

                $userdata = $order->get_user();
                if ($userdata)
                {
                    $cus_name = esc_attr($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
                    $return_str .= '<a data_id="' . var_export($userdata, true) . '" href="' . get_edit_user_link($userdata->ID) . '">' . $cus_name . '</a>';
                } else
                {
                    $return_str = esc_attr($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
                }

                break;

            case 'adder_user':
                $userdata = get_userdata($bpm_refund_user_id);
                $return_str = '<a href="' . get_edit_user_link($bpm_refund_user_id) . '">' . esc_attr($userdata->first_name . ' ' . $userdata->last_name) . '</a>';

                break;

            case 'date_add':
                if (!empty($bpm_date_add) && strtotime($bpm_date_add) > 0)
                {
                    $add_date = date_i18n('Y-m-d H:i:s', strtotime($bpm_date_add));
                    $return_str = '<span dir="ltr">' . $add_date . '</span>';
                }

                break;

            case 'date_refund':

                if (!empty($refund_date) && strtotime($refund_date) > 0)
                {
                    $add_date = date_i18n('Y-m-d H:i:s', strtotime($refund_date));
                    $return_str = '<span dir="ltr">' . $refund_date . '</span>';
                }
                break;

            case 'order_details':

                $date = $order->get_date_paid();
                if ($date != null)
                {
                    $return_str = '<b>' . __('Link:', 'wc_beh') . ' </b><a href="' . get_edit_post_link($item->order_id) . '">#' . $item->order_id . '</a><br>';
                    $return_str .= '<b>' . __('Date:', 'wc_beh') . ': </b><span dir="ltr">' . $date->date_i18n('Y-m-d H:i:s') . '</span>';
                }
                break;


            case 'status':

                switch (intval($status))
                {
                    case 1:
                        $return_str = '<b style="color:green;">' . __('Done', 'wc_beh') . '</b>';
                        break;
                    case 2:
                        $return_str = '<b style="color:#000;">' . __('Pending', 'wc_beh') . '</b>';
                        break;
                    case 3:
                        $return_str = '<b style="color:red;">' . __('Failed', 'wc_beh') . '</b>';
                        break;
                    default:
                        $return_str = '<b>' . __('Unknown', 'wc_beh') . '</b>';
                        break;
                }

                break;
        }

        return $return_str;
    }

    function column_amount($item)
    {
        $order_id = $item->order_id;
        $order = wc_get_order($order_id);
        $currency = $order->get_currency();

        $amount = $item->amount;
        $amount_str = number_format($amount) . ' ' . get_woocommerce_currency_symbol($currency);
        $actions = array(
            'confirm' =>
            '<a href="' . admin_url('admin.php?page=bpm_refunds&action=confirm&item_id=' . $item->id) . '">' . __('Confirm', 'wc_beh') . '</a>',
            'reject' => '<a href="' . admin_url('admin.php?page=bpm_refunds&action=reject&item_id=' . $item->id) . '">' . __('Reject', 'wc_beh') . '</a>'
        );

        return sprintf('%1$s %2$s', $amount_str, $this->row_actions($actions));
    }

    function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="%1$s[]" value="%2$s" />', $this->_args['singular'], $item->id);
    }

    function get_refunds($per_page = 20, $current_page = 1, $status = -1)
    {
        $s = isset($_REQUEST['s']) ? $_REQUEST['s'] : '';

        global $wpdb;
        $offset = ($current_page - 1) * $per_page;

        $table = $wpdb->prefix . 'beh_refunds';
        $sql = "SELECT * FROM $table WHERE `id` > 0";


        if ($status != '-1')
        {
            $sql = "SELECT * FROM $table WHERE `status` ='$status'";
        }

        if (!empty($s))
        {
            $sql .= " AND `order_id`=$s";
        }

        if (!empty($_REQUEST['orderby']))
        {
            $sql .= ' ORDER BY ' . esc_sql($_REQUEST['orderby']);
            $sql .= !empty($_REQUEST['order']) ? ' ' . esc_sql($_REQUEST['order']) : ' ASC';
        } else
        {
            $sql .= ' ORDER BY `add_date` DESC';
        }

        $sql .= " LIMIT $offset , $per_page";
        $result = $wpdb->get_results($sql);
        return $result;
    }

    function record_count($status = '-1')
    {
        global $wpdb;
        $table = $wpdb->prefix . 'beh_refunds';
        $sql = "SELECT COUNT(*) FROM $table WHERE `id`> 0";
        if ($status != '-1')
        {
            $sql = "SELECT COUNT(*) FROM $table WHERE `status` ='$status'";
        }

        return $wpdb->get_var($sql);
    }

    function single_row($item)
    {
        $order_id = $item->order_id;

        $status = $item->status;
        $class = '';
        if ($status == 1)
        {
            $class = 'active';
        }

        echo '<tr class="' . $class . '">';
        $this->single_row_columns($item);
        echo '</tr>';
    }

    function no_items()
    {
        _e('There are no results!', 'wc_beh');
    }

}

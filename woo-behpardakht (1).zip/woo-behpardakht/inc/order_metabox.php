<?php

class BPM_WC_MetaBox {

    public function __construct() {
        add_action('add_meta_boxes', [$this, 'add_check_pay_status_meta_box']);
        add_action('wp_ajax_beh_payment_inquiry', [$this, 'beh_payment_inquiry']);
    }

    function beh_payment_inquiry() {

        $order_id = isset($_POST['oid']) ? $_POST['oid'] : null;
        if (empty($order_id)) {
            $res_js = array('code' => -43, 'msg' => __('Order id is empty!', 'wc_beh'));
            wp_send_json($res_js, 200);
        }

        $order = wc_get_order($order_id);
        if (empty($order)) {
            $res_js = array('code' => -43, 'msg' => __('Order no found!', 'wc_beh'));
            wp_send_json($res_js, 200);
        }

        try {

            $settings = get_option('woocommerce_' . BEH_WOO_ID . '_settings');

            $terminal_id = $settings['terminal_id'] ?? '';
            $username = $settings['username'] ?? '';
            $password = $settings['password'] ?? '';
            $foktor_id = $order->get_meta("foktor_id", true);

            $SaleReferenceId = $order->get_transaction_id();
            if (empty($SaleReferenceId)) {
                $SaleReferenceId = $order->get_meta('BehSaleReferenceId', true);
            }
            $parameters = array(
                'terminalId' => $terminal_id,
                'userName' => $username,
                'userPassword' => $password,
                'orderId' => $foktor_id,
                'saleOrderId' => $foktor_id,
                'saleReferenceId' => $SaleReferenceId
            );
            $result = WC_BehPardakht::soap_call('bpInquiryRequest', $parameters);
            $VerResult = explode(',', $result->return);
            $VerResultInt = $VerResult[0];

            $msg = get_beh_error_msg($VerResultInt);

            $res_js = array('code' => $VerResultInt, 'msg' => $msg . " [$VerResultInt]");
        } catch (Exception $exc) {

            $res_js = array('code' => -43, 'msg' => $exc->getMessage());
        }

        wp_send_json($res_js, 200);
    }

    function add_check_pay_status_meta_box() {
        add_meta_box(
                'woocommerce-order-pay-status',
                __('BehPardakht Payment inquiry', 'wc_beh'),
                [$this, 'check_payment_status_meta_box'],
                'woocommerce_page_wc-orders',
                'side',
                'high'
        );
    }

    function check_payment_status_meta_box($order) {

        $order2 = wc_get_order($order);

        if ($order2->get_payment_method() === BEH_WOO_ID) {
            $inquiry_res = $order2->get_meta('beh_inquiry_result ', true);
            ?>
            <div class="beh-payment-inquiry">
                <table>
                    <tr>
                        <td>
                            <p><?php _e('Check the transaction status for this order.', 'wc_beh') ?></p>
                        </td>
                    </tr>
                    <tr>

                        <td style="text-align: center">
                            <p class="inquiry-res">
                                <?php
                                if ($inquiry_res == 1) {
                                    _e('This order has been queried and successfully paid.', 'wc_beh');
                                }
                                ?>
                            </p>
                            <button type="button" data-oid="<?php echo $order2->get_id() ?>" class="button button-primary inquiry">
                                <?php _e('Inquiry', 'wc_beh') ?>
                                &nbsp;<img id="loading_pb" style="width: 28px; display: none;" src="<?php echo admin_url('images/spinner-2x.gif') ?>" />
                            </button>

                        </td>
                    </tr>

                </table>
            </div>
            <?php
        } else {
            echo '<p>' . __('This order was not paid with BehPardakht.', 'wc_beh') . '</p>';
        }
    }
}

new BPM_WC_MetaBox();

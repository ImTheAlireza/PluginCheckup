<?php

/**
 * BehPardakht Payment Gateway for WooCommerce
 */
class WC_BehPardakht extends WC_Payment_Gateway
{

    private static function get_wc_logger_context()
    {
        $source = defined('BEH_WOO_ID') ? BEH_WOO_ID : 'woo-behpardakht';
        return array('source' => $source);
    }

    private static function redact_log_params($parameters)
    {
        if (!is_array($parameters)) {
            return $parameters;
        }

        $redacted = $parameters;
        foreach (array('userPassword', 'password', 'pass', 'pwd', 'token', 'api_key', 'apikey') as $key) {
            if (array_key_exists($key, $redacted)) {
                $redacted[$key] = '***';
            }
        }
        return $redacted;
    }

    private static function log_wc_error($message, $context = array())
    {
        if (!function_exists('wc_get_logger')) {
            return;
        }

        try {
            $logger = wc_get_logger();
            $logger->error($message, array_merge(self::get_wc_logger_context(), $context));
        } catch (Exception $e) {
            // Never block payment flow due to logging failure.
        }
    }

    private static function truncate_for_log($value, $maxLen = 4000)
    {
        if (!is_string($value)) {
            return $value;
        }

        if (strlen($value) <= $maxLen) {
            return $value;
        }

        return substr($value, 0, $maxLen) . '...';
    }

    public static function loadLibrary()
    {
        $settings = get_option('woocommerce_' . BEH_WOO_ID . '_settings');
        $check_card = isset($settings['check_card']) ? $settings['check_card'] : 'no';
        $ham3daWooPaymentUtility = new ham3daWooPaymentUtility(BEH_WOO_ID, $check_card);
        $ham3daWooPaymentUtility->init();
    }

    public $author, $send_phone, $check_card, $pay_btn_text;
    private $terminal_id, $username, $password;
    public $success_massage, $failed_massage;

    public function __construct()
    {


        $this->author = 'ham3da.ir';
        $this->id = BEH_WOO_ID;
        $this->method_title = __('Behpardakht Mellat', 'wc_beh');
        $this->method_description = __('Behpardakht Mellat Gateway Settings', 'wc_beh');

        $this->has_fields = false;

        $this->supports = array(
            'products',
            'refunds',
        );


        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description', '');
        $this->icon = apply_filters('wc_bpm_logo', $this->get_ico_url());

        $this->terminal_id = $this->get_option('terminal_id', '');
        $this->username = $this->get_option('username', '');
        $this->password = $this->get_option('password', '');

        $this->send_phone = $this->get_option('send_phone', 'no');
        $this->check_card = $this->get_option('check_card', 'no');
        $this->pay_btn_text = $this->get_option('pay_btn_text', __("Proceed to Behpardakht", "wc_beh"));

        $this->success_massage = $this->get_option('success_massage', '');
        $this->failed_massage = $this->get_option('failed_massage', '');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_' . strtolower(get_class($this)) . '', array($this, 'verify_payment'));

        // Handle redirect to gateway
        add_action(
            'woocommerce_api_behpardakht_redirect',
            array($this, 'handle_gateway_redirect')
        );

        add_action('woocommerce_thankyou_' . $this->id . '', array($this, 'cm_thankyou'));
    }

    function get_ico_url()
    {
        $icon = $this->get_option('bpm_logo', null);
        $url = BEH_WOO_URL . 'assets/images/logo.png';
        if (!empty($icon)) {
            $url = $icon;
        }
        return $url;
    }

    public static function soap_call($method, $parameters = [])
    {
        $wsdl = 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl';
        $encoding = 'UTF-8';

        if (class_exists('SoapClient')) {
            // PHP SOAP
            try {
                $client = new SoapClient($wsdl, ['encoding' => $encoding]);
                return $client->__soapCall($method, [$parameters]);
            } catch (Exception $e) {
                self::log_wc_error('SOAP Error: ' . $e->getMessage(), array(
                    'method' => $method,
                    'wsdl' => $wsdl,
                    'params' => self::redact_log_params($parameters),
                ));
                return (object)['return' => ['-1', 'SOAP Error: ' . $e->getMessage()]];
            }
        } else {
            // NuSOAP
            require_once BEH_WOO_DIR . 'inc/lib/nusoap.php';
            $client = new nusoap_client($wsdl);
            // NuSOAP expects parameters as a flat associative array.
            $namespace = 'http://interfaces.core.sw.bps.com/';

            if ($err = $client->getError()) {
                self::log_wc_error('NuSOAP Error: ' . $err, array(
                    'method' => $method,
                    'wsdl' => $wsdl,
                    'params' => self::redact_log_params($parameters),
                    'request' => self::truncate_for_log($client->request ?? null),
                    'response' => self::truncate_for_log($client->response ?? null),
                    'debug' => self::truncate_for_log($client->debug_str ?? null),
                ));
                return (object)['return' => ['-1', 'NuSOAP Error: ' . $err]];
            }

            $result = $client->call($method, $parameters, $namespace);


            if ($client->fault) {
                self::log_wc_error('NuSOAP Fault', array(
                    'method' => $method,
                    'wsdl' => $wsdl,
                    'params' => self::redact_log_params($parameters),
                    'fault' => $result,
                    'request' => self::truncate_for_log($client->request ?? null),
                    'response' => self::truncate_for_log($client->response ?? null),
                    'debug' => self::truncate_for_log($client->debug_str ?? null),
                ));
                return (object)['return' => ['-2', 'NuSOAP Fault: ' . var_export($result, true)]];
            }


            return $result;
        }
    }



    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = wc_get_order($order_id);
        global $wpdb;
        $table = $wpdb->prefix . 'beh_refunds';

        $data = array(
            'order_id' => $order_id,
            'amount' => $amount,
            'add_date' => current_time('mysql'),
            'adder_user' => get_current_user_id(),
            'status' => 2 //2 pendding , 1 refunded, 3 reject
        );
        $format = array('%d', '%d', '%s', '%d', '%d');
        $res = $wpdb->insert($table, $data, $format);
        $my_id = $wpdb->insert_id;

        $currency = $order->get_currency();
        $am_str = number_format($amount) . " " . get_woocommerce_currency_symbol($currency);
        $note = sprintf(__('%s was added for refund.', 'wc_beh'), $am_str);
        $order->add_order_note($note);
        if ($res) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 
     * @param int|string $foktor_id
     * @param int $order_id
     * @param string $RefId
     * @param int|float $Amount
     * @return object|false 
     */
    public static function refundAmount($foktor_id, $order_id, $RefId, $Amount)
    {
        if (current_user_can('administrator') || current_user_can('beh_refund')) {

            $settings = get_option('woocommerce_' . BEH_WOO_ID . '_settings');

            $terminal_id = isset($settings['terminal_id']) ? $settings['terminal_id'] : '';
            $username = isset($settings['username']) ? $settings['username'] : '';
            $password = isset($settings['password']) ? $settings['password'] : '';
            $orderId_new = time();

            $order = wc_get_order($order_id);

            $currency = $order->get_currency();

            try {
                $Amount2 = woo_behpardakht_calc_price($Amount, $currency);
                $parameters = array(
                    'terminalId' => $terminal_id,
                    'userName' => $username,
                    'userPassword' => $password,
                    'orderId' => $orderId_new,
                    'saleOrderId' => $foktor_id,
                    'saleReferenceId' => $RefId,
                    'refundAmount' => $Amount2,
                );
                $result = self::soap_call('bpRefundRequest', $parameters);
                return $result;
            } catch (Exception $exc) {
                $order->add_order_note('Refund Error: ' . $exc->getMessage());
                return false;
            }
        } else {
            return false;
        }
    }

    public function admin_options()
    {
        parent::admin_options();
    }

    public function init_form_fields()
    {
        $icon = $this->get_ico_url();
        $this->form_fields = apply_filters(
            'WC_BehPardakht_Config',
            array(
                'base_confing' => array(
                    'title' => __('Gateway settings', 'wc_beh'),
                    'type' => 'title',
                    'description' => '',
                ),
                'enabled' => array(
                    'title' => __('Enable', 'wc_beh'),
                    'type' => 'checkbox',
                    'label' => __('Enable gateway', 'wc_beh'),
                    'description' => '',
                    'default' => 'yes',
                    'desc_tip' => true,
                ),
                'title' => array(
                    'title' => __('Gateway title', 'wc_beh'),
                    'type' => 'text',
                    'description' => __('The title of the payment gateway that is displayed to the customer during the purchase.', 'wc_beh'),
                    'default' => __('BehPardakh Mellat', 'wc_beh'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Gateway Description', 'wc_beh'),
                    'type' => 'text',
                    'desc_tip' => true,
                    'description' => __('Description of the payment gateway', 'wc_beh'),
                    'default' => __('Secure payment through the BehPardakh Mellat', 'wc_beh')
                ),
                'account_confing' => array(
                    'title' => __('Payment gateway information', 'wc_beh'),
                    'type' => 'title',
                    'description' => '',
                ),
                'terminal_id' => array(
                    'title' => __('Terminal ID', 'wc_beh'),
                    'type' => 'text',
                    'description' => __('The terminal id has been sent to you by BehPardakh Mellat Company.', 'wc_beh'),
                    'default' => '',
                    'desc_tip' => false
                ),
                'username' => array(
                    'title' => __('Username', 'wc_beh'),
                    'type' => 'text',
                    'description' => __('The Username id has been sent to you by BehPardakh Mellat Company.', 'wc_beh'),
                    'default' => '',
                    'desc_tip' => false
                ),
                'password' => array(
                    'title' => __('Password', 'wc_beh'),
                    'type' => 'text',
                    'description' => __('The Username id has been sent to you by BehPardakh Mellat Company.', 'wc_beh'),
                    'default' => '',
                    'desc_tip' => false
                ),
                'payment_confing' => array(
                    'title' => __('Advanced settings', 'wc_beh'),
                    'type' => 'title',
                    'description' => '',
                ),
                'check_card' => array(
                    'title' => __('Check the user card number', 'wc_beh'),
                    'type' => 'checkbox',
                    'label' => __('Enable', 'wc_beh'),
                    'description' => __('‌If this option is enabled, the user can only buy with the cards defined by the site administrator in his user profile, and if he pays with other cards, his order will be checked.', 'wc_beh'),
                    'default' => 'no',
                    'desc_tip' => false,
                ),
                'send_phone' => array(
                    'title' => __('Send mobile number to the gateway', 'wc_beh'),
                    'type' => 'checkbox',
                    'label' => __('Send mobile number to the gateway', 'wc_beh'),
                    'description' => __('Send mobile number to payment gateway to save user card number', 'wc_beh'),
                    'default' => 'no',
                    'desc_tip' => false,
                ),
                'bpm_logo' => array(
                    'title' => __('Gateway logo', 'wc_beh'),
                    'type' => 'text',
                    'desc_tip' => false,
                    'description' => __('Logo URL', 'wc_beh'),
                    'class' => 'code',
                    'default' => $icon,
                ),
                'pay_btn_text' => array(
                    'title' => __('Order button text', 'wc_beh'),
                    'type' => 'text',
                    'default' => __('Proceed to BehPardakht', 'wc_beh'),
                    'desc_tip' => true,
                ),
                'success_massage' => array(
                    'title' => __('Successful payment message', 'wc_beh'),
                    'type' => 'textarea',
                    'description' => __('Enter the text of the message you want to display to the user after successful payment.
                                            You can also use the following shortcodes:<br/>
                                            <strong>%Transaction_id%</strong> : Transaction Code<br/>
                                            <strong>%Order_Number%</strong> : Transaction order id<br/>', 'wc_beh'),
                    'default' => __('Payment was successful.', 'wc_beh'),
                ),
                'failed_massage' => array(
                    'title' => __('Unsuccessful payment message', 'wc_beh'),
                    'type' => 'textarea',
                    'description' => __("Enter the text of the message you want to display to the user after a failed payment. You can also use the \"%fault%\" shortcode to display the cause of the error.", 'wc_beh'),
                    'default' => __('Payment failed. Error description: %fault%', 'wc_beh'),
                ),
            )
        );
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);

        // بررسی فعال بودن لایسنس (مطابق کد شما)
        $active_state = WC_Beh_Activation::check_activation();
        if (!$active_state) {
            wc_add_notice(__('The license of this payment gateway is not registered. Please contact site support!', 'wc_beh'), 'error');
            return array('result' => 'fail');
        }

        // محاسبه مبلغ و سایر تنظیمات
        $currency = $order->get_currency();
        $Amount = woo_behpardakht_calc_price(intval($order->get_total()), $currency);
        $foktor_id = time() + intval($order_id);

        // درخواست به درگاه بانک
        try {
            $parameters = array(
                'terminalId' => $this->terminal_id,
                'userName' => $this->username,
                'userPassword' => $this->password,
                'orderId' => $foktor_id,
                'amount' => $Amount,
                'localDate' => date("Ymd"),
                'localTime' => date("His"),
                'additionalData' => "wc order id: $order_id",
                'callBackUrl' => add_query_arg('wc_order', $order_id, WC()->api_request_url('WC_BehPardakht')),
                'payerId' => 0
            );



            $result = self::soap_call('bpPayRequest', $parameters);
            $PayResult = explode(',', $result->return);

            if ($PayResult[0] === "0") {
                $RefID = $PayResult[1];

                // ذخیره اطلاعات مورد نیاز در متادیتای سفارش
                $order->update_meta_data('foktor_id', $foktor_id);
                $order->update_meta_data('RefId', $RefID);

                // Add informative notes
                $order->add_order_note(sprintf('توکن پرداخت صادر شد. RefId: %s', $RefID));
                $order->add_order_note('در حال هدایت کاربر به درگاه پرداخت به‌پرداخت ملت.');
                $order->save();

                // Redirect to a dedicated WooCommerce API endpoint.
                // This route works even when the cart has already been emptied.
                $redirect_url = add_query_arg(
                    array(
                        'wc-api'   => 'behpardakht_redirect',
                        'order_id' => $order_id,
                        'key'      => $order->get_order_key(),
                    ),
                    home_url('/')
                );

                return array(
                    'result'   => 'success',
                    'redirect' => esc_url_raw($redirect_url),
                );
            } else {
                $err = get_beh_error_msg($PayResult[0]);
                $order->add_order_note('خطا در اتصال به درگاه: ' . $err . '<br>' . 'Result: ' . var_export($PayResult, true));
                wc_add_notice('خطا در اتصال به درگاه پرداخت: ' . $err, 'error');
                return array('result' => 'fail');
            }
        } catch (Exception $ex) {
            $order->add_order_note('خطای سیستمی: ' . $ex->getMessage());
            wc_add_notice('خطای سیستمی در پرداخت', 'error');
            return array('result' => 'fail');
        }
    }

    /**
     * Handle redirect to payment gateway
     */
    public function handle_gateway_redirect()
    {
        nocache_headers();

        $order_id = isset($_GET['order_id'])
            ? absint(wp_unslash($_GET['order_id']))
            : 0;

        $provided_key = isset($_GET['key'])
            ? wc_clean(wp_unslash($_GET['key']))
            : '';

        if (!$order_id || $provided_key === '') {
            wp_die(
                esc_html__('اطلاعات درخواست پرداخت ناقص است.', 'wc_beh'),
                esc_html__('خطای پرداخت', 'wc_beh'),
                array('response' => 400)
            );
        }

        $order = wc_get_order($order_id);

        if (!$order) {
            wp_die(
                esc_html__('سفارش موردنظر یافت نشد.', 'wc_beh'),
                esc_html__('خطای پرداخت', 'wc_beh'),
                array('response' => 404)
            );
        }

        $expected_key = (string) $order->get_order_key();

        if (
            $expected_key === '' ||
            !hash_equals($expected_key, (string) $provided_key)
        ) {
            $order->add_order_note(
                'تلاش نامعتبر برای ورود به مسیر انتقال به‌پرداخت ملت؛ کلید سفارش معتبر نبود.'
            );
            $order->save();

            wp_die(
                esc_html__('دسترسی به این درخواست پرداخت مجاز نیست.', 'wc_beh'),
                esc_html__('خطای پرداخت', 'wc_beh'),
                array('response' => 403)
            );
        }

        if ($order->is_paid()) {
            wp_safe_redirect($this->get_return_url($order));
            exit;
        }

        $refid = (string) $order->get_meta('RefId', true);

        if ($refid === '') {
            $order->add_order_note(
                'خطا در انتقال به به‌پرداخت ملت: توکن RefId در سفارش یافت نشد.'
            );
            $order->save();

            wp_die(
                esc_html__(
                    'توکن پرداخت سفارش یافت نشد. لطفاً پرداخت را دوباره آغاز کنید.',
                    'wc_beh'
                ),
                esc_html__('خطای پرداخت', 'wc_beh'),
                array('response' => 400)
            );
        }

        $order->add_order_note(
            'کاربر به صفحه انتقال درگاه پرداخت به‌پرداخت ملت رسید.'
        );
        $order->save();

        $this->redirect_to_gateway($refid, $order);
        exit;
    }

    private function redirect_to_gateway($RefID, $order)
    {
        $phone = $order->get_billing_phone();
        $gateway_url = 'https://bpm.shaparak.ir/pgwchannel/startpay.mellat';

        // Clean output buffer to ensure clean output
        if (ob_get_level() > 0) {
            ob_end_clean();
        }

        // Set proper headers to prevent caching and buffering issues
        @header('Content-Type: text/html; charset=utf-8');
        @header('Cache-Control: no-cache, no-store, must-revalidate');
        @header('Pragma: no-cache');
        @header('Expires: 0');

        ?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html(__('Processing Payment...', 'wc_beh')); ?></title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .payment-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 40px;
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .payment-container h1 {
            color: #333;
            margin-top: 0;
            font-size: 24px;
        }
        .payment-container p {
            color: #666;
            line-height: 1.6;
            margin: 15px 0;
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .submit-btn {
            background-color: #3498db;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        .submit-btn:hover {
            background-color: #2980b9;
        }
        .submit-btn:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body>
    <div class="payment-container">
        <h1><?php echo esc_html(__('Processing Payment...', 'wc_beh')); ?></h1>
        <div class="spinner"></div>
        <p><?php echo esc_html(__('You are being redirected to the payment gateway.', 'wc_beh')); ?></p>
        <p><?php echo esc_html(__('Please do not close this page. If you are not redirected within a few seconds, click the button below.', 'wc_beh')); ?></p>

        <form id="behpardakht_redirect" method="POST" action="<?php echo esc_url($gateway_url); ?>">
            <input type="hidden" name="RefId" value="<?php echo esc_attr($RefID); ?>">
            <?php if ($this->send_phone == 'yes' && WC_Validation::is_phone($phone)) { ?>
                <input type="hidden" name="MobileNo" value="<?php echo esc_attr($phone); ?>">
            <?php } ?>

            <noscript>
                <p><?php echo esc_html(__('Please enable JavaScript in your browser to proceed with the payment.', 'wc_beh')); ?></p>
                <button type="submit" class="submit-btn">
                    <?php echo esc_html(__('Click here to proceed to payment', 'wc_beh')); ?>
                </button>
            </noscript>
        </form>

        <script type="text/javascript">
        (function() {
            // Auto-submit the form using multiple methods to ensure compatibility
            var form = document.getElementById('behpardakht_redirect');
            
            // Method 1: Direct submit
            if (form && typeof form.submit === 'function') {
                try {
                    form.submit();
                } catch (e) {
                    // If submit() fails, try alternative methods
                    submitFormAlternative(form);
                }
            }

            function submitFormAlternative(formElement) {
                // Method 2: Simulate form submission via navigation
                if (formElement.method.toLowerCase() === 'post') {
                    try {
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', formElement.action, true);
                        
                        var formData = new FormData(formElement);
                        xhr.onload = function() {
                            window.location.href = formElement.action;
                        };
                        xhr.onerror = function() {
                            // Fallback to form.submit() if XHR fails
                            formElement.submit();
                        };
                        
                        xhr.send(formData);
                    } catch (e) {
                        // Ultimate fallback: direct redirect with form params in body
                        window.location.href = formElement.action;
                    }
                }
            }

            // Method 3: Timeout fallback - if form hasn't submitted after 5 seconds
            setTimeout(function() {
                if (window.location.href === window.location.href) {
                    // Page hasn't changed, try again
                    if (form && typeof form.submit === 'function') {
                        try {
                            form.submit();
                        } catch (e) {}
                    }
                }
            }, 5000);
        })();
        </script>
    </div>
</body>
</html>
        <?php
        exit;
    }


    public function cm_thankyou($order_id)
    {

        $order = wc_get_order($order_id);
        if ($order) {

            $foktor_id = $order->get_meta("foktor_id", true);
            $transaction_id = $order->get_transaction_id();

            if ($order->is_paid()) {
                $message = wpautop(wptexturize($this->success_massage));
                $arr1 = array("%Transaction_id%", "%Order_Number%");
                $arr2 = array($transaction_id, $foktor_id);
                $message2 = str_replace($arr1, $arr2, $message);

                if (!empty($message2)) {
                    $txt = '<p>' . $message2 . '</p>';
                    echo $txt;
                }
            }
        }
    }

    public function verify_payment()
    {

        $order_id = $_GET['wc_order'] ?? null;
        if ($order_id == null) {
            wp_die(__('Order id not found!', 'wc_beh'), __('error', 'wc_beh'));
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die(__('Order not found!', 'wc_beh'), __('error', 'wc_beh'));
        }

        $check_card_res = true;

        $currency = $order->get_currency();
        $terminal_id = $this->terminal_id;
        $username = $this->username;
        $password = $this->password;

        $Pay_Status = isset($_POST['ResCode']) ? trim($_POST['ResCode']) : null;
        $SaleOrderId = isset($_POST['SaleOrderId']) ? trim($_POST['SaleOrderId']) : null;

        $SaleReferenceId = $_POST['SaleReferenceId'] ?? null;

        $RefIdPosted = $_POST['RefId'] ?? null;

        if (!empty($SaleReferenceId)) {
            $order->update_meta_data('BehSaleReferenceId', $SaleReferenceId);
        }

        $foktor_id = $order->get_meta('foktor_id', true);
        $RefId = $order->get_meta("RefId", true);

        if ($RefId != $RefIdPosted || $SaleOrderId != $foktor_id) {

            $error = __('Error checking transaction parameters!', 'wc_beh');
            $error .= '<br> POST DATA :' . print_r($_POST, true);
            $order->add_order_note($error);

            wc_add_notice(__('The transaction failed!', 'wc_beh'), 'error');

            wp_redirect(wc_get_checkout_url());
            exit();
        }

        if ($Pay_Status == 0) {
            if ($order->get_status() != 'completed' && $order->get_status() != 'processing') {
                $Amount = intval($order->get_total());

                try {

                    $parameters = array(
                        'terminalId' => $terminal_id,
                        'userName' => $username,
                        'userPassword' => $password,
                        'orderId' => $foktor_id,
                        'saleOrderId' => $SaleOrderId,
                        'saleReferenceId' => $SaleReferenceId
                    );

                    $result = self::soap_call('bpVerifyRequest', $parameters);
                    if (!isset($result->return) || empty($result->return)) {
                        $result = self::soap_call('bpInquiryRequest', $parameters);
                    }

                    $VerResult = explode(',', $result->return);
                    $VerResultInt = $VerResult[0];

                    if (is_numeric($VerResultInt) && ($VerResultInt == 0 || $VerResultInt == 43)) { //OK
                        $SettResult = self::soap_call('bpSettleRequest', $parameters);
                        $SettResult_end = explode(',', $SettResult->return);
                        $SettRes_Int = $SettResult_end[0];

                        if (is_numeric($SettRes_Int) && ($SettRes_Int == 0 || $SettRes_Int == 45)) {

                            $PrimaryAccNo = filter_input(INPUT_POST, 'CardHolderPan');

                            $order->update_meta_data('PrimaryAccNo', $PrimaryAccNo);

                            if ($this->check_card == 'yes') {
                                $c_number = preg_replace('/\D/', '', $PrimaryAccNo);
                                $user_id = $order->get_user_id();

                                $check_card_res = ham3da_Card_Utility::check_user_card_number($user_id, $c_number);
                            }

                            if ($check_card_res) {
                                $Note = sprintf(__('Payment completed successfully.<br/>Transaction code: %s <br/>Transaction order number: %s', 'wc_beh'), $SaleReferenceId, $SaleOrderId);
                                $order->add_order_note($Note, 1);
                                $order->update_meta_data('PrimaryAccNoStatus', '1');
                                ######payment complete####
                                $order->payment_complete($SaleReferenceId);
                                ######payment complete####
                            } else {
                                $Note = sprintf(__('Awaiting review due to payment by unauthorized card.<br/>Transaction code: %s <br>Transaction order number: %s', 'wc_beh'), $SaleReferenceId, $SaleOrderId);
                                $order->add_order_note($Note, 1);
                                ######payment on hold####
                                $order->update_status('on-hold', __('Awaiting review due to payment by unauthorized card.', 'wc_beh'));
                                ######payment on hold####
                                $order->update_meta_data('PrimaryAccNoStatus', "0");
                                $order->save();
                            }

                            WC()->cart->empty_cart();
                            $Notice = wpautop(wptexturize($this->success_massage));
                            $arr1 = array("%Transaction_id%", "%Order_Number%");
                            $arr2 = array($SaleReferenceId, $SaleOrderId);
                            $Notice = str_replace($arr1, $arr2, $Notice);

                            if ($check_card_res) {
                                wc_add_notice($Notice, 'success');
                            } else {
                                $Notice = sprintf(__('Awaiting review due to payment by unauthorized card.<br/>Transaction code: %s <br>Transaction order number: %s', 'wc_beh'), $SaleReferenceId, $SaleOrderId);
                                wc_add_notice($Notice, 'notice');
                            }

                            do_action('WC_BehPardakht_Return_from_Gateway_Success', $order_id, $SaleReferenceId, $SaleOrderId);

                            if ($check_card_res) {
                                wp_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));
                            } else {
                                wp_redirect(add_query_arg('wc_status', 'on-hold', $this->get_return_url($order)));
                            }
                            exit();
                        } else {
                            $fault = $SettResult_end[0];
                            $error = get_beh_error_msg($fault);

                            $tr_id = ($SaleReferenceId && $SaleReferenceId != 0) ? '<br>' . (__('Transaction code: ', 'wc_beh') . $SaleReferenceId) : '';
                            $sale_order_id = ($SaleOrderId && $SaleOrderId != 0) ? '<br>' . (__('Transaction order number: ', 'wc_beh') . $SaleOrderId) : '';

                            $Note = sprintf('Confirmation error: %s %s %s', $error, $tr_id, $sale_order_id);

                            $order->add_order_note($Note, 1);

                            $Notice = wpautop(wptexturize($this->failed_massage));

                            $arr1 = array("%Transaction_id%", "%Order_Number%");
                            $arr2 = array($SaleReferenceId, $SaleOrderId);
                            $Notice = str_replace($arr1, $arr2, $Notice);
                            $Notice = str_replace("%fault%", $error, $Notice);

                            wc_add_notice($Notice, 'error');

                            do_action('WC_BehPardakht_Return_from_Gateway_Failed', $order_id, $SaleReferenceId, $SaleOrderId, $fault);
                            wp_redirect(wc_get_checkout_url());
                            exit();
                        }
                    } else {
                        $error = get_beh_error_msg($VerResult[0]);

                        $tr_id = '<br>' . (__('Transaction code: ', 'wc_beh') . $SaleReferenceId);
                        $sale_order_id = '<br>' . (__('Transaction order number: ', 'wc_beh') . $SaleOrderId);
                        $Note = sprintf(__('Error returning from payment gateway: %s %s %s', 'wc_beh'), $error, $tr_id, $sale_order_id);

                        $order->add_order_note($Note, 1);

                        $Notice = wpautop(wptexturize($this->failed_massage));

                        $arr1 = array("%Transaction_id%", "%Order_Number%");
                        $arr2 = array($SaleReferenceId, $SaleOrderId);

                        $Notice = str_replace($arr1, $arr2, $Notice);
                        $Notice = str_replace("%fault%", $error, $Notice);

                        wc_add_notice($Notice, 'error');

                        do_action('WC_BehPardakht_Return_from_Gateway_Failed', $order_id, $SaleReferenceId, $SaleOrderId, $Pay_Status);
                        wp_redirect(wc_get_checkout_url());
                        exit();
                    }
                } catch (Exception $exc) {

                    $order->add_order_note($exc->getMessage());
                    wc_add_notice($exc->getMessage(), 'error');
                    wp_redirect(wc_get_checkout_url());
                    exit();
                }
            } else { //قبلاً پرداخت شده
                $transaction_id = $order->get_transaction_id();
                $Notice = wpautop(wptexturize($this->success_massage));

                $arr1 = array("%Transaction_id%", "%Order_Number%");
                $arr2 = array($transaction_id, $foktor_id);
                $Notice = str_replace($arr1, $arr2, $Notice);

                wc_add_notice($Notice, 'success');
                do_action('WC_BehPardakht_Return_from_Gateway_ReSuccess', $order_id, $SaleReferenceId, $SaleOrderId);
                wp_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));
                exit();
            }
        } else {
            $error = get_beh_error_msg($Pay_Status);

            $tr_id = '<br>' . (__('Transaction code: ', 'wc_beh') . $SaleReferenceId);
            $sale_order_id = '<br>' . (__('Transaction order number: ', 'wc_beh') . $SaleOrderId);
            $Note = sprintf(__('Error returning from payment gateway: %s %s %s', 'wc_beh'), $error, $tr_id, $sale_order_id);

            $order->add_order_note($Note);

            $Notice = wpautop(wptexturize($this->failed_massage));

            $arr1 = array("%Transaction_id%", "%Order_Number%");
            $arr2 = array($SaleReferenceId, $SaleOrderId);

            $Notice = str_replace($arr1, $arr2, $Notice);
            $Notice = str_replace("%fault%", $error, $Notice);

            wc_add_notice($Notice, 'error');

            do_action('WC_BehPardakht_Return_from_Gateway_Failed', $order_id, $SaleReferenceId, $SaleOrderId, $Pay_Status);
            wp_redirect(wc_get_checkout_url());
            exit();
        }
    }
}

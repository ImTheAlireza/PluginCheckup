<?php

if (!defined('ABSPATH')) {
    die('Access denied!');
}

class WC_Beh_Activation {

    public static $check_url = 'https://guard.zhaket.com/api/';
    //
    public static $produc_token = '437ca11b-f92c-4bb6-8357-fcdaeab9474b';

    public static function on_activation() {
        if (!wp_next_scheduled('beh_validate')) {
            // wp_schedule_event(time(), 'daily', 'beh_validate');
        }
    }

    public static function on_deactivation() {
        if (wp_next_scheduled('beh_validate')) {
            wp_clear_scheduled_hook('beh_validate');
        }
    }

    public static function init() {
        register_deactivation_hook(BEH_PLUGIN_FILE, array(__CLASS__, 'on_deactivation'));
        register_activation_hook(BEH_PLUGIN_FILE, array(__CLASS__, 'on_activation'));
        add_action('beh_validate', array(__CLASS__, 'chk_validate_daily'));
        add_action('wp_ajax_wcbeh_check_register', [__CLASS__, 'ajax_check_register_plugin']);
    }

    public static function getUserLicence() {
        return get_option('ham3da_wcbeh_license_token', '0');
    }

    /**
     * Check License is Valid or No
     * @return boolean|int if License is Valid return true else false and if error return 0
     */
    public static function CheckSavedLicenseisValid() {
        $license_token = get_option('ham3da_wcbeh_license_token', '0'); // Your license token
        $result = self::isValid($license_token);
        if (isset($result->status)) {
            if ($result->status == 'successful') {
                return true;
            } else {
                // License not valid / show message
                if (isset($result->conn_err)) {
                    return -1;
                } else {
                    return false;
                }
            }
        } else {
            return -2;
        }
    }

    /**
     *  Check licence from Zhaket.com every day
     */
    public static function chk_validate_daily() {
        $active_state = self::check_activation();
        if ($active_state && WCBEH_HAM3DA != 1) {
            $plugin_data = get_plugin_data(BEH_PLUGIN_FILE);
            //check licence online
            $LicenseisValid = self::CheckSavedLicenseisValid();
            if ($LicenseisValid === false) {
                update_option('owwpp_ac_wc_beh_xx', '0');
                $admin_email = get_option('admin_email');

                $subject = __("BehPardakht Gateway License Expiration", 'wc_beh');
                $plName = $plugin_data['Name'];

                $dir = is_rtl() ? 'rtl' : 'ltr';
                $message = '<p dir="' . $dir . '">' . sprintf(__('Hi, dear user, %s Plugin License has expired on your site. Please reactivate it.', 'wc_beh'), $plName) . '</p>';
                $message .= '<p dir="' . $dir . '">' . sprintf(__('If you think this is a mistake, please contact %s support.', 'wc_beh'), '<a href="https://www.zhaket.com/">zhaket.com/</a>') . '</p>';
                $site_url = get_site_url();
                $message .= '<p><a href="' . $site_url . '">' . $site_url . '</a></p>';
                $message = apply_filters('wc_beh_alert_licence', $message);
                $headers = array('Content-Type: text/html; charset=UTF-8');
                wp_mail($admin_email, $subject, $message, $headers);
            }
        }
    }

    /**
     * Register license and return result as array
     * @param string $license_token User License
     * @return array 'res' => boolean, 'msg'=> string
     */
    public static function install_validate($license_token) {
        /*
          @param1 : license_token
          @param2 : product_token
          replace it with your own license token and product token :)
         */
        $result = self::install($license_token, self::$produc_token);

        if (!isset($result->status)) {
            return array('res' => false, 'msg' => __('Error checking license status!', 'wc_beh') . '[E0]');
        }

        if ($result->status == 'successful') {
            //echo $result->message; // License installed successful
            update_option('ham3da_wcbeh_license_token', $license_token);
            update_option('owwpp_ac_wc_beh_xx', '1');

            return array('res' => true, 'msg' => $result->message);
        } else {
            update_option('owwpp_ac_wc_beh_xx', '0');

            // License not installed / show message
            if (!is_object($result->message)) {
                // License is Invalid
                //echo $result->message;
                return array('res' => false, 'msg' => $result->message . '[ E1]');
            } else {
                $message_res = "";
                foreach ($result->message as $message) {
                    foreach ($message as $msg) {
                        $message_res .= $msg . '<br/>';
                    }
                }
                return array('res' => false, 'msg' => $message_res . '[ E2]');
            }
        }
    }

    public static function ajax_check_register_plugin() {
        $user_licence = filter_input(INPUT_POST, 'user_licence');
        if ($user_licence != null) {
            $res = self::install_validate($user_licence);
            die(json_encode($res));
        }
    }

    public static function check_activation() {
        $active_state = get_option('owwpp_ac_wc_beh_xx', '0');
        if (intval($active_state) === 1 || WCBEH_HAM3DA === 1) {
            return true;
        } else {
            return false;
        }
    }

    //-------------------------------------------------
    // This method sends GET request to specific url and returns the result
    public static function sendRequest($method, $params = array()) {
        $param_string = http_build_query($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, self::$check_url . $method . '?' . $param_string);
        $content = curl_exec($ch);

        $error = curl_errno($ch);
        $error_msg = curl_error($ch);
        curl_close($ch);
        if ($error) {
            return (object) ['status' => 'failed', 'message' => $error_msg, 'conn_err' => 1];
        } else {
            return json_decode($content);
        }
    }

    //-------------------------------------------------
    public static function isValid($license_token) {
        $result = self::sendRequest('validation-license', array('token' => $license_token, 'domain' => self::getHost()));
        return $result;
    }

    //-------------------------------------------------
    public static function install($license_token, $product_token) {
        $result = self::sendRequest('install-license', array('product_token' => $product_token, 'token' => $license_token, 'domain' => self::getHost()));
        return $result;
    }

    //-------------------------------------------------
    public static function getHost() {
        $host = parse_url(get_site_url(), PHP_URL_HOST);
        $host = preg_replace('/:\d+$/', '', $host);
        $host = str_ireplace('www.', '', $host);
        return trim($host);
    }
}

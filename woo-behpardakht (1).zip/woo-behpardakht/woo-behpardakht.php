<?php

/*
 * Plugin Name: Behpardakht Woocommerce
 * Version: 2.6.5
 * Description: This plugin adds the Behpardakht Mellat payment gateway to the WooCommerce plugin.
 * Plugin URI: https://www.zhaket.com/web/woo-behpardakht-gateway
 * Author: Javad Ehteshami
 * Author URI: https://www.zhaket.com/store/web/ham3da
 * Text Domain: wc_beh
 * Domain Path: /lang
 * Requires Plugins: woocommerce
 * WC requires at least: 6.9
 * WC tested up to: 11.0.1
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit();
}



define("BEH_WOO_VER", "2.6.5");

define("BEH_WOO_DIR", plugin_dir_path(__FILE__));
define("BEH_WOO_URL", plugin_dir_url(__FILE__));
define("BEH_WOO_ID", 'WC_BehPardakht');
define("BEH_PLUGIN_FILE", __FILE__);
define("WCBEH_HAM3DA", 0);


add_action('init', function () {
    load_plugin_textdomain('wc_beh', false, basename(dirname(__FILE__)) . '/lang');
}, 0);

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});


require_once BEH_WOO_DIR . 'inc/functions.php';
require_once BEH_WOO_DIR . 'inc/activation.php';
require_once BEH_WOO_DIR . 'inc/card_functions.php';
require_once BEH_WOO_DIR . 'inc/card_custom_feild.php';
require_once BEH_WOO_DIR . 'inc/refund_table.php';
require_once BEH_WOO_DIR . 'inc/refund_table_init.php';
require_once BEH_WOO_DIR . 'inc/admin.php';
require_once BEH_WOO_DIR . 'inc/order_metabox.php';

register_activation_hook(__FILE__, 'flush_rewrite_rules');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

WC_Beh_Activation::init();

register_activation_hook(__FILE__, 'beh_woo_activation');

add_action('admin_enqueue_scripts', 'beh_woo_admin_init');

function beh_woo_admin_init($hook) {
    
    if($hook == 'woocommerce_page_wc-orders')
    {
        wp_enqueue_script("beh_inqiry", BEH_WOO_URL . "assets/beh_inqiry.js", array('jquery'));
        wp_localize_script( 'beh_inqiry', 'beh_ajax_object',
            array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }
    
    if (in_array($hook, ['profile.php' , 'user-edit.php' ]) ) {

        wp_enqueue_script("sadad_woo_js", BEH_WOO_URL . "assets/tagify/tagify.js");
        wp_enqueue_script("sadad_woo_js2", BEH_WOO_URL . "assets/tagify/jQuery.tagify.min.js", array('jquery'));
        wp_enqueue_script("sadad_woo_admin_js", BEH_WOO_URL . "assets/admin_jscode.js", array('jquery'));
        wp_enqueue_style('sadad_woo', BEH_WOO_URL . "assets/tagify/tagify.css");
        wp_enqueue_style('sadad_woo_admin2', BEH_WOO_URL . "assets/admin_style.css");
    }
}

add_action('woocommerce_before_checkout_form', function ($checkout) {
    echo '<script src="' . BEH_WOO_URL . 'assets/user_jscode.js' . '"></script>';
    echo '<link rel="stylesheet" href="' . BEH_WOO_URL . "assets/user_style.css" . '">';
});

function Load_BehPardakht_Gateway() {
    if (class_exists('WC_Payment_Gateway') && !class_exists('WC_BehPardakht')) {
        add_filter('woocommerce_payment_gateways', function ($methods) {
            $methods[] = 'WC_BehPardakht';
            return $methods;
        });

        add_filter('woocommerce_currencies', 'woo_behpardakht_IR_currency');
        add_filter('woocommerce_currency_symbol', 'woo_behpardakht_IR_currency_symbol', 10, 2);

        require_once BEH_WOO_DIR . 'inc/gateway.php';

        WC_BehPardakht::loadLibrary();
    }
}

add_action('plugins_loaded', 'Load_BehPardakht_Gateway');


function beh_woo_blocks_support() {
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        add_action(
                'woocommerce_blocks_payment_method_type_registration',
                function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
                    require_once BEH_WOO_DIR . 'inc/woo-block.php';
                    $payment_method_registry->register(new Beh_WC_Payments_Block());
                }
        );
    }
}

add_action('woocommerce_blocks_loaded', 'beh_woo_blocks_support');
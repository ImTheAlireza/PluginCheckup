
jQuery(function ($)
{
    $('.beh-payment-inquiry .inquiry').on('click', function () {
        var this_obj = this;
        let order_id = $(this_obj).data('oid');
        var postData = {action: "beh_payment_inquiry", oid: order_id};
        var request = $.ajax({method: "POST",
            data: postData,
            dataType: "json",
            url: beh_ajax_object.ajax_url,
            beforeSend: function (xhr) {
                $('.beh-payment-inquiry .inquiry').find('#loading_pb').show();
            }
        });
        request.done(function (response)
        {
            $('.beh-payment-inquiry .inquiry').find('#loading_pb').hide(200);
            if (response)
            {
                var res = response.res;
                $(".beh-payment-inquiry .inquiry-res").html(response.msg);

            } else
            {
                $(".beh-payment-inquiry .inquiry-res").html("Error: The request failed!");
                console.log("response2 = %o", response);
            }
        });
        request.fail(function (jqXHR, textStatus, errorThrown)
        {
            $('.beh-payment-inquiry .inquiry').find('#loading_pb').hide(200);
            console.log("jqXHR = %o", jqXHR);
            console.log("textStatus = %o", textStatus);
            console.log("errorThrown = %o", errorThrown);
            $(".beh-payment-inquiry .inquiry-res").html('Error: The request failed! <br/>' + errorThrown);

            return;
        });
    });



});
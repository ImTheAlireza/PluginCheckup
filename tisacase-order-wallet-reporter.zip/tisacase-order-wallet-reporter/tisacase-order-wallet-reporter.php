<?php
/**
 * Plugin Name: TisaCase Order Wallet Reporter
 * Description: استعلام تکی و گروهی موجودی کیف پول TeraWallet با شماره سفارش، نمایش وضعیت سفارش و خروجی XLSX.
 * Version: 1.0.0
 * Author: Shayan Zakizadeh
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * Text Domain: tisacase-order-wallet-reporter
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'TisaCase_Order_Wallet_Reporter' ) ) {

	final class TisaCase_Order_Wallet_Reporter {

		const VERSION           = '1.0.0';
		const PAGE_SLUG         = 'tisacase-order-wallet-reporter';
		const AJAX_SINGLE       = 'tisacase_wallet_lookup_single';
		const AJAX_START        = 'tisacase_wallet_report_start';
		const AJAX_BATCH        = 'tisacase_wallet_report_batch';
		const DOWNLOAD_ACTION   = 'tisacase_wallet_report_download';
		const NONCE_ACTION      = 'tisacase_wallet_report_nonce';
		const DOWNLOAD_NONCE    = 'tisacase_wallet_report_download_nonce';
		const BATCH_SIZE        = 20;
		const MAX_BULK_ORDERS   = 5000;
		const REPORT_LIFETIME   = 86400;
		const REPORT_DIR_NAME   = 'tisacase-wallet-reports';

		public static function init() {
			add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
			add_action( 'wp_ajax_' . self::AJAX_SINGLE, array( __CLASS__, 'ajax_single' ) );
			add_action( 'wp_ajax_' . self::AJAX_START, array( __CLASS__, 'ajax_start' ) );
			add_action( 'wp_ajax_' . self::AJAX_BATCH, array( __CLASS__, 'ajax_batch' ) );
			add_action( 'admin_post_' . self::DOWNLOAD_ACTION, array( __CLASS__, 'download_xlsx' ) );
		}

		public static function add_menu() {
			add_submenu_page(
				'woocommerce',
				'گزارش کیف پول سفارش‌ها',
				'گزارش کیف پول سفارش‌ها',
				'manage_woocommerce',
				self::PAGE_SLUG,
				array( __CLASS__, 'render_page' )
			);
		}

		private static function assert_access() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز است.' ), 403 );
			}
		}

		private static function to_english_digits( $value ) {
			return strtr(
				(string) $value,
				array(
					'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
					'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
					'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
					'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
				)
			);
		}

		private static function normalize_order_id( $value ) {
			$value = self::to_english_digits( $value );
			$value = preg_replace( '/\D+/', '', $value );
			return absint( $value );
		}

		private static function phone_variants( $phone ) {
			$raw    = trim( self::to_english_digits( $phone ) );
			$digits = preg_replace( '/\D+/', '', $raw );
			$digits = is_string( $digits ) ? $digits : '';

			if ( 0 === strpos( $digits, '0098' ) ) {
				$digits = substr( $digits, 2 );
			}

			$e164  = '';
			$local = '';

			if ( 12 === strlen( $digits ) && 0 === strpos( $digits, '98' ) ) {
				$e164  = $digits;
				$local = '0' . substr( $digits, 2 );
			} elseif ( 11 === strlen( $digits ) && 0 === strpos( $digits, '09' ) ) {
				$local = $digits;
				$e164  = '98' . substr( $digits, 1 );
			} elseif ( 10 === strlen( $digits ) && 0 === strpos( $digits, '9' ) ) {
				$local = '0' . $digits;
				$e164  = '98' . $digits;
			}

			$variants = array( $raw, $digits );

			if ( $e164 ) {
				$variants[] = $e164;
				$variants[] = '+' . $e164;
			}

			if ( $local ) {
				$variants[] = $local;
				$variants[] = substr( $local, 1 );
			}

			$variants = array_filter( array_map( 'trim', $variants ) );
			return array_values( array_unique( $variants ) );
		}

		private static function find_user_by_phone( $phone ) {
			$variants = self::phone_variants( $phone );

			if ( empty( $variants ) ) {
				return false;
			}

			foreach ( $variants as $variant ) {
				$user = get_user_by( 'login', $variant );
				if ( $user instanceof WP_User ) {
					return $user;
				}
			}

			global $wpdb;

			$meta_keys = array(
				'billing_phone',
				'digits_phone_no',
				'digits_phone',
				'mobile',
				'mobile_number',
				'phone',
				'phone_number',
			);

			$key_placeholders   = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
			$value_placeholders = implode( ', ', array_fill( 0, count( $variants ), '%s' ) );

			$sql = "SELECT user_id
				FROM {$wpdb->usermeta}
				WHERE meta_key IN ({$key_placeholders})
				AND meta_value IN ({$value_placeholders})
				ORDER BY user_id DESC
				LIMIT 1";

			$prepared = $wpdb->prepare( $sql, array_merge( $meta_keys, $variants ) );
			$user_id  = $prepared ? absint( $wpdb->get_var( $prepared ) ) : 0;

			return $user_id ? get_user_by( 'id', $user_id ) : false;
		}

		private static function resolve_user( $order ) {
			$customer_id = absint( $order->get_customer_id() );

			if ( $customer_id ) {
				$user = get_user_by( 'id', $customer_id );
				if ( $user instanceof WP_User ) {
					return array(
						'user'   => $user,
						'method' => 'حساب کاربری متصل به سفارش',
					);
				}
			}

			$phone = $order->get_billing_phone();
			if ( $phone ) {
				$user = self::find_user_by_phone( $phone );
				if ( $user instanceof WP_User ) {
					return array(
						'user'   => $user,
						'method' => 'تطبیق شماره تماس صورتحساب',
					);
				}
			}

			$email = sanitize_email( $order->get_billing_email() );
			if ( $email ) {
				$user = get_user_by( 'email', $email );
				if ( $user instanceof WP_User ) {
					return array(
						'user'   => $user,
						'method' => 'تطبیق ایمیل صورتحساب',
					);
				}
			}

			return false;
		}

		private static function get_wallet_balance( $user_id ) {
			if ( ! function_exists( 'woo_wallet' ) ) {
				return new WP_Error( 'wallet_missing', 'افزونه TeraWallet فعال نیست یا API آن در دسترس نیست.' );
			}

			$instance = woo_wallet();

			if (
				! is_object( $instance ) ||
				! isset( $instance->wallet ) ||
				! is_object( $instance->wallet ) ||
				! method_exists( $instance->wallet, 'get_wallet_balance' )
			) {
				return new WP_Error( 'wallet_api_missing', 'متد دریافت موجودی TeraWallet در دسترس نیست.' );
			}

			return (float) $instance->wallet->get_wallet_balance( absint( $user_id ), 'edit' );
		}

		private static function format_wallet_balance( $balance, $user_id ) {
			if ( function_exists( 'wc_price' ) ) {
				$args = function_exists( 'woo_wallet_wc_price_args' )
					? woo_wallet_wc_price_args( $user_id )
					: array();

				return wc_price( $balance, $args );
			}

			return number_format_i18n( $balance );
		}

		private static function order_status_label( $order ) {
			$status = $order->get_status();
			if ( function_exists( 'wc_get_order_status_name' ) ) {
				$name = wc_get_order_status_name( $status );
				if ( $name ) {
					return $name;
				}
			}
			return $status;
		}

		private static function empty_row( $order_id ) {
			return array(
				'order_id'       => absint( $order_id ),
				'order_number'   => absint( $order_id ) ? '#' . absint( $order_id ) : '—',
				'status'         => '—',
				'customer_name'  => '—',
				'phone'          => '—',
				'username'       => '—',
				'user_id'        => 0,
				'balance'        => 0,
				'balance_html'   => '—',
				'currency'       => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '',
				'method'         => '—',
				'error'          => '',
			);
		}

		private static function lookup_order( $raw_order_number ) {
			$order_id = self::normalize_order_id( $raw_order_number );
			$row      = self::empty_row( $order_id );

			if ( ! function_exists( 'wc_get_order' ) ) {
				$row['error'] = 'ووکامرس فعال نیست.';
				return $row;
			}

			if ( ! $order_id ) {
				$row['error'] = 'شماره سفارش معتبر نیست.';
				return $row;
			}

			$order = wc_get_order( $order_id );

			if ( ! $order instanceof WC_Order ) {
				$row['error'] = 'سفارش پیدا نشد.';
				return $row;
			}

			$row['order_number']  = '#' . $order->get_order_number();
			$row['status']        = self::order_status_label( $order );
			$row['customer_name'] = $order->get_formatted_billing_full_name();
			$row['phone']         = $order->get_billing_phone() ? $order->get_billing_phone() : '—';

			$resolved = self::resolve_user( $order );

			if ( ! $resolved || empty( $resolved['user'] ) || ! $resolved['user'] instanceof WP_User ) {
				$row['error'] = 'حساب کاربری مرتبط با سفارش پیدا نشد.';
				return $row;
			}

			$user = $resolved['user'];

			$row['username'] = $user->user_login;
			$row['user_id']  = (int) $user->ID;
			$row['method']   = $resolved['method'];

			$balance = self::get_wallet_balance( $user->ID );

			if ( is_wp_error( $balance ) ) {
				$row['error'] = $balance->get_error_message();
				return $row;
			}

			$row['balance']      = (float) $balance;
			$row['balance_html'] = self::format_wallet_balance( $balance, $user->ID );

			return $row;
		}

		private static function report_directory() {
			$upload = wp_upload_dir();

			if ( ! empty( $upload['error'] ) ) {
				return new WP_Error( 'upload_dir_error', $upload['error'] );
			}

			$dir = trailingslashit( $upload['basedir'] ) . self::REPORT_DIR_NAME;

			if ( ! wp_mkdir_p( $dir ) ) {
				return new WP_Error( 'report_dir_error', 'پوشه موقت گزارش ساخته نشد.' );
			}

			if ( ! file_exists( trailingslashit( $dir ) . 'index.php' ) ) {
				@file_put_contents( trailingslashit( $dir ) . 'index.php', "<?php\n// Silence is golden.\n" );
			}

			if ( ! file_exists( trailingslashit( $dir ) . '.htaccess' ) ) {
				@file_put_contents( trailingslashit( $dir ) . '.htaccess', "Deny from all\n" );
			}

			return $dir;
		}

		private static function cleanup_old_reports() {
			$dir = self::report_directory();
			if ( is_wp_error( $dir ) ) {
				return;
			}

			$files = glob( trailingslashit( $dir ) . 'report-*.jsonl' );
			if ( ! is_array( $files ) ) {
				return;
			}

			$checked = 0;
			foreach ( $files as $file ) {
				if ( $checked >= 30 ) {
					break;
				}
				$checked++;
				if ( is_file( $file ) && ( time() - filemtime( $file ) ) > self::REPORT_LIFETIME ) {
					@unlink( $file );
				}
			}
		}

		private static function valid_token( $token ) {
			return is_string( $token ) && 1 === preg_match( '/^[a-f0-9]{32}$/', $token );
		}

		private static function report_path( $token ) {
			if ( ! self::valid_token( $token ) ) {
				return new WP_Error( 'invalid_token', 'شناسه گزارش معتبر نیست.' );
			}

			$dir = self::report_directory();
			if ( is_wp_error( $dir ) ) {
				return $dir;
			}

			return trailingslashit( $dir ) . 'report-' . $token . '.jsonl';
		}

		private static function append_report_row( $token, $row ) {
			$path = self::report_path( $token );
			if ( is_wp_error( $path ) ) {
				return $path;
			}

			$line = wp_json_encode( $row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( false === $line ) {
				return new WP_Error( 'json_error', 'ذخیره موقت نتیجه ناموفق بود.' );
			}

			$result = @file_put_contents( $path, $line . PHP_EOL, FILE_APPEND | LOCK_EX );
			if ( false === $result ) {
				return new WP_Error( 'write_error', 'نوشتن فایل موقت گزارش ممکن نشد.' );
			}

			return true;
		}

		private static function create_report_file() {
			$token = md5( wp_generate_uuid4() . '|' . get_current_user_id() . '|' . microtime( true ) );
			$path  = self::report_path( $token );

			if ( is_wp_error( $path ) ) {
				return $path;
			}

			if ( false === @file_put_contents( $path, '' ) ) {
				return new WP_Error( 'report_create_error', 'فایل موقت گزارش ساخته نشد.' );
			}

			return array(
				'token' => $token,
				'path'  => $path,
			);
		}

		private static function download_url( $token ) {
			$url = add_query_arg(
				array(
					'action' => self::DOWNLOAD_ACTION,
					'token'  => $token,
				),
				admin_url( 'admin-post.php' )
			);

			return wp_nonce_url( $url, self::DOWNLOAD_NONCE . '|' . $token );
		}

		public static function ajax_single() {
			self::assert_access();
			check_ajax_referer( self::NONCE_ACTION, 'nonce' );

			$order_number = isset( $_POST['order_number'] )
				? sanitize_text_field( wp_unslash( $_POST['order_number'] ) )
				: '';

			$row    = self::lookup_order( $order_number );
			$report = self::create_report_file();

			if ( is_wp_error( $report ) ) {
				wp_send_json_error( array( 'message' => $report->get_error_message() ), 500 );
			}

			$append = self::append_report_row( $report['token'], $row );
			if ( is_wp_error( $append ) ) {
				wp_send_json_error( array( 'message' => $append->get_error_message() ), 500 );
			}

			wp_send_json_success(
				array(
					'row'          => $row,
					'download_url' => self::download_url( $report['token'] ),
				)
			);
		}

		public static function ajax_start() {
			self::assert_access();
			check_ajax_referer( self::NONCE_ACTION, 'nonce' );
			self::cleanup_old_reports();

			$count = isset( $_POST['count'] ) ? absint( $_POST['count'] ) : 0;

			if ( ! $count ) {
				wp_send_json_error( array( 'message' => 'هیچ شماره سفارشی وارد نشده است.' ), 400 );
			}

			if ( $count > self::MAX_BULK_ORDERS ) {
				wp_send_json_error(
					array( 'message' => 'حداکثر ' . number_format_i18n( self::MAX_BULK_ORDERS ) . ' سفارش در هر گزارش مجاز است.' ),
					400
				);
			}

			$report = self::create_report_file();

			if ( is_wp_error( $report ) ) {
				wp_send_json_error( array( 'message' => $report->get_error_message() ), 500 );
			}

			wp_send_json_success(
				array(
					'token'          => $report['token'],
					'batch_size'     => self::BATCH_SIZE,
					'download_url'   => self::download_url( $report['token'] ),
				)
			);
		}

		public static function ajax_batch() {
			self::assert_access();
			check_ajax_referer( self::NONCE_ACTION, 'nonce' );

			$token = isset( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
			$ids   = isset( $_POST['order_ids'] ) ? (array) $_POST['order_ids'] : array();

			if ( ! self::valid_token( $token ) ) {
				wp_send_json_error( array( 'message' => 'شناسه گزارش معتبر نیست.' ), 400 );
			}

			$ids = array_slice( $ids, 0, self::BATCH_SIZE );
			$rows = array();

			foreach ( $ids as $raw_id ) {
				$row    = self::lookup_order( sanitize_text_field( wp_unslash( $raw_id ) ) );
				$append = self::append_report_row( $token, $row );

				if ( is_wp_error( $append ) ) {
					wp_send_json_error( array( 'message' => $append->get_error_message() ), 500 );
				}

				$rows[] = $row;
			}

			wp_send_json_success( array( 'rows' => $rows ) );
		}

		private static function xml_escape( $value ) {
			return htmlspecialchars( (string) $value, ENT_XML1 | ENT_COMPAT, 'UTF-8' );
		}

		private static function xlsx_col_name( $number ) {
			$name = '';
			while ( $number > 0 ) {
				$number--;
				$name   = chr( 65 + ( $number % 26 ) ) . $name;
				$number = (int) floor( $number / 26 );
			}
			return $name;
		}

		private static function xlsx_inline_cell( $column, $row, $value, $style = 0 ) {
			$ref = self::xlsx_col_name( $column ) . $row;
			return '<c r="' . $ref . '" t="inlineStr" s="' . absint( $style ) . '"><is><t xml:space="preserve">' . self::xml_escape( $value ) . '</t></is></c>';
		}

		private static function xlsx_number_cell( $column, $row, $value, $style = 0 ) {
			$ref = self::xlsx_col_name( $column ) . $row;
			return '<c r="' . $ref . '" t="n" s="' . absint( $style ) . '"><v>' . self::xml_escape( $value ) . '</v></c>';
		}

		private static function ensure_dir( $path ) {
			return is_dir( $path ) || wp_mkdir_p( $path );
		}

		private static function create_xlsx( $jsonl_path, $xlsx_path ) {
			$work_dir = trailingslashit( get_temp_dir() ) . 'tisacase-xlsx-' . wp_generate_password( 12, false, false );

			$dirs = array(
				$work_dir,
				$work_dir . '/_rels',
				$work_dir . '/docProps',
				$work_dir . '/xl',
				$work_dir . '/xl/_rels',
				$work_dir . '/xl/worksheets',
			);

			foreach ( $dirs as $dir ) {
				if ( ! self::ensure_dir( $dir ) ) {
					return new WP_Error( 'xlsx_dir_error', 'ساخت پوشه موقت XLSX ممکن نشد.' );
				}
			}

			$content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
				. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
				. '<Default Extension="xml" ContentType="application/xml"/>'
				. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
				. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
				. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
				. '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
				. '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
				. '</Types>';

			$root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
				. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
				. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
				. '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
				. '</Relationships>';

			$workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
				. '<bookViews><workbookView/></bookViews>'
				. '<sheets><sheet name="گزارش کیف پول" sheetId="1" r:id="rId1"/></sheets>'
				. '</workbook>';

			$workbook_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
				. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
				. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
				. '</Relationships>';

			$styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
				. '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
				. '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
				. '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
				. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
				. '<cellXfs count="3">'
				. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="right" readingOrder="2"/></xf>'
				. '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" readingOrder="2"/></xf>'
				. '<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="right"/></xf>'
				. '</cellXfs>'
				. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
				. '</styleSheet>';

			$created = gmdate( 'Y-m-d\TH:i:s\Z' );
			$core = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
				. '<dc:creator>TisaCase</dc:creator><cp:lastModifiedBy>TisaCase</cp:lastModifiedBy>'
				. '<dcterms:created xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:created>'
				. '<dcterms:modified xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:modified>'
				. '</cp:coreProperties>';

			$app = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
				. '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
				. '<Application>TisaCase</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop>'
				. '</Properties>';

			$static_files = array(
				$work_dir . '/[Content_Types].xml'    => $content_types,
				$work_dir . '/_rels/.rels'            => $root_rels,
				$work_dir . '/xl/workbook.xml'         => $workbook,
				$work_dir . '/xl/_rels/workbook.xml.rels' => $workbook_rels,
				$work_dir . '/xl/styles.xml'           => $styles,
				$work_dir . '/docProps/core.xml'        => $core,
				$work_dir . '/docProps/app.xml'         => $app,
			);

			foreach ( $static_files as $file => $contents ) {
				if ( false === @file_put_contents( $file, $contents ) ) {
					self::remove_tree( $work_dir );
					return new WP_Error( 'xlsx_write_error', 'نوشتن اجزای XLSX ناموفق بود.' );
				}
			}

			$sheet_path = $work_dir . '/xl/worksheets/sheet1.xml';
			$sheet      = @fopen( $sheet_path, 'wb' );

			if ( ! $sheet ) {
				self::remove_tree( $work_dir );
				return new WP_Error( 'xlsx_sheet_error', 'فایل شیت XLSX ساخته نشد.' );
			}

			fwrite( $sheet, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' );
			fwrite( $sheet, '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' );
			fwrite( $sheet, '<sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' );
			fwrite( $sheet, '<sheetFormatPr defaultRowHeight="18"/>' );
			fwrite( $sheet, '<cols><col min="1" max="1" width="16" customWidth="1"/><col min="2" max="2" width="19" customWidth="1"/><col min="3" max="3" width="24" customWidth="1"/><col min="4" max="4" width="18" customWidth="1"/><col min="5" max="5" width="22" customWidth="1"/><col min="6" max="6" width="13" customWidth="1"/><col min="7" max="7" width="20" customWidth="1"/><col min="8" max="8" width="12" customWidth="1"/><col min="9" max="9" width="28" customWidth="1"/><col min="10" max="10" width="35" customWidth="1"/></cols>' );
			fwrite( $sheet, '<sheetData>' );

			$headers = array(
				'شماره سفارش',
				'وضعیت سفارش',
				'نام مشتری',
				'شماره تماس',
				'نام کاربری',
				'شناسه کاربر',
				'موجودی کیف پول',
				'واحد پول',
				'روش شناسایی',
				'خطا',
			);

			$row_number = 1;
			fwrite( $sheet, '<row r="1">' );
			foreach ( $headers as $index => $header ) {
				fwrite( $sheet, self::xlsx_inline_cell( $index + 1, 1, $header, 1 ) );
			}
			fwrite( $sheet, '</row>' );

			$input = @fopen( $jsonl_path, 'rb' );
			if ( ! $input ) {
				fclose( $sheet );
				self::remove_tree( $work_dir );
				return new WP_Error( 'report_read_error', 'فایل موقت گزارش خوانده نشد.' );
			}

			while ( ( $line = fgets( $input ) ) !== false ) {
				$data = json_decode( $line, true );
				if ( ! is_array( $data ) ) {
					continue;
				}

				$row_number++;
				fwrite( $sheet, '<row r="' . $row_number . '">' );
				fwrite( $sheet, self::xlsx_inline_cell( 1, $row_number, isset( $data['order_number'] ) ? $data['order_number'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 2, $row_number, isset( $data['status'] ) ? $data['status'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 3, $row_number, isset( $data['customer_name'] ) ? $data['customer_name'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 4, $row_number, isset( $data['phone'] ) ? $data['phone'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 5, $row_number, isset( $data['username'] ) ? $data['username'] : '' ) );
				fwrite( $sheet, self::xlsx_number_cell( 6, $row_number, isset( $data['user_id'] ) ? (int) $data['user_id'] : 0 ) );
				fwrite( $sheet, self::xlsx_number_cell( 7, $row_number, isset( $data['balance'] ) ? (float) $data['balance'] : 0, 2 ) );
				fwrite( $sheet, self::xlsx_inline_cell( 8, $row_number, isset( $data['currency'] ) ? $data['currency'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 9, $row_number, isset( $data['method'] ) ? $data['method'] : '' ) );
				fwrite( $sheet, self::xlsx_inline_cell( 10, $row_number, isset( $data['error'] ) ? $data['error'] : '' ) );
				fwrite( $sheet, '</row>' );
			}

			fclose( $input );
			fwrite( $sheet, '</sheetData><autoFilter ref="A1:J' . max( 1, $row_number ) . '"/></worksheet>' );
			fclose( $sheet );

			$result = self::zip_directory( $work_dir, $xlsx_path );
			self::remove_tree( $work_dir );

			return $result;
		}

		private static function zip_directory( $source_dir, $destination ) {
			if ( class_exists( 'ZipArchive' ) ) {
				$zip = new ZipArchive();
				if ( true !== $zip->open( $destination, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
					return new WP_Error( 'zip_open_error', 'ساخت فایل XLSX ممکن نشد.' );
				}

				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $source_dir, FilesystemIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::LEAVES_ONLY
				);

				foreach ( $iterator as $file ) {
					if ( ! $file->isFile() ) {
						continue;
					}
					$path     = $file->getPathname();
					$relative = ltrim( str_replace( '\\', '/', substr( $path, strlen( $source_dir ) ) ), '/' );
					$zip->addFile( $path, $relative );
				}

				$zip->close();
				return true;
			}

			require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';

			if ( ! class_exists( 'PclZip' ) ) {
				return new WP_Error( 'zip_missing', 'ZipArchive و PclZip روی سرور در دسترس نیستند.' );
			}

			$archive = new PclZip( $destination );
			$result  = $archive->create( $source_dir, PCLZIP_OPT_REMOVE_PATH, $source_dir );

			if ( 0 === $result ) {
				return new WP_Error( 'pclzip_error', $archive->errorInfo( true ) );
			}

			return true;
		}

		private static function remove_tree( $dir ) {
			if ( ! is_dir( $dir ) ) {
				return;
			}

			$items = scandir( $dir );
			if ( ! is_array( $items ) ) {
				return;
			}

			foreach ( $items as $item ) {
				if ( '.' === $item || '..' === $item ) {
					continue;
				}
				$path = $dir . DIRECTORY_SEPARATOR . $item;
				if ( is_dir( $path ) ) {
					self::remove_tree( $path );
				} else {
					@unlink( $path );
				}
			}

			@rmdir( $dir );
		}

		public static function download_xlsx() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( 'دسترسی غیرمجاز است.' );
			}

			$token = isset( $_GET['token'] ) ? sanitize_key( wp_unslash( $_GET['token'] ) ) : '';
			check_admin_referer( self::DOWNLOAD_NONCE . '|' . $token );

			$report_path = self::report_path( $token );

			if ( is_wp_error( $report_path ) || ! is_file( $report_path ) ) {
				wp_die( 'گزارش موقت پیدا نشد یا منقضی شده است.' );
			}

			$xlsx_path = trailingslashit( get_temp_dir() ) . 'tisacase-wallet-report-' . $token . '.xlsx';
			$result    = self::create_xlsx( $report_path, $xlsx_path );

			if ( is_wp_error( $result ) ) {
				wp_die( esc_html( $result->get_error_message() ) );
			}

			if ( ! is_file( $xlsx_path ) ) {
				wp_die( 'فایل XLSX ساخته نشد.' );
			}

			while ( ob_get_level() ) {
				ob_end_clean();
			}

			$filename = 'tisacase-wallet-report-' . gmdate( 'Y-m-d-His' ) . '.xlsx';

			nocache_headers();
			header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
			header( 'Content-Length: ' . filesize( $xlsx_path ) );
			header( 'X-Content-Type-Options: nosniff' );

			readfile( $xlsx_path );
			@unlink( $xlsx_path );
			exit;
		}

		public static function render_page() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( 'دسترسی غیرمجاز است.' );
			}

			self::cleanup_old_reports();

			$ajax_nonce = wp_create_nonce( self::NONCE_ACTION );
			$download_base = admin_url( 'admin-post.php?action=' . self::DOWNLOAD_ACTION );
			?>

			<div class="wrap tisacase-wallet-reporter" dir="rtl">
				<h1>گزارش کیف پول سفارش‌ها</h1>
				<p>استعلام تکی یا گروهی وضعیت سفارش، کاربر مرتبط و موجودی کیف پول TeraWallet.</p>

				<div class="tisa-tabs">
					<button type="button" class="button button-primary tisa-tab is-active" data-target="single">استعلام تکی</button>
					<button type="button" class="button tisa-tab" data-target="bulk">استعلام گروهی و XLSX</button>
				</div>

				<section id="tisa-panel-single" class="tisa-panel is-active">
					<div class="tisa-card">
						<h2>استعلام تکی</h2>
						<div class="tisa-inline-form">
							<input id="tisa-single-order" type="text" inputmode="numeric" autocomplete="off" placeholder="شماره سفارش؛ مثلاً 28761">
							<button id="tisa-single-submit" type="button" class="button button-primary button-large">استعلام کیف پول</button>
						</div>
						<div id="tisa-single-message"></div>
						<div id="tisa-single-result" class="tisa-table-wrap" style="display:none;"></div>
					</div>
				</section>

				<section id="tisa-panel-bulk" class="tisa-panel">
					<div class="tisa-card">
						<h2>استعلام گروهی</h2>
						<p>شماره سفارش‌ها را با خط جدید، فاصله یا ویرگول جدا کن. شماره‌های تکراری خودکار حذف می‌شوند.</p>
						<textarea id="tisa-bulk-orders" rows="9" placeholder="28761&#10;28762&#10;28763"></textarea>
						<div class="tisa-actions">
							<button id="tisa-bulk-start" type="button" class="button button-primary button-large">شروع بررسی گروهی</button>
							<button id="tisa-bulk-stop" type="button" class="button" disabled>توقف</button>
							<button id="tisa-bulk-clear" type="button" class="button">پاک‌کردن نتایج</button>
							<a id="tisa-download" class="button button-secondary" href="#" style="display:none;">دانلود XLSX</a>
						</div>

						<div id="tisa-progress-box" class="tisa-progress-box" style="display:none;">
							<div class="tisa-progress-track"><div id="tisa-progress-bar"></div></div>
							<p id="tisa-progress-text"></p>
						</div>

						<div id="tisa-bulk-message"></div>
						<div class="tisa-table-wrap">
							<table id="tisa-results-table" class="widefat striped" style="display:none;">
								<thead>
									<tr>
										<th>شماره سفارش</th>
										<th>وضعیت سفارش</th>
										<th>نام مشتری</th>
										<th>شماره تماس</th>
										<th>نام کاربری</th>
										<th>شناسه کاربر</th>
										<th>موجودی کیف پول</th>
										<th>روش شناسایی</th>
										<th>خطا</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</section>
			</div>

			<style>
				.tisacase-wallet-reporter{max-width:1400px}.tisa-tabs{display:flex;gap:8px;margin:20px 0}.tisa-panel{display:none}.tisa-panel.is-active{display:block}.tisa-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.05)}.tisa-inline-form{display:flex;gap:10px;align-items:center}.tisa-inline-form input{width:300px;min-height:44px;font-size:17px;direction:ltr;text-align:center}.tisa-card textarea{width:100%;direction:ltr;text-align:left;font-family:monospace;font-size:15px}.tisa-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.tisa-table-wrap{overflow:auto;margin-top:18px}.tisa-table-wrap table{min-width:1050px}.tisa-table-wrap td,.tisa-table-wrap th{text-align:right;vertical-align:middle}.tisa-progress-box{margin-top:18px}.tisa-progress-track{height:22px;background:#e6e9ef;border-radius:999px;overflow:hidden}.tisa-progress-track div{height:100%;width:0;background:#2271b1;transition:width .2s}.tisa-error{color:#b32d2e;font-weight:700}.tisa-success{color:#008a20;font-weight:700}.tisa-wallet-amount{font-weight:800;color:#135e96;white-space:nowrap}.tisa-single-card{margin-top:16px}.tisa-single-card .tisa-balance{display:flex;justify-content:space-between;align-items:center;background:#eef5ff;border-right:5px solid #2271b1;border-radius:8px;padding:16px;margin-bottom:14px}.tisa-single-card .tisa-balance strong{font-size:24px;color:#135e96}@media(max-width:782px){.tisa-inline-form{align-items:stretch;flex-direction:column}.tisa-inline-form input{width:100%}.tisa-actions>*{flex:1 1 auto}.tisa-single-card .tisa-balance{align-items:flex-start;flex-direction:column;gap:8px}}
			</style>

			<script>
			jQuery(function($){
				const ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
				const nonce = <?php echo wp_json_encode( $ajax_nonce ); ?>;
				const actionSingle = <?php echo wp_json_encode( self::AJAX_SINGLE ); ?>;
				const actionStart = <?php echo wp_json_encode( self::AJAX_START ); ?>;
				const actionBatch = <?php echo wp_json_encode( self::AJAX_BATCH ); ?>;
				const maxOrders = <?php echo (int) self::MAX_BULK_ORDERS; ?>;
				const downloadBase = <?php echo wp_json_encode( $download_base ); ?>;
				let running = false;
				let request = null;
				let orderIds = [];
				let position = 0;
				let token = '';
				let successCount = 0;
				let errorCount = 0;

				function esc(value){return $('<div>').text(value === null || value === undefined ? '' : String(value)).html();}
				function rowHtml(row){
					return '<tr>' +
						'<td dir="ltr">'+esc(row.order_number)+'</td>'+
						'<td>'+esc(row.status)+'</td>'+
						'<td>'+esc(row.customer_name)+'</td>'+
						'<td dir="ltr">'+esc(row.phone)+'</td>'+
						'<td dir="ltr"><strong>'+esc(row.username)+'</strong></td>'+
						'<td>'+esc(row.user_id || '')+'</td>'+
						'<td class="tisa-wallet-amount">'+(row.balance_html || '—')+'</td>'+
						'<td>'+esc(row.method)+'</td>'+
						'<td class="tisa-error">'+esc(row.error)+'</td>'+
					'</tr>';
				}

				function normalizeDigits(value){
					const fa='۰۱۲۳۴۵۶۷۸۹', ar='٠١٢٣٤٥٦٧٨٩';
					return String(value || '').replace(/[۰-۹]/g,d=>fa.indexOf(d)).replace(/[٠-٩]/g,d=>ar.indexOf(d));
				}

				function parseIds(value){
					const parts = normalizeDigits(value).split(/[\s,،;؛|]+/);
					const seen = {};
					const ids = [];
					parts.forEach(function(part){
						const id = String(part).replace(/\D+/g,'');
						if(id && !seen[id]){seen[id]=true;ids.push(id);}
					});
					return ids;
				}

				function updateProgress(){
					const total = orderIds.length;
					const percent = total ? Math.min(100, Math.round(position / total * 100)) : 0;
					$('#tisa-progress-bar').css('width', percent + '%');
					$('#tisa-progress-text').html('بررسی‌شده: <strong>'+position+'</strong> از <strong>'+total+'</strong> — موفق: <strong>'+successCount+'</strong> — خطا: <strong>'+errorCount+'</strong>');
				}

				function setBulkControls(active){
					$('#tisa-bulk-start').prop('disabled', active);
					$('#tisa-bulk-stop').prop('disabled', !active);
				}

				$('.tisa-tab').on('click', function(){
					$('.tisa-tab').removeClass('button-primary is-active');
					$(this).addClass('button-primary is-active');
					$('.tisa-panel').removeClass('is-active');
					$('#tisa-panel-' + $(this).data('target')).addClass('is-active');
				});

				$('#tisa-single-submit').on('click', function(){
					const orderNumber = $('#tisa-single-order').val().trim();
					if(!orderNumber){$('#tisa-single-message').html('<p class="tisa-error">شماره سفارش را وارد کن.</p>');return;}
					const button = $(this);
					button.prop('disabled', true).text('در حال بررسی...');
					$('#tisa-single-message').empty();
					$('#tisa-single-result').hide().empty();
					$.post(ajaxUrl,{action:actionSingle,nonce:nonce,order_number:orderNumber})
					.done(function(response){
						if(!response || !response.success){throw new Error(response && response.data && response.data.message ? response.data.message : 'خطای نامشخص');}
						const row=response.data.row;
						const html='<div class="tisa-single-card"><div class="tisa-balance"><span>موجودی کیف پول</span><strong>'+(row.balance_html || '—')+'</strong></div><table class="widefat striped"><tbody>'+
						'<tr><th>شماره سفارش</th><td dir="ltr">'+esc(row.order_number)+'</td></tr>'+
						'<tr><th>وضعیت سفارش</th><td>'+esc(row.status)+'</td></tr>'+
						'<tr><th>نام مشتری</th><td>'+esc(row.customer_name)+'</td></tr>'+
						'<tr><th>شماره تماس</th><td dir="ltr">'+esc(row.phone)+'</td></tr>'+
						'<tr><th>نام کاربری</th><td dir="ltr"><strong>'+esc(row.username)+'</strong></td></tr>'+
						'<tr><th>شناسه کاربر</th><td>'+esc(row.user_id || '—')+'</td></tr>'+
						'<tr><th>روش شناسایی</th><td>'+esc(row.method)+'</td></tr>'+
						(row.error ? '<tr><th>خطا</th><td class="tisa-error">'+esc(row.error)+'</td></tr>' : '')+
						'</tbody></table><p><a class="button button-secondary" href="'+esc(response.data.download_url || '#')+'">دانلود XLSX همین نتیجه</a></p></div>';
						$('#tisa-single-result').html(html).show();
					})
					.fail(function(xhr){const msg=xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'ارتباط با سرور ناموفق بود.';$('#tisa-single-message').html('<p class="tisa-error">'+esc(msg)+'</p>');})
					.always(function(){button.prop('disabled',false).text('استعلام کیف پول');});
				});

				function runNextBatch(){
					if(!running){return;}
					if(position >= orderIds.length){
						running=false;setBulkControls(false);updateProgress();
						$('#tisa-bulk-message').html('<p class="tisa-success">عملیات کامل شد. فایل XLSX آماده دانلود است.</p>');
						$('#tisa-download').show();
						return;
					}
					const batch = orderIds.slice(position, position + <?php echo (int) self::BATCH_SIZE; ?>);
					request = $.ajax({url:ajaxUrl,type:'POST',dataType:'json',data:{action:actionBatch,nonce:nonce,token:token,order_ids:batch}})
					.done(function(response){
						if(!response || !response.success){running=false;setBulkControls(false);$('#tisa-bulk-message').html('<p class="tisa-error">'+esc(response&&response.data&&response.data.message?response.data.message:'خطا در پردازش')+'</p>');return;}
						(response.data.rows || []).forEach(function(row){$('#tisa-results-table tbody').append(rowHtml(row));if(row.error){errorCount++;}else{successCount++;}});
						position += batch.length;updateProgress();setTimeout(runNextBatch,180);
					})
					.fail(function(xhr,status){if(status==='abort'){return;}running=false;setBulkControls(false);const msg=xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'ارتباط با سرور قطع شد.';$('#tisa-bulk-message').html('<p class="tisa-error">'+esc(msg)+'</p>');});
				}

				$('#tisa-bulk-start').on('click', function(){
					orderIds=parseIds($('#tisa-bulk-orders').val());
					if(!orderIds.length){$('#tisa-bulk-message').html('<p class="tisa-error">شماره سفارش معتبری وارد نشده است.</p>');return;}
					if(orderIds.length>maxOrders){$('#tisa-bulk-message').html('<p class="tisa-error">حداکثر '+maxOrders+' سفارش در هر گزارش مجاز است.</p>');return;}
					position=0;successCount=0;errorCount=0;token='';running=true;
					$('#tisa-results-table tbody').empty();$('#tisa-results-table').show();$('#tisa-download').hide().attr('href','#');$('#tisa-progress-box').show();$('#tisa-bulk-message').empty();setBulkControls(true);updateProgress();
					$.post(ajaxUrl,{action:actionStart,nonce:nonce,count:orderIds.length})
					.done(function(response){
						if(!response||!response.success){running=false;setBulkControls(false);$('#tisa-bulk-message').html('<p class="tisa-error">'+esc(response&&response.data&&response.data.message?response.data.message:'شروع گزارش ناموفق بود.')+'</p>');return;}
						token=response.data.token;
						$('#tisa-download').attr('href', response.data.download_url || '#');
						runNextBatch();
					})
					.fail(function(xhr){running=false;setBulkControls(false);const msg=xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'شروع گزارش ناموفق بود.';$('#tisa-bulk-message').html('<p class="tisa-error">'+esc(msg)+'</p>');});
				});

				$('#tisa-bulk-stop').on('click',function(){running=false;if(request){request.abort();}setBulkControls(false);$('#tisa-bulk-message').html('<p>عملیات متوقف شد. نتایج پردازش‌شده باقی مانده‌اند.</p>');});
				$('#tisa-bulk-clear').on('click',function(){if(running){return;}$('#tisa-results-table tbody').empty();$('#tisa-results-table').hide();$('#tisa-progress-box').hide();$('#tisa-download').hide().attr('href','#');$('#tisa-bulk-message').empty();position=0;successCount=0;errorCount=0;token='';});
			});
			</script>
			<?php
		}
	}

	TisaCase_Order_Wallet_Reporter::init();
}

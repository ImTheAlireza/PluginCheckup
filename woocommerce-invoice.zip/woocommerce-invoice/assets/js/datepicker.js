jQuery(document).ready(function ($) {
    let wooi_created_at_start_date_input = $('input[name="created_at_start_date"]');
    let wooi_created_at_end_date_input = $('input[name="created_at_end_date"]');
    let wooi_paid_at_start_date_input = $('input[name="paid_at_start_date"]');
    let wooi_paid_at_end_date_input = $('input[name="paid_at_end_date"]');
    if (wooi_data.is_rtl) {

        wooi_created_at_start_date_input.persianDatepicker({
            formatDate: "YYYY-0M-0D",
        });

        wooi_created_at_end_date_input.persianDatepicker({
            formatDate: "YYYY-0M-0D",
        });

        wooi_paid_at_start_date_input.persianDatepicker({
            formatDate: "YYYY-0M-0D",
        });

        wooi_paid_at_end_date_input.persianDatepicker({
            formatDate: "YYYY-0M-0D",
        });

    } else {
        wooi_created_at_start_date_input.datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
        });

        wooi_created_at_end_date_input.datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });

        wooi_paid_at_start_date_input.datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
        });

        wooi_paid_at_end_date_input.datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
        });
    }


});
